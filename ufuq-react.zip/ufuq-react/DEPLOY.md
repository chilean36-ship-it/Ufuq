# Ufuq — deploy checklist

## 1. Site (Vercel)
```bash
npm install
npm run build        # must finish without errors
```
Push to the repo connected to Vercel (or `vercel --prod`). Env vars: see `.env.example`.

## 2. Cloudflare Workers (once, then only when `workers/` changes)
**ufuq-media** (teacher videos/audio, private, signed links)
```bash
cd workers/ufuq-media
# 1) wrangler.toml → ALLOWED_ORIGINS = "https://<your-domain>,http://localhost:5173"
npx wrangler secret put SIGNING_SECRET      # paste: openssl rand -base64 48
npx wrangler deploy
```
Keep bucket `ufuq-media` PRIVATE (no r2.dev / public domain).
Then make sure `MEDIA_WORKER_URL` in `src/lib/mediaUpload.js` equals the deployed worker URL.

**ufuq-audio-uploader** (lesson audio, now needs a teacher/admin login)
```bash
cd workers/ufuq-audio-uploader
# wrangler.toml → ALLOWED_ORIGINS, and PUBLIC_BASE_URL (copy the value from the current worker in the Cloudflare dashboard)
npx wrangler deploy
```

## 3. Supabase
Already applied to project `ldbthwpikixtykwmvudy`: `group_media`, `group_media_hardening`
(source: `supabase/migrations/group_media.sql`). Nothing to run again.

## 3b. Hifz (Qur'an recitation checker)
Baza va funksiya `ldbthwpikixtykwmvudy`da tayyor (`supabase/migrations/20261011_hifz.sql`, `supabase/functions/ufuq-hifz-check`).
Deploydan oldin **bir marta**: `public/quran/*.json` ni yasang — `README_HIFZ.md` 1-bo'lim (Tanzil matni, `node scripts/build-quran-json.mjs ...`).
Ixtiyoriy aniqroq dvigatel: `asr-space/` (README_HIFZ 3-4).

## 4. Smoke test (5 min)
1. Teacher → Media → upload a small mp4 to ONE group → appears under that group only.
2. Student of that group → Library → Videos → plays (watermark visible). Student of another group → not listed.
3. Landing page: hero sand-letters react to the mouse.
4. Teacher (individual group) → Teaching → Hifz → assign 112-sura 1–4 to a student. Student → My Group → Hifz → record → coloured result appears; teacher opens the task → Approve / Recite again → student sees the verdict.

## 5. CAPTCHA (Cloudflare Turnstile) — serverda yoqish
Brauzer tomonidagi himoya yetarli emas; haqiqiy bloklash Supabase Auth'da yoqiladi. Bir marta:
1. Cloudflare Dashboard → Turnstile → widget yarating. Domen ro'yxatiga saytingiz domenini va `localhost` ni qo'shing.
2. Site key → Vercel/`.env`: `VITE_TURNSTILE_SITE_KEY`. Secret key → **faqat** Supabase Dashboard.
3. Supabase Dashboard → Authentication → Attack Protection → CAPTCHA protection: Turnstile'ni yoqing, secret key'ni kiriting.
   Shu sozlama login, signup, parolni tiklash va parolni o'zgartirish (signInWithPassword) so'rovlarini himoyalaydi.
4. Authentication → Rate Limits: sign-up va sign-in uchun chegaralarni tekshiring.
5. Tekshirish: `.env` da `VITE_TURNSTILE_SITE_KEY=1x00000000000000000000AA` (doim o'tadi) bilan kirish ishlashini, `2x00000000000000000000AB` (doim rad) bilan esa xabar chiqishini ko'ring.
