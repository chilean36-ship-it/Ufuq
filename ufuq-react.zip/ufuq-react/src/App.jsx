import { Navigate, Route, Routes } from 'react-router-dom';
import ScrollManager from './components/ScrollManager';
import RecoveryGate from './components/RecoveryGate';
import SiteLayout from './components/SiteLayout';
import RequireAuth from './components/RequireAuth';
import RequireRole from './components/RequireRole';
import LandingPage from './pages/Landing/LandingPage';
import AboutAuthor from './pages/AboutAuthor/AboutAuthor';
import Checkout from './pages/Checkout/Checkout';
import CheckoutResult from './pages/Checkout/CheckoutResult';
import Invoice from './pages/Checkout/Invoice';
import ProfileRoute from './pages/Profile/ProfileRoute';
import Dashboard from './pages/Dashboard/Dashboard';
import Admin from './pages/Admin/Admin';
import Teacher from './pages/Teacher/Teacher';
import LegalPage from './pages/Legal/LegalPage';
import Pending from './pages/Pending/Pending';

/**
 * Routes mirror the old multi-page site (cleanUrls):
 *   /index  /about-author  /checkout  /profile  /dashboard  /teacher  /admin
 * and "/" opened dashboard.html (vercel.json rewrite) — kept the same here.
 */
export default function App() {
  return (
    <>
      <ScrollManager />
      <RecoveryGate />
      <Routes>
        {/* pages with the shared language switcher */}
        <Route element={<SiteLayout />}>
          <Route path="/index" element={<LandingPage />} />
          <Route path="/about-author" element={<AboutAuthor />} />
          {['terms', 'privacy', 'cookies', 'refund'].map((d) => (
            <Route key={d} path={`/${d}`} element={<LegalPage doc={d} />} />
          ))}
          <Route path="/checkout" element={<RequireAuth><Checkout /></RequireAuth>} />
          <Route path="/checkout/result" element={<RequireAuth><CheckoutResult /></RequireAuth>} />
          <Route path="/invoice/:id" element={<RequireAuth><Invoice /></RequireAuth>} />
        </Route>

        {/* profile uses its own "cabinet" i18n system (English-keyed), not the site's */}
        <Route path="/profile" element={<ProfileRoute />} />

        {/* role-guarded apps */}
        <Route path="/" element={<RequireRole role="student"><Dashboard /></RequireRole>} />
        <Route path="/dashboard" element={<RequireRole role="student"><Dashboard /></RequireRole>} />
        <Route path="/teacher" element={<RequireRole role="teacher"><Teacher /></RequireRole>} />
        <Route path="/admin" element={<RequireRole role="admin"><Admin /></RequireRole>} />

        {/* old *.html URLs keep working */}
        {['index', 'about-author', 'checkout', 'profile', 'dashboard', 'teacher', 'admin'].map((p) => (
          <Route key={p} path={`/${p}.html`} element={<Navigate to={`/${p}`} replace />} />
        ))}
        <Route path="*" element={<Navigate to="/index" replace />} />
      </Routes>
    </>
  );
}
