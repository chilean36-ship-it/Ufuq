import { useCallback, useEffect, useState } from 'react';
import useLiveRefresh from '../../lib/liveRefresh';
import { supabase } from '../../lib/supabaseClient';
import { usePanel } from '../../components/panel/PanelContext';
import { Avatar, EmptyState, Ico, PageHeader, Skeleton, StatCard } from './ui';

const TIERS = [['super', 'Main admin'], ['standard', 'Admin']];

/** Main admin only: appoint admins, choose their tier, remove admin rights. Everything goes through SECURITY DEFINER
 *  RPCs (supabase/migrations/20261007_admin_tiers.sql) that re-check the caller on the server. */
export default function AdminsPage() {
  const { t, toast, askConfirm, user } = usePanel();
  const [rows, setRows] = useState(null);
  const [email, setEmail] = useState('');
  const [tier, setTier] = useState('standard');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async (opts) => {
    const { data, error: err } = await supabase.rpc('admin_list_admins');
    if (err) { if (!(opts && opts.silent)) setRows({ error: err.message }); return; }
    setRows(data || []);
  }, []);
  useEffect(() => { load(); }, [load]);
  useLiveRefresh(load);

  const fail = (err) => {
    const m = err && err.message ? err.message : String(err);
    toast(m.includes('user_not_found') ? t('No account with this email. The person must sign up first.') : m, 'err');
  };

  async function appoint(e) {
    e.preventDefault();
    setError('');
    if (!email.trim()) { setError(t('Enter the email of the person.')); return; }
    setBusy(true);
    const { error: err } = await supabase.rpc('admin_appoint', { p_email: email.trim(), p_tier: tier });
    setBusy(false);
    if (err) { fail(err); return; }
    toast(t('Admin appointed.'), 'ok');
    setEmail('');
    load();
  }

  async function changeTier(a, next) {
    const { error: err } = await supabase.rpc('admin_set_tier', { p_user: a.id, p_tier: next });
    if (err) { fail(err); return; }
    toast(t('Admin type updated.'), 'ok');
    load();
  }

  function revoke(a) {
    askConfirm(t('Remove admin rights'), (a.full_name || a.email) + ' ' + t('will lose admin access and become a regular student account. Continue?'), async () => {
      const { error: err } = await supabase.rpc('admin_revoke', { p_user: a.id });
      if (err) { fail(err); return; }
      toast(t('Admin rights removed.'), 'ok');
      load();
    });
  }

  const list = Array.isArray(rows) ? rows : [];
  const mains = list.filter((a) => a.admin_tier !== 'standard').length;
  return (
    <section className="page active" id="page-admins">
      <PageHeader title={t('Admins')} sub={t('Appoint admins and choose what each one can do.')} />

      <div className="a-stats a-stats-sm">
        <StatCard loading={rows === null} tone="var(--gold)" label={t('Main admin')} value={mains} icon={<Ico><path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6l-8-3Z" /><path d="m9 12 2 2 4-4" /></Ico>} />
        <StatCard loading={rows === null} tone="var(--a-blue)" label={t('Admin')} value={list.length - mains} icon={<Ico><circle cx="12" cy="7" r="4" /><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /></Ico>} />
      </div>

      <div className="a-grid g-12">
        <div className="panel">
          <div className="panel-head"><h3><span className="panel-head-bar" />{t('Appoint an admin')}</h3></div>
          <form onSubmit={appoint}>
            <div className="field">
              <label htmlFor="adm-email">{t('Email of an existing account')}</label>
              <input id="adm-email" type="email" style={{ width: '100%' }} required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="name@example.com" />
            </div>
            <div className="field">
              <label>{t('Admin type')}</label>
              <div className="a-typepick" role="radiogroup" id="adm-tier">
                {TIERS.map(([v, l]) => <button type="button" role="radio" aria-checked={tier === v} key={v} className={tier === v ? 'on' : ''} onClick={() => setTier(v)}>{t(l)}</button>)}
              </div>
            </div>
            <p className="hint" role="alert" style={{ display: error ? 'block' : 'none', color: 'var(--danger-bright)' }}>{error}</p>
            <div className="modal-actions"><button type="submit" className="btn btn-gold" disabled={busy}>{busy ? t('Saving…') : t('Appoint')}</button></div>
          </form>
        </div>

        <div className="panel">
          <div className="panel-head"><h3><span className="panel-head-bar" />{t('What each type can do')}</h3></div>
          <div className="attn-list">
            <div className="attn ok" style={{ cursor: 'default', alignItems: 'flex-start' }}><b>{'\u2605'}</b><span><strong>{t('Main admin')}</strong><br />{t('Everything: groups, tasks, exams, students, audio, media, and appointing other admins.')}</span></div>
            <div className="attn" style={{ cursor: 'default', alignItems: 'flex-start' }}><b>{'\u25CF'}</b><span><strong>{t('Admin')}</strong><br />{t('Can view groups and students, message students, upload audio lessons, and see reports. Cannot create, edit, delete or deactivate groups, change Zoom links, remove students, or manage tasks and exams.')}</span></div>
          </div>
        </div>
      </div>

      <div className="panel a-flush">
        <div className="panel-head" style={{ padding: '18px 20px 0' }}><h3><span className="panel-head-bar" />{t('Current admins')}</h3></div>
        <div className="a-table-wrap a-flat">
          <table>
            <thead><tr><th>{t('Name')}</th><th>{t('Email')}</th><th>{t('Admin type')}</th><th></th></tr></thead>
            <tbody>
              {rows === null ? <tr className="empty-row"><td colSpan={4}><Skeleton h={28} /></td></tr>
                : rows.error ? <tr className="empty-row"><td colSpan={4}>{rows.error} {'\u2014'} {t('Run the admin-tiers SQL migration first.')}</td></tr>
                : rows.length === 0 ? <tr className="empty-row"><td colSpan={4}><EmptyState title={t('No admins yet.')} /></td></tr>
                : rows.map((a) => {
                  const me = user && a.id === user.id;
                  return (
                    <tr key={a.id}>
                      <td><div className="a-cell-user"><Avatar name={a.full_name || a.email || '?'} /><b>{a.full_name || '\u2014'}{me ? <span className="u-pill gold" style={{ marginLeft: 8 }}>{t('You')}</span> : null}</b></div></td>
                      <td className="muted">{a.email}</td>
                      <td>
                        {me ? <span className="u-pill gold">{t('Main admin')}</span> : (
                          <select className={'chip-select ' + (a.admin_tier === 'standard' ? 'chip-status-unpaid' : 'chip-status-active')} value={a.admin_tier} onChange={(e) => changeTier(a, e.target.value)} aria-label={t('Admin type')}>
                            {TIERS.map(([v, l]) => <option key={v} value={v}>{t(l)}</option>)}
                          </select>
                        )}
                      </td>
                      <td className="a-actions">{!me && <button className="btn btn-danger btn-sm" onClick={() => revoke(a)}>{t('Remove')}</button>}</td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
