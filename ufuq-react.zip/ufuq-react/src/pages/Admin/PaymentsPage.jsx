import { useCallback, useEffect, useMemo, useState } from 'react';
import useLiveRefresh from '../../lib/liveRefresh';
import { supabase } from '../../lib/supabaseClient';
import { usePanel } from '../../components/panel/PanelContext';
import { EmptyRow, Modal, Switch } from '../../components/panel/ui';
import { formatMoney, minorToMajor } from '../../lib/payments';
import PageStyle from '../../components/PageStyle';

const STATUSES = ['pending', 'awaiting_review', 'paid', 'failed', 'cancelled', 'rejected', 'refunded'];
const SLABEL = { pending: 'Waiting for payment', awaiting_review: 'Waiting for review', paid: 'Paid', failed: 'Failed', cancelled: 'Cancelled', rejected: 'Rejected', refunded: 'Refunded' };
const METHOD = { paymob: 'Card (Paymob)', bank_transfer: 'Bank transfer', admin: 'Granted by Ufuq' };
const day = (v) => (v ? new Date(v).toISOString().slice(0, 10) : '');
const money = (c, cur) => (cur ? formatMoney(minorToMajor(c, cur), cur, 'en') : '—');

function downloadCsv(rows) {
  const head = ['invoice_no', 'created', 'paid_at', 'status', 'method', 'plan', 'months', 'buyer_name', 'buyer_email', 'country', 'currency', 'total', 'tax', 'refunded', 'reference'];
  const esc = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const lines = rows.map((o) => [o.invoice_no, day(o.created_at), day(o.paid_at), o.status, o.method, o.plan_id, o.months, o.buyer_name, o.buyer_email, o.buyer_country,
    o.charge_currency, (o.charge_cents / 100).toFixed(2), ((o.tax_cents || 0) / 100).toFixed(2), ((o.refund_cents || 0) / 100).toFixed(2), o.provider_txn_id || o.id].map(esc).join(','));
  const blob = new Blob(['﻿' + [head.join(','), ...lines].join('\n')], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = `ufuq-orders-${day(new Date())}.csv`; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}


/* Payments — header, tabs, metric cards (presentation only) */
const PAY_CSS = `
#page-payments .pay-head{ display:flex; align-items:center; gap:16px; margin-bottom:22px; }
#page-payments .pay-head-icon{ flex:none; width:46px; height:46px; border-radius:12px; display:grid; place-items:center; color:var(--gold-bright); background:var(--gold-dim); border:1px solid rgba(201,162,75,.3); }
#page-payments .pay-head-icon svg{ width:22px; height:22px; }
#page-payments .pay-head-text{ min-width:0; }
#page-payments .pay-head h2{ margin:0; font-size:24px; line-height:1.2; letter-spacing:-.01em; }
#page-payments .pay-head p{ margin:5px 0 0; font-size:14px; line-height:1.5; color:var(--text-muted); }

#page-payments .pay-tabs{ display:inline-flex; gap:4px; padding:4px; margin-bottom:22px; max-width:100%; overflow-x:auto; background:var(--bg-2); border:1px solid var(--line); border-radius:12px; }
#page-payments .pay-tab{ flex:none; min-height:36px; padding:8px 18px; border:none; border-radius:9px; background:transparent; color:var(--text-muted); font-family:inherit; font-size:13.5px; font-weight:600; line-height:1; cursor:pointer; transition:background-color .18s ease, color .18s ease, box-shadow .18s ease; }
#page-payments .pay-tab:hover{ color:var(--text); background:rgba(127,127,127,.08); }
#page-payments .pay-tab.is-active{ color:var(--bg); background:var(--gold); box-shadow:0 6px 16px -8px rgba(200,160,60,.7); }
#page-payments .pay-tab:focus-visible{ outline:2px solid var(--gold); outline-offset:2px; }

#page-payments .pay-metrics{ display:grid; grid-template-columns:repeat(auto-fit, minmax(min(100%, 210px), 1fr)); gap:16px; margin-bottom:22px; }
#page-payments .pay-metric{ position:relative; overflow:hidden; display:flex; align-items:flex-start; gap:14px; padding:18px 18px 16px; background:var(--bg-2); border:1px solid var(--line); border-radius:14px; transition:transform .18s ease, border-color .18s ease, box-shadow .18s ease; }
#page-payments .pay-metric:hover{ transform:translateY(-2px); border-color:rgba(var(--m-rgb),.45); box-shadow:0 14px 30px -18px rgba(0,0,0,.5); }
#page-payments .pay-metric::before{ content:''; position:absolute; inset:0 0 auto 0; height:3px; background:linear-gradient(90deg, transparent, rgb(var(--m-rgb)), transparent); opacity:.8; }
#page-payments .pay-metric-ic{ flex:none; width:40px; height:40px; border-radius:11px; display:grid; place-items:center; color:rgb(var(--m-rgb)); background:rgba(var(--m-rgb),.13); border:1px solid rgba(var(--m-rgb),.3); }
#page-payments .pay-metric-ic svg{ width:19px; height:19px; }
#page-payments .pay-metric-body{ min-width:0; flex:1; }
#page-payments .pay-metric-lbl{ font-size:12px; font-weight:600; letter-spacing:.05em; text-transform:uppercase; color:var(--text-muted); line-height:1.3; }
#page-payments .pay-metric-val{ margin-top:6px; font-family:'Fraunces',serif; font-size:clamp(22px,3.4vw,27px); font-weight:600; line-height:1.15; color:var(--text); overflow-wrap:anywhere; font-variant-numeric:tabular-nums; }
#page-payments .pay-metric-sub{ margin-top:5px; font-size:12.5px; line-height:1.4; color:var(--text-muted); }
#page-payments .pay-metric.gold{ --m-rgb:201,162,75; }
#page-payments .pay-metric.warn{ --m-rgb:224,169,59; }
#page-payments .pay-metric.ok{ --m-rgb:80,176,120; }
#page-payments .pay-metric.bad{ --m-rgb:217,120,104; }
html[data-theme="light"] #page-payments .pay-metric.gold{ --m-rgb:160,118,38; }
html[data-theme="light"] #page-payments .pay-metric.warn{ --m-rgb:176,124,20; }
html[data-theme="light"] #page-payments .pay-metric.ok{ --m-rgb:36,128,76; }
html[data-theme="light"] #page-payments .pay-metric.bad{ --m-rgb:186,78,62; }
#page-payments .pay-metric-skel{ display:inline-block; width:64px; height:24px; border-radius:6px; background:rgba(127,127,127,.16); }

@media (max-width:640px){
  #page-payments .pay-head{ gap:12px; margin-bottom:18px; }
  #page-payments .pay-head-icon{ width:40px; height:40px; border-radius:10px; }
  #page-payments .pay-head h2{ font-size:21px; }
  #page-payments .pay-tabs{ display:flex; width:100%; }
  #page-payments .pay-tab{ flex:1 1 0; padding-inline:12px; }
  #page-payments .pay-metrics{ grid-template-columns:repeat(2, minmax(0,1fr)); gap:12px; }
  #page-payments .pay-metric{ flex-direction:column; gap:10px; padding:14px; }
}
@media (max-width:360px){ #page-payments .pay-metrics{ grid-template-columns:1fr; } }
@media (prefers-reduced-motion:reduce){ #page-payments .pay-tab, #page-payments .pay-metric{ transition:none; } #page-payments .pay-metric:hover{ transform:none; } }
/* Orders — filter bar, themed search, table, status pills */
#page-payments .pay-filters{ padding:18px; }
#page-payments .pay-filters-grid{ display:grid; grid-template-columns:repeat(3, minmax(0,1fr)); gap:14px; margin-bottom:14px; }
#page-payments .pay-filters-grid .field{ margin-bottom:0; }
#page-payments .pay-filters .field label{ font-size:11.5px; font-weight:600; letter-spacing:.05em; text-transform:uppercase; }
#page-payments .pay-search{ position:relative; display:flex; align-items:center; width:100%; }
#page-payments .pay-search-ic{ position:absolute; left:14px; width:17px; height:17px; color:var(--text-muted); pointer-events:none; transition:color .18s ease; }
#page-payments .pay-search input[type=search]{ -webkit-appearance:none; appearance:none; width:100%; min-height:44px; padding:11px 42px 11px 42px; background:var(--bg-3); border:1px solid var(--line); border-radius:10px; color:var(--text); font-family:inherit; font-size:14.5px; line-height:1.3; color-scheme:dark; transition:border-color .18s ease, box-shadow .18s ease, background-color .18s ease; }
html[data-theme="light"] #page-payments .pay-search input[type=search]{ color-scheme:light; }
#page-payments .pay-search input[type=search]::placeholder{ color:var(--text-muted); opacity:.85; }
#page-payments .pay-search input[type=search]::-webkit-search-cancel-button,
#page-payments .pay-search input[type=search]::-webkit-search-decoration{ -webkit-appearance:none; display:none; }
#page-payments .pay-search input[type=search]:hover{ border-color:rgba(201,162,75,.35); }
#page-payments .pay-search input[type=search]:focus{ outline:none; border-color:var(--gold); background:var(--bg-2); box-shadow:0 0 0 3px var(--gold-dim); }
#page-payments .pay-search:focus-within .pay-search-ic{ color:var(--gold-bright); }
#page-payments .pay-search-clear{ position:absolute; right:8px; width:28px; height:28px; display:grid; place-items:center; border:none; border-radius:8px; background:transparent; color:var(--text-muted); cursor:pointer; transition:background-color .15s ease, color .15s ease; }
#page-payments .pay-search-clear:hover{ background:var(--gold-dim); color:var(--gold-bright); }
#page-payments .pay-search-clear svg{ width:14px; height:14px; }
#page-payments .pay-filters select, #page-payments .pay-filters input[type=date]{ min-height:42px; border-radius:10px; transition:border-color .18s ease, box-shadow .18s ease; }
#page-payments .pay-filters select:focus, #page-payments .pay-filters input[type=date]:focus{ border-color:var(--gold); box-shadow:0 0 0 3px var(--gold-dim); }
html[data-theme="dark"] #page-payments .pay-filters input[type=date], html:not([data-theme]) #page-payments .pay-filters input[type=date]{ color-scheme:dark; }
#page-payments .pay-filters-foot{ display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; margin-top:14px; padding-top:14px; border-top:1px solid var(--line); }
#page-payments .pay-filters-foot .hint{ margin:0; font-size:13px; }
#page-payments .pay-filters-foot .hint b{ color:var(--gold-bright); font-variant-numeric:tabular-nums; }
#page-payments .pay-filters-actions{ display:flex; gap:8px; align-items:center; }

#page-payments .pay-table-wrap{ padding:0; overflow-x:auto; border-radius:14px; }
#page-payments .pay-table{ width:100%; border-collapse:separate; border-spacing:0; min-width:760px; }
#page-payments .pay-table thead th{ position:sticky; top:0; padding:13px 16px; text-align:left; font-size:11.5px; font-weight:600; letter-spacing:.06em; text-transform:uppercase; color:var(--text-muted); background:var(--bg-3); border-bottom:1px solid var(--line); white-space:nowrap; }
#page-payments .pay-table tbody td{ padding:14px 16px; vertical-align:middle; font-size:14px; border-bottom:1px solid var(--line); transition:background-color .15s ease; }
#page-payments .pay-table tbody tr:last-child td{ border-bottom:none; }
#page-payments .pay-table tbody tr:hover td{ background:rgba(201,162,75,.06); }
#page-payments .pay-table .hint{ margin-top:3px; }
#page-payments .pay-table .pay-buyer b{ font-weight:600; }
#page-payments .pay-table .pay-amt{ font-variant-numeric:tabular-nums; font-weight:600; white-space:nowrap; }
#page-payments .pay-table .pay-refund{ color:#D97868; font-weight:500; }
html[data-theme="light"] #page-payments .pay-table .pay-refund{ color:#BA4E3E; }
#page-payments .pay-plan{ display:inline-block; padding:3px 9px; border-radius:7px; font-size:12.5px; font-weight:600; background:var(--bg-3); border:1px solid var(--line); }
#page-payments .pay-actions{ text-align:right; white-space:nowrap; }
#page-payments .pay-actions .btn + .btn{ margin-left:6px; }

#page-payments .pay-pill{ display:inline-flex; align-items:center; gap:7px; padding:4px 11px; border-radius:999px; font-size:12px; font-weight:600; white-space:nowrap; --p-rgb:201,162,75; color:rgb(var(--p-rgb)); background:rgba(var(--p-rgb),.13); border:1px solid rgba(var(--p-rgb),.3); }
#page-payments .pay-pill::before{ content:''; width:6px; height:6px; border-radius:50%; background:currentColor; }
#page-payments .pay-pill.ok{ --p-rgb:80,176,120; }
#page-payments .pay-pill.warn{ --p-rgb:224,169,59; }
#page-payments .pay-pill.bad{ --p-rgb:217,120,104; }
#page-payments .pay-pill.mute{ --p-rgb:150,146,138; }
html[data-theme="light"] #page-payments .pay-pill.ok{ --p-rgb:36,128,76; }
html[data-theme="light"] #page-payments .pay-pill.warn{ --p-rgb:176,124,20; }
html[data-theme="light"] #page-payments .pay-pill.bad{ --p-rgb:186,78,62; }
html[data-theme="light"] #page-payments .pay-pill.mute{ --p-rgb:113,105,91; }

#page-payments .pay-skel td{ padding:16px; }
#page-payments .pay-skel-bar{ display:block; height:14px; border-radius:6px; background:linear-gradient(90deg, rgba(127,127,127,.12), rgba(127,127,127,.22), rgba(127,127,127,.12)); background-size:200% 100%; animation:payShimmer 1.3s linear infinite; }
@keyframes payShimmer{ from{ background-position:200% 0; } to{ background-position:-200% 0; } }
#page-payments .pay-empty{ padding:44px 16px; text-align:center; color:var(--text-muted); }
#page-payments .pay-empty svg{ width:34px; height:34px; margin-bottom:10px; opacity:.6; }
#page-payments .pay-empty div{ font-size:14px; }

@media (max-width:720px){
  #page-payments .pay-filters{ padding:14px; }
  #page-payments .pay-filters-grid{ grid-template-columns:1fr; gap:12px; }
  #page-payments .pay-filters-foot{ flex-direction:column; align-items:stretch; }
  #page-payments .pay-filters-actions{ justify-content:flex-end; }
}
@media (prefers-reduced-motion:reduce){ #page-payments .pay-skel-bar{ animation:none; } #page-payments .pay-search input[type=search], #page-payments .pay-table tbody td{ transition:none; } }

/* Access — group chips + accordion */
#page-payments .acc-chips{ display:flex; gap:8px; flex-wrap:wrap; margin-top:14px; }
#page-payments .acc-chip{ display:inline-flex; align-items:center; gap:8px; min-height:34px; padding:6px 8px 6px 14px; border:1px solid var(--line); border-radius:999px; background:var(--bg-3); color:var(--text-muted); font-family:inherit; font-size:13px; font-weight:600; cursor:pointer; transition:background-color .16s ease, color .16s ease, border-color .16s ease; }
#page-payments .acc-chip:hover{ color:var(--text); border-color:rgba(201,162,75,.4); }
#page-payments .acc-chip:focus-visible{ outline:2px solid var(--gold); outline-offset:2px; }
#page-payments .acc-chip.is-active{ color:var(--bg); background:var(--gold); border-color:var(--gold); }
#page-payments .acc-chip-n{ min-width:22px; padding:2px 7px; border-radius:999px; font-size:11.5px; line-height:1.3; text-align:center; background:rgba(127,127,127,.18); font-variant-numeric:tabular-nums; }
#page-payments .acc-chip.is-active .acc-chip-n{ background:rgba(0,0,0,.18); }
#page-payments .acc-toolbar{ display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; margin-top:14px; padding-top:14px; border-top:1px solid var(--line); }
#page-payments .acc-toolbar .hint{ margin:0; font-size:13px; }
#page-payments .acc-toolbar .hint b{ color:var(--gold-bright); }
#page-payments .acc-group{ margin-bottom:14px; padding:0; overflow:hidden; border-radius:14px; }
#page-payments .acc-group-head{ width:100%; display:flex; align-items:center; gap:12px; padding:14px 18px; border:none; background:transparent; color:var(--text); font-family:inherit; text-align:left; cursor:pointer; transition:background-color .15s ease; }
#page-payments .acc-group-head:hover{ background:rgba(201,162,75,.06); }
#page-payments .acc-group-head:focus-visible{ outline:2px solid var(--gold); outline-offset:-2px; }
#page-payments .acc-group-ic{ flex:none; width:36px; height:36px; border-radius:10px; display:grid; place-items:center; color:var(--gold-bright); background:var(--gold-dim); border:1px solid rgba(201,162,75,.3); }
#page-payments .acc-group-ic svg{ width:18px; height:18px; }
#page-payments .acc-group-title{ flex:1; min-width:0; }
#page-payments .acc-group-title b{ display:block; font-size:15px; font-weight:600; overflow-wrap:anywhere; }
#page-payments .acc-group-title span{ display:block; margin-top:2px; font-size:12.5px; color:var(--text-muted); }
#page-payments .acc-caret{ flex:none; width:18px; height:18px; color:var(--text-muted); transition:transform .2s ease; }
#page-payments .acc-group.is-open .acc-caret{ transform:rotate(180deg); }
#page-payments .acc-group-body{ display:none; border-top:1px solid var(--line); overflow-x:auto; }
#page-payments .acc-group.is-open .acc-group-body{ display:block; animation:accFade .18s ease; }
@keyframes accFade{ from{ opacity:0; transform:translateY(-4px); } to{ opacity:1; transform:none; } }
#page-payments .acc-group-body .pay-table{ min-width:560px; }
#page-payments .acc-group-body .pay-table thead th{ position:static; }
@media (max-width:720px){ #page-payments .acc-group-head{ padding:12px 14px; } #page-payments .acc-toolbar{ flex-direction:column; align-items:stretch; } }
@media (prefers-reduced-motion:reduce){ #page-payments .acc-caret{ transition:none; } #page-payments .acc-group.is-open .acc-group-body{ animation:none; } }

/* Settings — section nav, toggle cards, plan cards, save bar */
#page-payments .set-wrap{ max-width:980px; }
#page-payments .set-nav{ display:flex; gap:6px; margin-bottom:18px; overflow-x:auto; padding-bottom:2px; border-bottom:1px solid var(--line); }
#page-payments .set-nav-btn{ position:relative; flex:none; display:inline-flex; align-items:center; gap:9px; min-height:42px; padding:10px 16px; border:none; border-bottom:2px solid transparent; margin-bottom:-1px; background:transparent; color:var(--text-muted); font-family:inherit; font-size:14px; font-weight:600; cursor:pointer; transition:color .15s ease, border-color .15s ease, background-color .15s ease; border-radius:10px 10px 0 0; }
#page-payments .set-nav-btn:hover{ color:var(--text); background:rgba(201,162,75,.06); }
#page-payments .set-nav-btn.is-active{ color:var(--gold-bright); border-bottom-color:var(--gold); }
#page-payments .set-nav-btn:focus-visible{ outline:2px solid var(--gold); outline-offset:-2px; }
#page-payments .set-nav-ic svg{ width:17px; height:17px; display:block; }
#page-payments .set-dot{ display:inline-block; width:7px; height:7px; border-radius:50%; background:var(--gold); }
#page-payments .set-nav-btn .set-dot{ position:absolute; top:9px; right:7px; }

#page-payments .set-card{ margin-bottom:16px; padding:20px; border-radius:14px; }
#page-payments .set-anim{ animation:setIn .2s ease; }
@keyframes setIn{ from{ opacity:0; transform:translateY(6px); } to{ opacity:1; transform:none; } }
#page-payments .set-card-head{ display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; margin-bottom:16px; }
#page-payments .set-card-head h3{ margin:0; font-size:16px; }
#page-payments .set-card-head .btn svg{ width:14px; height:14px; margin-right:6px; vertical-align:-2px; }
#page-payments .set-card > .hint{ margin:0 0 14px; font-size:13px; }
#page-payments .set-grid{ display:grid; grid-template-columns:repeat(2, minmax(0,1fr)); gap:14px; }
#page-payments .set-field{ margin-bottom:14px; }
#page-payments .set-grid .set-field{ margin-bottom:0; }
#page-payments .set-grid{ margin-bottom:14px; }
#page-payments .set-field label{ font-size:11.5px; font-weight:600; letter-spacing:.05em; text-transform:uppercase; }
#page-payments .set-field input, #page-payments .set-field textarea{ border-radius:10px; transition:border-color .18s ease, box-shadow .18s ease; }
#page-payments .set-field input{ min-height:42px; }
#page-payments .set-field input:hover, #page-payments .set-field textarea:hover{ border-color:rgba(201,162,75,.35); }
#page-payments .set-field input:focus, #page-payments .set-field textarea:focus{ outline:none; border-color:var(--gold); box-shadow:0 0 0 3px var(--gold-dim); }

#page-payments .set-toggles{ display:grid; gap:12px; }
#page-payments .set-toggle{ width:100%; display:flex; align-items:center; gap:14px; padding:14px 16px; text-align:left; font-family:inherit; color:var(--text); background:var(--bg-3); border:1px solid var(--line); border-radius:12px; cursor:pointer; transition:border-color .18s ease, background-color .18s ease, transform .18s ease; }
#page-payments .set-toggle:hover{ border-color:rgba(201,162,75,.45); transform:translateY(-1px); }
#page-payments .set-toggle:focus-visible{ outline:2px solid var(--gold); outline-offset:2px; }
#page-payments .set-toggle.is-on{ background:rgba(80,176,120,.08); border-color:rgba(80,176,120,.4); }
#page-payments .set-toggle-ic{ flex:none; width:40px; height:40px; border-radius:11px; display:grid; place-items:center; color:var(--gold-bright); background:var(--gold-dim); border:1px solid rgba(201,162,75,.3); }
#page-payments .set-toggle.is-on .set-toggle-ic{ color:rgb(80,176,120); background:rgba(80,176,120,.13); border-color:rgba(80,176,120,.35); }
#page-payments .set-toggle-ic svg{ width:19px; height:19px; }
#page-payments .set-toggle-body{ flex:1; min-width:0; }
#page-payments .set-toggle-body b{ display:block; font-size:14.5px; font-weight:600; }
#page-payments .set-toggle-body small{ display:block; margin-top:3px; font-size:12.5px; line-height:1.45; color:var(--text-muted); }
#page-payments .set-state{ flex:none; font-size:11px; font-weight:700; letter-spacing:.07em; color:var(--text-muted); }
#page-payments .set-toggle.is-on .set-state{ color:rgb(80,176,120); }
html[data-theme="light"] #page-payments .set-toggle.is-on .set-state{ color:#24804C; }
#page-payments .set-alert{ margin-top:14px; padding:12px 14px; border-radius:10px; font-size:13.5px; color:#E0A93B; background:rgba(224,169,59,.12); border:1px solid rgba(224,169,59,.35); }
html[data-theme="light"] #page-payments .set-alert{ color:#8A5F10; }

#page-payments .set-bank{ display:grid; grid-template-columns:minmax(0,1.1fr) minmax(0,1fr); gap:18px; margin-bottom:12px; }
#page-payments .set-bank .set-field{ margin-bottom:0; }
#page-payments .set-preview-lbl{ margin-bottom:6px; font-size:11.5px; font-weight:600; letter-spacing:.05em; text-transform:uppercase; color:var(--text-muted); }
#page-payments .set-preview-box{ min-height:100%; padding:14px 16px; white-space:pre-wrap; overflow-wrap:anywhere; font-size:14px; line-height:1.6; background:var(--bg-3); border:1px dashed rgba(201,162,75,.4); border-radius:12px; }

#page-payments .set-plans{ display:grid; grid-template-columns:repeat(auto-fit, minmax(min(100%, 260px), 1fr)); gap:14px; }
#page-payments .set-plan{ display:flex; flex-direction:column; gap:12px; padding:16px; background:var(--bg-3); border:1px solid var(--line); border-radius:12px; transition:border-color .18s ease, opacity .18s ease, transform .18s ease; }
#page-payments .set-plan:hover{ border-color:rgba(201,162,75,.4); transform:translateY(-1px); }
#page-payments .set-plan.is-off{ opacity:.7; }
#page-payments .set-plan .set-field{ margin-bottom:0; }
#page-payments .set-plan-top{ display:flex; justify-content:space-between; align-items:center; gap:10px; }
#page-payments .set-plan-sw{ display:inline-flex; align-items:center; gap:8px; }
#page-payments .set-plan-sw .hint{ margin:0; font-size:12.5px; }
#page-payments .set-plan-save{ align-self:flex-end; }

#page-payments .set-fx{ display:grid; grid-template-columns:repeat(auto-fill, minmax(min(100%, 300px), 1fr)); gap:10px; }
#page-payments .set-fx-row{ display:flex; align-items:center; gap:10px; padding:10px 12px; background:var(--bg-3); border:1px solid var(--line); border-radius:12px; transition:border-color .18s ease; }
#page-payments .set-fx-row:hover{ border-color:rgba(201,162,75,.4); }
#page-payments .set-fx-cur{ flex:1; min-width:0; }
#page-payments .set-fx-cur b{ display:block; font-size:14.5px; }
#page-payments .set-fx-cur .hint{ display:block; margin:2px 0 0; font-size:11.5px; }
#page-payments .set-fx-row input{ width:110px; min-height:38px; border-radius:9px; }
#page-payments .set-remind{ display:flex; align-items:center; gap:14px; flex-wrap:wrap; }
#page-payments .set-remind .hint{ flex:1; min-width:200px; margin:0; font-size:13px; }

#page-payments .set-savebar{ position:sticky; bottom:12px; z-index:5; display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; padding:12px 16px; background:var(--bg-2); border:1px solid var(--line); border-radius:14px; box-shadow:0 12px 30px -16px rgba(0,0,0,.55); transition:border-color .18s ease; }
#page-payments .set-savebar.is-dirty{ border-color:rgba(201,162,75,.55); }
#page-payments .set-savebar-msg{ display:inline-flex; align-items:center; gap:9px; font-size:13.5px; font-weight:600; color:var(--text-muted); }
#page-payments .set-savebar-msg .set-dot{ background:rgb(80,176,120); }
#page-payments .set-savebar.is-dirty .set-savebar-msg{ color:var(--gold-bright); }
#page-payments .set-savebar.is-dirty .set-savebar-msg .set-dot{ background:var(--gold); animation:setPulse 1.4s ease-in-out infinite; }
@keyframes setPulse{ 50%{ opacity:.35; } }
#page-payments .set-savebar-btns{ display:inline-flex; align-items:center; gap:8px; }

@media (max-width:720px){
  #page-payments .set-card{ padding:16px; }
  #page-payments .set-grid{ grid-template-columns:1fr; }
  #page-payments .set-bank{ grid-template-columns:1fr; }
  #page-payments .set-toggle{ flex-wrap:wrap; }
  #page-payments .set-toggle-body{ flex-basis:calc(100% - 140px); }
  #page-payments .set-savebar{ bottom:8px; }
  #page-payments .set-savebar-btns{ width:100%; justify-content:flex-end; }
}
@media (prefers-reduced-motion:reduce){ #page-payments .set-anim, #page-payments .set-savebar.is-dirty .set-dot{ animation:none; } #page-payments .set-toggle, #page-payments .set-plan, #page-payments .set-nav-btn{ transition:none; } #page-payments .set-toggle:hover, #page-payments .set-plan:hover{ transform:none; } }

/* Global polish: pane transition, buttons, focus, mobile stacked tables */
#page-payments .pay-pane{ animation:payPane .22s ease; }
@keyframes payPane{ from{ opacity:0; transform:translateY(8px); } to{ opacity:1; transform:none; } }
#page-payments .btn{ transition:transform .15s ease, box-shadow .15s ease, background-color .15s ease, border-color .15s ease, color .15s ease, opacity .15s ease; }
#page-payments .btn:not(:disabled):hover{ transform:translateY(-1px); }
#page-payments .btn:not(:disabled):active{ transform:translateY(0) scale(.98); }
#page-payments .btn-gold:not(:disabled):hover{ box-shadow:0 8px 18px -10px rgba(200,160,60,.8); }
#page-payments .btn:disabled{ opacity:.55; cursor:not-allowed; }
#page-payments .btn:focus-visible, #page-payments select:focus-visible, #page-payments input:focus-visible, #page-payments textarea:focus-visible{ outline:2px solid var(--gold); outline-offset:2px; }
#page-payments .pay-filters input:focus-visible, #page-payments .set-field input:focus-visible, #page-payments .set-field textarea:focus-visible, #page-payments .pay-search input:focus-visible{ outline:none; }
#page-payments .pay-table-wrap, #page-payments .acc-group-body{ scrollbar-width:thin; }
#page-payments .pay-actions .btn{ opacity:.92; }
#page-payments .pay-table tbody tr:hover .pay-actions .btn{ opacity:1; }
@media (max-width:640px){
  #page-payments .pay-table, #page-payments .acc-group-body .pay-table{ min-width:0; display:block; }
  #page-payments .pay-table thead{ display:none; }
  #page-payments .pay-table tbody{ display:block; }
  #page-payments .pay-table tbody tr{ display:block; padding:12px 14px; border-bottom:1px solid var(--line); }
  #page-payments .pay-table tbody tr:last-child{ border-bottom:none; }
  #page-payments .pay-table tbody td{ display:flex; justify-content:space-between; align-items:center; gap:14px; padding:6px 0; border:none; text-align:right; background:transparent !important; }
  #page-payments .pay-table tbody td[data-label]::before{ content:attr(data-label); flex:none; font-size:11px; font-weight:600; letter-spacing:.05em; text-transform:uppercase; color:var(--text-muted); text-align:left; }
  #page-payments .pay-table tbody td.pay-buyer{ text-align:right; }
  #page-payments .pay-table tbody td.pay-actions{ justify-content:flex-end; padding-top:10px; }
  #page-payments .pay-table tbody td.pay-actions:empty{ display:none; }
  #page-payments .pay-table tr.pay-skel td{ display:block; }
}
@media (prefers-reduced-motion:reduce){ #page-payments .pay-pane{ animation:none; } #page-payments .btn{ transition:none; } #page-payments .btn:not(:disabled):hover, #page-payments .btn:not(:disabled):active{ transform:none; } }
`;

const svg = (d) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{d}</svg>
);
const IC_WALLET = svg(<><path d="M3 7.5A2.5 2.5 0 015.5 5H18a1 1 0 011 1v2" /><path d="M3 7.5V17a2 2 0 002 2h13a1 1 0 001-1v-9a1 1 0 00-1-1H5.5A2.5 2.5 0 013 7.5z" /><circle cx="16" cy="13.5" r="1.1" fill="currentColor" stroke="none" /></>);
const IC_CLOCK = svg(<><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>);
const IC_CHECK = svg(<><circle cx="12" cy="12" r="9" /><path d="M8 12.5l2.8 2.8L16.5 9.5" /></>);
const IC_UNDO = svg(<><path d="M9 7L4 12l5 5" /><path d="M4 12h10a6 6 0 010 12" transform="translate(0 -6)" /></>);
const IC_TOGGLE = svg(<><rect x="2.5" y="7" width="19" height="10" rx="5" /><circle cx="16.5" cy="12" r="2.6" /></>);
const IC_BUILDING = svg(<><path d="M4 21V5a1 1 0 011-1h9a1 1 0 011 1v16" /><path d="M15 9h4a1 1 0 011 1v11" /><path d="M8 8h3M8 12h3M8 16h3M3 21h18" /></>);
const IC_BANK = svg(<><path d="M3 10l9-6 9 6" /><path d="M5 10v8M9.5 10v8M14.5 10v8M19 10v8M3 21h18" /></>);
const IC_TAG = svg(<><path d="M3 12V4a1 1 0 011-1h8l9 9-9 9-9-9z" /><circle cx="7.5" cy="7.5" r="1.2" fill="currentColor" stroke="none" /></>);
const IC_SHIELD = svg(<><path d="M12 3l8 3v6c0 4.5-3.2 7.8-8 9-4.8-1.2-8-4.5-8-9V6l8-3z" /><path d="M8.5 12l2.5 2.5 4.5-5" /></>);
const IC_CARD = svg(<><rect x="2.5" y="5" width="19" height="14" rx="2.5" /><path d="M2.5 10h19M6.5 15h4" /></>);
const IC_PERCENT = svg(<><path d="M19 5L5 19" /><circle cx="7" cy="7" r="2.2" /><circle cx="17" cy="17" r="2.2" /></>);
const IC_BELL = svg(<><path d="M6 16V11a6 6 0 0112 0v5l1.5 2h-15L6 16z" /><path d="M10 21h4" /></>);
const IC_REFRESH = svg(<><path d="M20 11a8 8 0 00-14-4L4 9" /><path d="M4 4v5h5" /><path d="M4 13a8 8 0 0014 4l2-2" /><path d="M20 20v-5h-5" /></>);

function Metric({ tone, icon, label, value, sub, loading }) {
  return (
    <div className={'pay-metric ' + tone}>
      <span className="pay-metric-ic">{icon}</span>
      <div className="pay-metric-body">
        <div className="pay-metric-lbl">{label}</div>
        <div className="pay-metric-val">{loading ? <span className="pay-metric-skel" /> : value}</div>
        {sub ? <div className="pay-metric-sub">{sub}</div> : null}
      </div>
    </div>
  );
}

/** Admin → Payments: orders & bank-transfer review, who has access, and the payment settings. All writes go through
 *  SECURITY DEFINER RPCs that re-check the caller (see supabase/migrations/20261018_payments.sql). */
const IC_SEARCH = svg(<><circle cx="11" cy="11" r="7" /><path d="M20 20l-3.5-3.5" /></>);
const IC_X = svg(<path d="M6 6l12 12M18 6L6 18" />);
const IC_INBOX = svg(<><path d="M3 13l2.5-7.5A2 2 0 017.4 4h9.2a2 2 0 011.9 1.5L21 13" /><path d="M3 13v5a2 2 0 002 2h14a2 2 0 002-2v-5h-5l-1.5 2h-5L8 13H3z" /></>);

function SearchBox({ value, onChange, placeholder, label }) {
  return (
    <div className="pay-search">
      <span className="pay-search-ic">{IC_SEARCH}</span>
      <input type="search" aria-label={label || placeholder} placeholder={placeholder} value={value} onChange={(e) => onChange(e.target.value)} autoComplete="off" spellCheck={false} />
      {value ? <button type="button" className="pay-search-clear" aria-label="Clear" onClick={() => onChange('')}>{IC_X}</button> : null}
    </div>
  );
}

const IC_CARET = svg(<path d="M6 9l6 6 6-6" />);
const IC_GROUP = svg(<><circle cx="9" cy="8" r="3.2" /><path d="M3 19c0-3.2 2.7-5.5 6-5.5s6 2.3 6 5.5" /><circle cx="17" cy="9" r="2.4" /><path d="M16.5 14c2.6 0 4.5 1.8 4.5 4.5" /></>);

const PILL = { paid: 'ok', pending: 'warn', awaiting_review: 'warn', failed: 'bad', rejected: 'bad', cancelled: 'mute', refunded: 'bad' };

export default function PaymentsPage() {
  const { t, toast, isSuper } = usePanel();
  const [tab, setTab] = useState('orders');
  return (
    <section className="page active" id="page-payments">
      <PageStyle css={PAY_CSS} />
      <div className="pay-head">
        <span className="pay-head-icon">{IC_WALLET}</span>
        <div className="pay-head-text"><h2>{t('Payments')}</h2><p>{t('Orders, bank-transfer review, access and payment settings.')}</p></div>
      </div>
      <div className="pay-tabs" role="tablist">
        {[['orders', 'Orders'], ['access', 'Access'], ...(isSuper ? [['settings', 'Settings']] : [])].map(([k, l]) => (
          <button key={k} type="button" role="tab" aria-selected={tab === k} className={'pay-tab' + (tab === k ? ' is-active' : '')} onClick={() => setTab(k)}>{t(l)}</button>
        ))}
      </div>
      <div className="pay-pane" key={tab}>
        {tab === 'orders' && <OrdersTab />}
        {tab === 'access' && <AccessTab />}
        {tab === 'settings' && isSuper && <SettingsTab />}
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ orders */
function OrdersTab() {
  const { t, toast, isSuper } = usePanel();
  const [rows, setRows] = useState(null);
  const [status, setStatus] = useState('');
  const [q, setQ] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [checks, setChecks] = useState({ lessons: false, downloads: false });
  const [sel, setSel] = useState(null); // { order, mode: 'review' | 'refund', proofUrl }
  const [note, setNote] = useState('');
  const [amount, setAmount] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const { data, error } = await supabase.rpc('admin_list_orders', { p_status: status || null, p_from: from || null, p_to: to || null, p_q: q || null });
    if (error) { setRows((r) => r || { error: error.message }); return; }
    setRows(data || []);
  }, [status, from, to, q]);
  useEffect(() => { load(); }, [load]);
  useLiveRefresh(load);

  const totals = useMemo(() => (Array.isArray(rows) ? rows.filter((o) => o.status === 'paid').reduce((s, o) => s + (o.charge_cents - (o.refund_cents || 0)), 0) : 0), [rows]);
  const cur = Array.isArray(rows) && rows[0] ? rows[0].charge_currency : 'EGP';

  async function open(o, mode) {
    setNote(''); setChecks({ lessons: false, downloads: false }); setAmount(mode === 'refund' ? ((o.charge_cents - (o.refund_cents || 0)) / 100).toFixed(2) : '');
    let proofUrl = null;
    if (mode === 'review' && o.proof_path) {
      const { data } = await supabase.storage.from('payment-proofs').createSignedUrl(o.proof_path, 600);
      proofUrl = data && data.signedUrl;
    }
    setSel({ order: o, mode, proofUrl });
  }
  async function review(approve) {
    setBusy(true);
    const { error } = await supabase.rpc('admin_review_order', { p_order: sel.order.id, p_approve: approve, p_note: note });
    setBusy(false);
    if (error) { toast(error.message, 'err'); return; }
    toast(t(approve ? 'Payment approved. Access granted.' : 'Payment rejected.'), 'ok');
    setSel(null); load();
  }
  async function refund() {
    const cents = Math.round(Number(amount) * 100);
    if (!cents || cents <= 0) { toast(t('Enter a valid amount.'), 'err'); return; }
    setBusy(true);
    const { error } = await supabase.rpc('admin_refund_order', { p_order: sel.order.id, p_cents: cents, p_note: note });
    setBusy(false);
    if (error) { toast(String(error.message).includes('REFUND_WINDOW_CLOSED') ? t('The refund window for this order has closed.') : error.message, 'err'); return; }
    toast(t('Refund recorded.'), 'ok');
    setSel(null); load();
  }

  const list = Array.isArray(rows) ? rows : [];
  const nPaid = list.filter((o) => o.status === 'paid').length;
  const nReview = list.filter((o) => ['pending', 'awaiting_review'].includes(o.status)).length;
  const nRefunded = list.filter((o) => o.status === 'refunded' || o.refund_cents > 0).length;
  const loadingRows = rows === null;
  return (
    <>
      <div className="pay-metrics">
        <Metric tone="gold" icon={IC_WALLET} label={t('Net revenue')} value={money(totals, cur)} sub={t('Paid, minus refunds')} loading={loadingRows} />
        <Metric tone="warn" icon={IC_CLOCK} label={t('Pending')} value={nReview} sub={t('Waiting for payment or review')} loading={loadingRows} />
        <Metric tone="ok" icon={IC_CHECK} label={t('Paid orders')} value={nPaid} sub={`${list.length} ${t('orders')}`} loading={loadingRows} />
        <Metric tone="bad" icon={IC_UNDO} label={t('Refunded')} value={nRefunded} sub={t('Orders with a refund')} loading={loadingRows} />
      </div>
      <div className="panel pay-filters">
        <div className="pay-filters-grid">
          <div className="field"><label>{t('Status')}</label>
            <select value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="">{t('All')}</option>
              {STATUSES.map((s) => <option key={s} value={s}>{t(SLABEL[s])}</option>)}
            </select></div>
          <div className="field"><label>{t('From')}</label><input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></div>
          <div className="field"><label>{t('To')}</label><input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></div>
        </div>
        <SearchBox value={q} onChange={setQ} placeholder={t('Search name, email or invoice no.')} />
        <div className="pay-filters-foot">
          <span className="hint">{t('Net paid in this list')}: <b>{money(totals, cur)}</b> · {list.length} {t('orders')}</span>
          <div className="pay-filters-actions">
            {(status || from || to || q) && <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setStatus(''); setFrom(''); setTo(''); setQ(''); }}>{t('Reset')}</button>}
            <button type="button" className="btn btn-ghost btn-sm" disabled={!list.length} onClick={() => downloadCsv(list)}>{t('Export CSV')}</button>
          </div>
        </div>
      </div>

      <div className="panel pay-table-wrap">
        <table className="pay-table">
          <thead><tr><th>{t('Date')}</th><th>{t('Buyer')}</th><th>{t('Plan')}</th><th>{t('Method')}</th><th>{t('Amount')}</th><th>{t('Status')}</th><th></th></tr></thead>
          <tbody>
            {rows === null ? [0, 1, 2, 3].map((i) => (
                <tr key={i} className="pay-skel">{[0, 1, 2, 3, 4, 5, 6].map((j) => <td key={j}><span className="pay-skel-bar" /></td>)}</tr>
              ))
              : rows.error ? <EmptyRow cols={7}>{rows.error}</EmptyRow>
              : list.length === 0 ? <tr><td colSpan={7}><div className="pay-empty">{IC_INBOX}<div>{t('No orders.')}</div></div></td></tr>
              : list.map((o) => (
                <tr key={o.id}>
                  <td data-label={t('Date')}>{day(o.created_at)}<div className="hint">{o.invoice_no || ''}</div></td>
                  <td data-label={t('Buyer')} className="pay-buyer"><b>{o.buyer_name}</b><div className="hint">{o.buyer_email} · {o.buyer_country}</div></td>
                  <td data-label={t('Plan')}><span className="pay-plan">{o.plan_id}</span></td>
                  <td data-label={t('Method')}>{t(METHOD[o.method] || o.method)}</td>
                  <td data-label={t('Amount')} className="pay-amt">{money(o.charge_cents, o.charge_currency)}{o.refund_cents > 0 && <div className="hint pay-refund">− {money(o.refund_cents, o.charge_currency)}</div>}</td>
                  <td data-label={t('Status')}><span className={'pay-pill ' + (PILL[o.status] || '')}>{t(SLABEL[o.status] || o.status)}</span></td>
                  <td className="pay-actions">
                    {o.method === 'bank_transfer' && ['pending', 'awaiting_review'].includes(o.status) && <button className="btn btn-gold btn-sm" onClick={() => open(o, 'review')}>{t('Review')}</button>}
                    {isSuper && o.status === 'paid' && <button className="btn btn-ghost btn-sm" onClick={() => open(o, 'refund')}>{t('Refund')}</button>}
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>

      <Modal open={!!sel} onClose={() => setSel(null)} style={{ maxWidth: 520 }}>
        {sel && sel.mode === 'review' && (
          <>
            <h3>{t('Review bank transfer')}</h3>
            <p className="hint" style={{ fontSize: 13.5, color: 'var(--text)' }}>
              <b>{sel.order.buyer_name}</b> · {sel.order.buyer_email}<br />
              {money(sel.order.charge_cents, sel.order.charge_currency)} · {t('Reference')}: UFUQ-{sel.order.id.slice(0, 8).toUpperCase()}
            </p>
            {sel.order.proof_note && <p className="hint">{t('Student note')}: {sel.order.proof_note}</p>}
            {sel.proofUrl ? <p><a href={sel.proofUrl} target="_blank" rel="noopener noreferrer" className="btn btn-ghost btn-sm">{t('Open receipt')}</a></p> : <p className="hint">{t('No receipt uploaded yet.')}</p>}
            <p className="hint">{t('Approve only after the money is visible on the bank statement. A receipt image alone is not proof.')}</p>
            <div className="field"><label>{t('Note (shown in the log)')}</label><input style={{ width: '100%' }} maxLength={300} value={note} onChange={(e) => setNote(e.target.value)} /></div>
            <div className="modal-actions">
              <button className="btn btn-danger" disabled={busy} onClick={() => review(false)}>{t('Reject')}</button>
              <button className="btn btn-gold" disabled={busy} onClick={() => review(true)}>{t('Approve')}</button>
            </div>
          </>
        )}
        {sel && sel.mode === 'refund' && (
          <>
            <h3>{t('Record a refund')}</h3>
            <p className="hint">{t('This records the refund and shortens access. Send the money back from the Paymob dashboard or your bank yourself.')}</p>
            <p className="hint">{t('Paid on')}: {sel.order.paid_at ? new Date(sel.order.paid_at).toLocaleDateString() : '—'}. {t('Refund allowed only within the refund window (see settings).')}</p>
            <label className="hint" style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
              <input type="checkbox" checked={checks.lessons} onChange={(e) => setChecks((c) => ({ ...c, lessons: e.target.checked }))} />
              {t('Student attended no more than 2 live lessons.')}
            </label>
            <label className="hint" style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 12 }}>
              <input type="checkbox" checked={checks.downloads} onChange={(e) => setChecks((c) => ({ ...c, downloads: e.target.checked }))} />
              {t('Student did not bulk-download the materials.')}
            </label>
            <div className="field"><label>{t('Amount')} ({sel.order.charge_currency})</label><input type="number" min="0" step="0.01" style={{ width: '100%' }} value={amount} onChange={(e) => setAmount(e.target.value)} /></div>
            <div className="field"><label>{t('Reason')}</label><input style={{ width: '100%' }} maxLength={300} value={note} onChange={(e) => setNote(e.target.value)} /></div>
            <div className="modal-actions">
              <button className="btn btn-ghost" onClick={() => setSel(null)}>{t('Cancel')}</button>
              <button className="btn btn-gold" disabled={busy || !checks.lessons || !checks.downloads} onClick={refund}>{t('Record refund')}</button>
            </div>
          </>
        )}
      </Modal>
    </>
  );
}

/* ------------------------------------------------------------------ access */
function AccessTab() {
  const { t, toast, askConfirm, isSuper } = usePanel();
  const [rows, setRows] = useState(null);
  const [q, setQ] = useState('');
  const [grant, setGrant] = useState(null);
  const [months, setMonths] = useState(1);
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [groups, setGroups] = useState([]);
  const [members, setMembers] = useState([]);
  const [gFilter, setGFilter] = useState('all');
  const [closed, setClosed] = useState(() => new Set());

  const load = useCallback(async () => {
    const { data, error } = await supabase.rpc('admin_list_access', { p_q: q || null });
    if (error) { setRows((r) => r || { error: error.message }); return; }
    setRows(data || []);
  }, [q]);
  useEffect(() => { const id = setTimeout(load, 250); return () => clearTimeout(id); }, [load]);
  useLiveRefresh(load);

  const loadGroups = useCallback(async () => {
    const [g, m] = await Promise.all([
      supabase.from('groups').select('code, name').order('name'),
      supabase.from('group_members').select('user_id, group_code'),
    ]);
    if (!g.error) setGroups((g.data || []).slice().sort((x, y) => String(x.name || x.code).localeCompare(String(y.name || y.code), undefined, { numeric: true, sensitivity: 'base' })));
    if (!m.error) setMembers(m.data || []);
  }, []);
  useEffect(() => { loadGroups(); }, [loadGroups]);
  useLiveRefresh(loadGroups);

  async function doGrant() {
    setBusy(true);
    const { error } = await supabase.rpc('admin_grant_access', { p_user: grant.user_id, p_months: Number(months), p_note: note });
    setBusy(false);
    if (error) { toast(error.message, 'err'); return; }
    toast(t('Access granted.'), 'ok'); setGrant(null); setNote(''); load();
  }
  function revoke(r) {
    askConfirm(t('Revoke access'), (r.full_name || r.email) + ' — ' + t('current access will end now. Continue?'), async () => {
      const { error } = await supabase.rpc('admin_revoke_access', { p_user: r.user_id });
      if (error) { toast(error.message, 'err'); return; }
      toast(t('Access revoked.'), 'ok'); load();
    });
  }

  const list = Array.isArray(rows) ? rows : [];
  const isOn = (r) => !!(r.ends_at && new Date(r.ends_at) > new Date());

  // Sections: one per group (a student in several groups shows in each), plus "No group".
  const sections = useMemo(() => {
    const byUser = new Map();
    members.forEach((m) => { if (!byUser.has(m.user_id)) byUser.set(m.user_id, []); byUser.get(m.user_id).push(m.group_code); });
    const out = groups.map((g) => ({ code: g.code, name: g.name || g.code, rows: [] }));
    const idx = new Map(out.map((x, i) => [x.code, i]));
    const none = { code: '__none', name: null, rows: [] };
    list.forEach((r) => {
      const codes = (byUser.get(r.user_id) || []).filter((c) => idx.has(c));
      if (!codes.length) none.rows.push(r);
      else codes.forEach((c) => out[idx.get(c)].rows.push(r));
    });
    return [...out, none].filter((x) => x.rows.length > 0);
  }, [groups, members, list]);

  const visible = gFilter === 'all' ? sections : sections.filter((x) => x.code === gFilter);
  const searching = q.trim().length > 0;
  const toggle = (code) => setClosed((c) => { const n = new Set(c); if (n.has(code)) n.delete(code); else n.add(code); return n; });
  const allClosed = visible.length > 0 && visible.every((x) => closed.has(x.code));
  const nOn = list.filter(isOn).length;
  const secName = (x) => x.name || t('No group');

  const tableFor = (rs) => (
    <table className="pay-table">
      <thead><tr><th>{t('Student')}</th><th>{t('Access until')}</th><th></th></tr></thead>
      <tbody>
        {rs.map((r) => {
          const on = isOn(r);
          return (
            <tr key={r.user_id}>
              <td data-label={t('Student')} className="pay-buyer"><b>{r.full_name || '—'}</b><div className="hint">{r.email}</div></td>
              <td data-label={t('Access until')}>{on ? <span className="pay-pill ok">{day(r.ends_at)}</span> : <span className={'pay-pill ' + (r.ends_at ? 'bad' : 'mute')}>{r.ends_at ? t('Expired') + ' ' + day(r.ends_at) : t('Never paid')}</span>}</td>
              <td className="pay-actions">
                <button className="btn btn-gold btn-sm" onClick={() => { setGrant(r); setMonths(1); }}>{t('Grant access')}</button>
                {isSuper && on && <button className="btn btn-danger btn-sm" onClick={() => revoke(r)}>{t('Revoke')}</button>}
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );

  return (
    <>
      <div className="panel pay-filters">
        <SearchBox value={q} onChange={setQ} placeholder={t('Search students by name or email')} />
        {sections.length > 0 && (
          <div className="acc-chips" role="tablist" aria-label={t('Groups')}>
            <button type="button" className={'acc-chip' + (gFilter === 'all' ? ' is-active' : '')} onClick={() => setGFilter('all')}>{t('All')}<span className="acc-chip-n">{list.length}</span></button>
            {sections.map((x) => (
              <button key={x.code} type="button" className={'acc-chip' + (gFilter === x.code ? ' is-active' : '')} onClick={() => setGFilter(x.code)}>{secName(x)}<span className="acc-chip-n">{x.rows.length}</span></button>
            ))}
          </div>
        )}
        <div className="acc-toolbar">
          <span className="hint"><b>{list.length}</b> {t('students')} · <b>{nOn}</b> {t('with access')}</span>
          {visible.length > 1 && <button type="button" className="btn btn-ghost btn-sm" onClick={() => setClosed(allClosed ? new Set() : new Set(visible.map((x) => x.code)))}>{allClosed ? t('Expand all') : t('Collapse all')}</button>}
        </div>
      </div>

      {rows === null ? (
        <div className="panel pay-table-wrap"><table className="pay-table"><tbody>{[0, 1, 2].map((i) => <tr key={i} className="pay-skel">{[0, 1, 2].map((j) => <td key={j}><span className="pay-skel-bar" /></td>)}</tr>)}</tbody></table></div>
      ) : rows.error ? (
        <div className="panel pay-table-wrap"><div className="pay-empty"><div>{rows.error}</div></div></div>
      ) : visible.length === 0 ? (
        <div className="panel pay-table-wrap"><div className="pay-empty">{IC_INBOX}<div>{t('No students.')}</div></div></div>
      ) : visible.map((x) => {
        const open = searching || !closed.has(x.code);
        const on = x.rows.filter(isOn).length;
        return (
          <div key={x.code} className={'panel acc-group' + (open ? ' is-open' : '')}>
            <button type="button" className="acc-group-head" aria-expanded={open} onClick={() => toggle(x.code)}>
              <span className="acc-group-ic">{IC_GROUP}</span>
              <span className="acc-group-title"><b>{secName(x)}</b><span>{x.rows.length} {t('students')} · {on} {t('with access')}</span></span>
              <span className="acc-caret">{IC_CARET}</span>
            </button>
            <div className="acc-group-body">{open && tableFor(x.rows)}</div>
          </div>
        );
      })}

      <Modal open={!!grant} onClose={() => setGrant(null)} style={{ maxWidth: 440 }}>
        {grant && (<>
          <h3>{t('Grant access')}</h3>
          <p className="hint" style={{ color: 'var(--text)' }}>{grant.full_name || grant.email}</p>
          <div className="field"><label>{t('Months')}</label><select style={{ width: '100%' }} value={months} onChange={(e) => setMonths(e.target.value)}>{[1, 2, 3, 6, 12, 24].map((m) => <option key={m} value={m}>{m}</option>)}</select></div>
          <div className="field"><label>{t('Reason (internal)')}</label><input style={{ width: '100%' }} maxLength={300} value={note} onChange={(e) => setNote(e.target.value)} /></div>
          <div className="modal-actions"><button className="btn btn-ghost" onClick={() => setGrant(null)}>{t('Cancel')}</button><button className="btn btn-gold" disabled={busy} onClick={doGrant}>{t('Grant')}</button></div>
        </>)}
      </Modal>
    </>
  );
}

/* ------------------------------------------------------------------ settings (main admin) */
const SET_SECTIONS = [
  ['switches', 'Switches', 'IC_TOGGLE', true],
  ['business', 'Business & tax', 'IC_BUILDING', true],
  ['bank', 'Bank transfer', 'IC_BANK', true],
  ['pricing', 'Pricing & rates', 'IC_TAG', false],
];

function SettingsTab() {
  const { t, toast, askConfirm } = usePanel();
  const [s, setS] = useState(null);
  const [orig, setOrig] = useState('');
  const [plans, setPlans] = useState([]);
  const [fx, setFx] = useState([]);
  const [busy, setBusy] = useState(false);
  const [sec, setSec] = useState('switches');

  const load = useCallback(async () => {
    const [a, b, c] = await Promise.all([
      supabase.rpc('admin_get_settings'),
      supabase.from('plans').select('id, title, months, price_usd_cents, active').order('sort'),
      supabase.from('fx_rates').select('currency, per_usd, source, updated_at').order('currency'),
    ]);
    if (a.data) { setS(a.data); setOrig(JSON.stringify(a.data)); }
    setPlans(b.data || []); setFx(c.data || []);
  }, []);
  useEffect(() => { load(); }, [load]);

  const set = (k, v) => setS((x) => ({ ...x, [k]: v }));
  const dirty = !!s && JSON.stringify(s) !== orig;
  async function save(e) {
    e.preventDefault();
    const save1 = async () => {
      setBusy(true);
      const { error } = await supabase.rpc('admin_save_settings', { p: s });
      setBusy(false);
      if (error) { toast(error.message, 'err'); return; }
      toast(t('Settings saved.'), 'ok'); load();
    };
    if (s.payments_enforced) {
      askConfirm(t('Payments are ON'), t('Students without an active plan will lose access to lessons, tasks, exams and the library. Save?'), save1);
    } else save1();
  }
  async function savePlan(p) {
    const { error } = await supabase.rpc('admin_save_plan', { p_id: p.id, p_title: p.title, p_months: Number(p.months), p_usd_cents: Math.round(Number(p.price_usd_cents)), p_active: !!p.active });
    if (error) toast(error.message, 'err'); else toast(t('Plan saved.'), 'ok');
  }
  async function saveFx(r) {
    const { error } = await supabase.rpc('admin_set_fx', { p_currency: r.currency, p_rate: Number(r.per_usd), p_source: 'manual' });
    if (error) toast(error.message, 'err'); else toast(t('Rate saved.'), 'ok');
  }
  async function refreshFx() {
    setBusy(true);
    const { data, error } = await supabase.functions.invoke('fx-refresh', { body: {} });
    setBusy(false);
    if (error || (data && data.error)) { toast(t('Could not update rates.'), 'err'); return; }
    toast(t('Rates updated.'), 'ok'); load();
  }
  async function reminders() {
    const { data, error } = await supabase.rpc('send_expiry_reminders');
    if (error) toast(error.message, 'err'); else toast(`${t('Reminders sent')}: ${data}`, 'ok');
  }
  const upPlan = (i, patch) => setPlans((a) => a.map((x, j) => (j === i ? { ...x, ...patch } : x)));
  const upFx = (i, patch) => setFx((a) => a.map((x, j) => (j === i ? { ...x, ...patch } : x)));

  if (!s) return <div className="panel"><p className="hint">{t('Loading…')}</p></div>;

  const ICONS = { IC_TOGGLE, IC_BUILDING, IC_BANK, IC_TAG };
  const text = (k, label, props = {}) => (
    <div className="field set-field"><label>{t(label)}</label><input style={{ width: '100%' }} value={s[k] ?? ''} onChange={(e) => set(k, e.target.value)} {...props} /></div>
  );
  const toggle = (k, label, hint, icon) => (
    <button type="button" role="switch" aria-checked={!!s[k]} className={'set-toggle' + (s[k] ? ' is-on' : '')} onClick={() => set(k, !s[k])}>
      <span className="set-toggle-ic">{icon}</span>
      <span className="set-toggle-body"><b>{t(label)}</b>{hint && <small>{t(hint)}</small>}</span>
      <span className="set-state">{s[k] ? t('ON') : t('OFF')}</span>
      <Switch on={!!s[k]} />
    </button>
  );
  const noMethod = !!s.payments_enforced && !s.paymob_enabled && !s.bank_transfer_enabled;

  return (
    <div className="set-wrap">
      <div className="set-nav" role="tablist">
        {SET_SECTIONS.map(([k, l, ic, isForm]) => (
          <button key={k} type="button" role="tab" aria-selected={sec === k} className={'set-nav-btn' + (sec === k ? ' is-active' : '')} onClick={() => setSec(k)}>
            <span className="set-nav-ic">{ICONS[ic]}</span><span className="set-nav-lbl">{t(l)}</span>
            {isForm && dirty && sec !== k ? <i className="set-dot" aria-hidden="true" /> : null}
          </button>
        ))}
      </div>

      {sec !== 'pricing' ? (
        <form onSubmit={save} className="set-form">
          {sec === 'switches' && (
            <div className="panel set-card set-anim">
              <div className="set-card-head"><h3>{t('Switches')}</h3></div>
              <div className="set-toggles">
                {toggle('payments_enforced', 'Require payment', 'OFF = everything stays open (use while testing). ON = students need an active plan.', IC_SHIELD)}
                {toggle('paymob_enabled', 'Card payments (Paymob)', 'Turn on only after the Paymob keys are set on the server.', IC_CARD)}
                {toggle('bank_transfer_enabled', 'Bank transfer', 'Students upload a receipt; you approve it in Orders.', IC_BANK)}
              </div>
              {noMethod && <div className="set-alert" role="alert">{t('Payments are required but no payment method is on.')}</div>}
            </div>
          )}

          {sec === 'business' && (
            <>
              <div className="panel set-card set-anim">
                <div className="set-card-head"><h3>{t('Seller details (printed on invoices)')}</h3></div>
                <div className="set-grid">{text('seller_name', 'Legal name')}{text('seller_tax_id', 'Tax registration no.')}</div>
                {text('seller_address', 'Address')}
                <div className="set-grid">{text('seller_email', 'Billing email')}{text('seller_country', 'Country (2 letters)', { maxLength: 2 })}</div>
              </div>
              <div className="panel set-card set-anim">
                <div className="set-card-head"><h3>{t('Charge currency and tax')}</h3></div>
                <div className="set-grid">{text('charge_currency', 'Charge currency (e.g. EGP)', { maxLength: 3 })}{text('tax_label', 'Tax name (e.g. VAT)')}</div>
                <div className="set-grid">
                  <div className="field set-field"><label>{t('Tax rate %')}</label><input type="number" min="0" max="100" step="0.01" style={{ width: '100%' }} value={s.tax_rate ?? 0} onChange={(e) => set('tax_rate', e.target.value)} /></div>
                  <div className="field set-field"><label>{t('Refund window (days)')}</label><input type="number" min="0" max="365" style={{ width: '100%' }} value={s.refund_days ?? 14} onChange={(e) => set('refund_days', e.target.value)} /></div>
                </div>
                {toggle('prices_include_tax', 'Prices already include tax', 'ON: the tax is taken out of the price. OFF: the tax is added on top. Ask your accountant.', IC_PERCENT)}
                <div className="set-grid" style={{ marginTop: 14 }}>{text('tax_note', 'Note printed on invoices')}{text('terms_version', 'Terms version (change it when the legal texts change)')}</div>
              </div>
            </>
          )}

          {sec === 'bank' && (
            <div className="panel set-card set-anim">
              <div className="set-card-head"><h3>{t('Bank transfer instructions')}</h3></div>
              <div className="set-bank">
                <div className="field set-field"><textarea rows={8} style={{ width: '100%' }} value={s.bank_instructions ?? ''} onChange={(e) => set('bank_instructions', e.target.value)} placeholder={'Bank name\nAccount name\nIBAN\nSWIFT'} /></div>
                <div className="set-preview">
                  <div className="set-preview-lbl">{t('What students see')}</div>
                  <div className="set-preview-box">{(s.bank_instructions || '').trim() || '—'}</div>
                </div>
              </div>
              <p className="hint">{t('Shown to signed-in students at checkout. Add the bank name, account holder, IBAN and SWIFT.')}</p>
            </div>
          )}

          <div className={'set-savebar' + (dirty ? ' is-dirty' : '')}>
            <span className="set-savebar-msg"><i className="set-dot" aria-hidden="true" />{dirty ? t('Unsaved changes') : t('All changes saved')}</span>
            <span className="set-savebar-btns">
              {dirty && <button type="button" className="btn btn-ghost btn-sm" disabled={busy} onClick={() => setS(JSON.parse(orig))}>{t('Discard changes')}</button>}
              <button type="submit" className="btn btn-gold" disabled={busy || !dirty}>{t('Save settings')}</button>
            </span>
          </div>
        </form>
      ) : (
        <>
          <div className="panel set-card set-anim">
            <div className="set-card-head"><h3>{t('Plans (price in US dollars)')}</h3></div>
            <div className="set-plans">
              {plans.map((p, i) => (
                <div key={p.id} className={'set-plan' + (p.active ? '' : ' is-off')}>
                  <div className="set-plan-top">
                    <span className="pay-plan">{p.id}</span>
                    <span className="set-plan-sw"><span className="hint">{p.active ? t('Active') : t('Inactive')}</span><Switch on={!!p.active} onClick={() => upPlan(i, { active: !p.active })} /></span>
                  </div>
                  <div className="field set-field"><label>{t('Title')}</label><input className="u-input" style={{ width: '100%' }} value={p.title} onChange={(e) => upPlan(i, { title: e.target.value })} /></div>
                  <div className="set-grid">
                    <div className="field set-field"><label>{t('Months')}</label><input className="u-input" type="number" min="1" max="36" style={{ width: '100%' }} value={p.months} onChange={(e) => upPlan(i, { months: e.target.value })} /></div>
                    <div className="field set-field"><label>{t('Price (USD)')}</label><input className="u-input" type="number" min="0" step="0.01" style={{ width: '100%' }} value={p.price_usd_cents / 100} onChange={(e) => upPlan(i, { price_usd_cents: Number(e.target.value) * 100 })} /></div>
                  </div>
                  <button type="button" className="btn btn-gold btn-sm set-plan-save" onClick={() => savePlan(p)}>{t('Save')}</button>
                </div>
              ))}
            </div>
          </div>

          <div className="panel set-card set-anim">
            <div className="set-card-head"><h3>{t('Exchange rates (units per 1 USD)')}</h3>
              <button type="button" className="btn btn-gold btn-sm" disabled={busy} onClick={refreshFx}>{IC_REFRESH}{t('Update rates')}</button></div>
            <p className="hint">{t('Rates are used to show local prices and to compute the charge currency. Update them before going live and from time to time.')}</p>
            <div className="set-fx">
              {fx.map((r, i) => (
                <div key={r.currency} className="set-fx-row">
                  <div className="set-fx-cur"><b>{r.currency}</b><span className="hint">{r.source}{r.updated_at ? ' · ' + day(r.updated_at) : ''}</span></div>
                  <input className="u-input" type="number" min="0" step="any" value={r.per_usd} onChange={(e) => upFx(i, { per_usd: e.target.value })} aria-label={r.currency} />
                  <button type="button" className="btn btn-ghost btn-sm" onClick={() => saveFx(r)}>{t('Save')}</button>
                </div>
              ))}
            </div>
          </div>

          <div className="panel set-card set-anim">
            <div className="set-card-head"><h3>{t('Renewal reminders')}</h3></div>
            <div className="set-remind">
              <span className="set-toggle-ic">{IC_BELL}</span>
              <p className="hint">{t('Sends a notice to students whose access ends within 3 days. Can also run daily (see the migration file for the pg_cron line).')}</p>
              <button type="button" className="btn btn-ghost btn-sm" onClick={reminders}>{t('Send reminders now')}</button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
