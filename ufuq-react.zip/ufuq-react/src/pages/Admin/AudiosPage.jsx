import { safeHttpUrl } from '../../lib/safeUrl';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { supabase } from '../../lib/supabaseClient';
import useLiveRefresh from '../../lib/liveRefresh';
import { usePanel } from '../../components/panel/PanelContext';
import { EditIcon, Modal, Switch, TrashIcon } from '../../components/panel/ui';
import { EmptyState, Ico, PageHeader, SearchInput, Segmented, Skeleton, StatCard } from './ui';
import {
  detectDurationFromFile, detectDurationSeconds, extractDriveFileId, fmtDate, groupLetterFor,
  parseDurationInput, secondsToClock, uploadToAudioWorker,
} from '../../lib/panelUtils';

export default function AudiosPage() {
  const { t, toast, askConfirm, currentGroup: g, isSuper } = usePanel();
  const code = g ? g.code : null;
  const [scope, setScopeRaw] = useState('group');
  const setScope = (v) => setScopeRaw(isSuper ? v : 'group'); // ordinary admins only ever work with their own group's audios
  const [audios, setAudios] = useState(null);   // null = loading, {error}|[]
  const [modal, setModal] = useState({ open: false, audio: null });

  const load = useCallback(async (opts) => {
    const silent = !!(opts && opts.silent);
    setAudios(null);
    let query = supabase.from('audio_lessons').select('*').order('published_at', { ascending: false });
    if (scope === 'global') {
      query = query.is('group_code', null);
    } else {
      if (!code) { setAudios('nogroup'); return; }
      query = query.eq('group_code', code);
    }
    const { data, error } = await query;
    if (error) { setAudios({ error: error.message }); return; }
    setAudios(data || []);
  }, [scope, code]);

  useEffect(() => { load(); }, [load]);
  useLiveRefresh(load);

  function del(a) {
    askConfirm(t('Delete audio'), t('This audio lesson will be deleted. Continue?'), async () => {
      const { error } = await supabase.from('audio_lessons').delete().eq('id', a.id);
      if (error) { toast(error.message, 'err'); return; }
      toast(t('Audio deleted.'), 'ok');
      load();
    });
  }

  const [q, setQ] = useState('');
  const list = Array.isArray(audios) ? audios : [];
  const shown = useMemo(() => { const s2 = q.trim().toLowerCase(); return s2 ? list.filter((a) => (a.title || '').toLowerCase().includes(s2)) : list; }, [list, q]);
  const totalSec = list.reduce((n, a) => n + (a.duration_seconds || 0), 0);
  const badLinks = list.filter((a) => !extractDriveFileId(a.drive_url)).length;
  const loading = audios === null;
  const newAudio = () => { if (scope === 'group' && !code) { toast(t('Select a group first.'), 'err'); return; } setModal({ open: true, audio: null }); };

  return (
    <section className="page active" id="page-audios">
      <PageHeader title={t('Audio Lessons')} sub={t('Add an audio lesson to a group, or make it available to everyone (global).')}>
        <button className="btn btn-gold" id="newAudioBtn" onClick={newAudio}><Ico><path d="M12 5v14M5 12h14" /></Ico>{t('New audio')}</button>
      </PageHeader>

      <div className="a-stats a-stats-sm">
        <StatCard loading={loading} tone="var(--gold)" label={t('Audio lessons')} value={list.length} icon={<Ico><path d="M9 18V5l12-2v13" /><circle cx="6" cy="18" r="3" /><circle cx="18" cy="16" r="3" /></Ico>} />
        <StatCard loading={loading} tone="var(--a-blue)" label={t('Total duration')} value={totalSec ? secondsToClock(totalSec) : '\u2014'} icon={<Ico><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></Ico>} />
        {badLinks > 0 && <StatCard tone="var(--a-rose)" label={t('Invalid link')} value={badLinks} icon={<Ico><path d="M12 9v4M12 17h.01" /><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z" /></Ico>} />}
      </div>

      <div className="a-toolbar a-toolbar-solo">
        <SearchInput value={q} onChange={setQ} placeholder={t('Search audio…')} />
        {isSuper && <Segmented value={scope} onChange={setScope} options={[{ value: 'group', label: t('Selected group') }, { value: 'global', label: t('Global (no group)') }]} />}
        {g && scope === 'group' && <span className="a-pill">{g.name}</span>}
      </div>

      <div className="a-list" id="audiosBody">
        {loading ? [0, 1, 2].map((i) => <Skeleton key={i} h={72} style={{ borderRadius: 16 }} />)
          : audios === 'nogroup' ? <div className="panel"><EmptyState title={t('Select a group')} /></div>
          : audios.error ? <div className="panel"><EmptyState title={audios.error} /></div>
          : list.length === 0 ? <div className="panel"><EmptyState title={t('No audio lessons added yet.')} hint={t('Upload a file or paste a Google Drive link.')}><button className="btn btn-gold btn-sm" onClick={newAudio}>{t('+ New audio')}</button></EmptyState></div>
          : shown.length === 0 ? <div className="panel"><EmptyState title={t('No results')} /></div>
          : shown.map((a, i) => {
            const driveOk = !!extractDriveFileId(a.drive_url);
            return (
              <article className="a-row" key={a.id}>
                <span className="a-row-ico"><Ico><path d="M3 18v-6a9 9 0 0 1 18 0v6" /><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z" /></Ico></span>
                <div className="a-row-main">
                  <b>{a.title}</b>
                  <small>{fmtDate(a.published_at)}{!a.group_code ? ' · ' + t('Global') : ''}{a.description ? ' · ' + a.description : ''}</small>
                </div>
                <span className="a-dur">{a.duration_seconds ? secondsToClock(a.duration_seconds) : '\u2014'}</span>
                {driveOk
                  ? <a className="btn btn-ghost btn-sm" href={safeHttpUrl(a.drive_url) || '#'} target="_blank" rel="noopener noreferrer"><Ico><path d="M5 3l14 9-14 9V3z" /></Ico>{t('Listen')}</a>
                  : <span className="chip chip-inactive" title={t('Could not read a Google Drive file id from this link.')}>{t('Invalid link')}</span>}
                <div className="a-row-act">
                  <button className="icon-btn" title={t('Edit')} aria-label={t('Edit')} onClick={() => setModal({ open: true, audio: a })}><EditIcon /></button>
                  <button className="icon-btn a-danger" title={t('Delete')} aria-label={t('Delete')} onClick={() => del(a)}><TrashIcon /></button>
                </div>
              </article>
            );
          })}
      </div>
      <AudioModal open={modal.open} audio={modal.audio} scope={scope} group={g} onClose={() => setModal((m) => ({ ...m, open: false }))} onSaved={load} />
    </section>
  );
}

function AudioModal({ open, audio, scope, group, onClose, onSaved }) {
  const { t, toast } = usePanel();
  const fileRef = useRef(null);
  const [f, setF] = useState({ title: '', desc: '', url: '', duration: '', isGlobal: false });
  const [error, setError] = useState('');      // '' = hidden
  const [durHint, setDurHint] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    setF({
      title: audio ? audio.title : '', desc: audio ? (audio.description || '') : '', url: audio ? (audio.drive_url || '') : '',
      duration: audio && audio.duration_seconds ? secondsToClock(audio.duration_seconds) : '',
      isGlobal: audio ? !audio.group_code : scope === 'global',
    });
    setError(''); setDurHint('');
    if (fileRef.current) fileRef.current.value = '';
  }, [open, audio, scope]);

  async function submit(e) {
    e.preventDefault();
    setError('');
    const file = fileRef.current && fileRef.current.files[0];
    setSaving(true);
    let finalUrl = '';
    let durationSeconds = parseDurationInput(f.duration);

    if (file) {
      const letter = groupLetterFor(group);
      if (!letter) { setError(t('Select a group whose name ends in A–G first, or paste a Drive link instead.')); setSaving(false); return; }
      setError(t('Uploading…'));
      const up = await uploadToAudioWorker(letter, file);
      if (!up.ok) { setError(up.error); setSaving(false); return; }
      finalUrl = up.url;
      setError('');
      if (durationSeconds === null) {
        setDurHint(t('Detecting duration…'));
        durationSeconds = await detectDurationFromFile(file);
        setDurHint(durationSeconds ? t('Detected:') + ' ' + secondsToClock(durationSeconds) : t('Could not detect the duration — saved without it.'));
      }
    } else {
      const driveUrl = f.url.trim();
      const fileId = extractDriveFileId(driveUrl);
      if (!fileId) { setError(t('Pick a file, or paste a valid Google Drive share link.')); setSaving(false); return; }
      finalUrl = driveUrl;
      if (durationSeconds === null) {
        setDurHint(t('Detecting duration…'));
        durationSeconds = await detectDurationSeconds(fileId);
        setDurHint(durationSeconds ? t('Detected:') + ' ' + secondsToClock(durationSeconds) : t('Could not detect the duration — saved without it.'));
      }
    }

    const payload = {
      title: f.title.trim(), description: f.desc.trim(), drive_url: finalUrl, duration_seconds: durationSeconds,
      group_code: f.isGlobal ? null : (group ? group.code : null),
    };
    try {
      const result = audio
        ? await supabase.from('audio_lessons').update(payload).eq('id', audio.id)
        : await supabase.from('audio_lessons').insert(payload);
      if (result.error) throw result.error;
      toast(audio ? t('Audio updated.') : t('New audio added.'), 'ok');
      onClose();
      onSaved();
    } catch (err) { setError(err.message); } finally { setSaving(false); }
  }

  return (
    <Modal open={open} onClose={onClose} id="audioModalOverlay">
      <h3 id="audioModalTitle">{audio ? t('Edit audio') : t('New audio')}</h3>
      <form id="audioForm" onSubmit={submit}>
        <div className="field"><label>{t('Title')}</label><input type="text" id="audioTitle" required value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
        <div className="field"><label>{t('Description')}</label><textarea id="audioDesc" value={f.desc} onChange={(e) => setF({ ...f, desc: e.target.value })}></textarea></div>
        <div className="field">
          <label>{t('Audio file')}</label>
          <input type="file" id="audioFile" accept="audio/*" ref={fileRef} />
          <p className="hint">{t('Pick a file to upload it automatically — or leave this empty and paste a Google Drive link below instead.')}</p>
        </div>
        <div className="field-row">
          <div className="field">
            <label>{t('Audio link (Google Drive) — optional if a file is picked above')}</label>
            <input type="url" id="audioUrl" placeholder="https://drive.google.com/file/d/..." value={f.url} onChange={(e) => setF({ ...f, url: e.target.value })} />
          </div>
          <div className="field">
            <label>{t('Duration (optional)')}</label>
            <input type="text" id="audioDuration" placeholder="auto" autoComplete="off" value={f.duration} onChange={(e) => setF({ ...f, duration: e.target.value })} />
            <p className="hint">{t('Leave empty — it is detected automatically.')}</p>
            <p className="hint" id="audioDurationHint">{durHint}</p>
          </div>
        </div>
        <div className="field">
          <label className="att-toggle" style={{ cursor: 'pointer' }} onClick={() => setF({ ...f, isGlobal: !f.isGlobal })}>
            <Switch on={f.isGlobal} id="audioGlobalSwitch" />
            {t('Global audio (not tied to a group, visible to everyone)')}
          </label>
        </div>
        <p className="hint" id="audioFormError" style={{ display: error ? 'block' : 'none', color: 'var(--danger-bright)' }}>{error}</p>
        <div className="modal-actions">
          <button type="button" className="btn btn-ghost" onClick={onClose}>{t('Cancel')}</button>
          <button type="submit" className="btn btn-gold" id="audioSaveBtn" disabled={saving}>{t('Save')}</button>
        </div>
      </form>
    </Modal>
  );
}
