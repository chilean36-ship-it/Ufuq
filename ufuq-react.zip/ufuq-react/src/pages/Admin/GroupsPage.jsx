import { safeHttpUrl } from '../../lib/safeUrl';
import { useEffect, useMemo, useState } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { usePanel } from '../../components/panel/PanelContext';
import { EditIcon, Modal, Switch } from '../../components/panel/ui';
import { Avatar, EmptyState, Ico, PageHeader, SearchInput, Segmented, StatCard } from './ui';
import { DAYS, dayLabel } from '../../lib/panelUtils';
import useJoinCodes from '../../lib/useJoinCodes';

const TIME_RE = /^([01][0-9]|2[0-3]):[0-5][0-9]$/;

export default function GroupsPage() {
  const { t, myGroups, toast, reloadGroups } = usePanel();
  const [modal, setModal] = useState({ open: false, group: null });
  const { joinCodes } = useJoinCodes(myGroups.map((g) => g.code));
  const [counts, setCounts] = useState(null);
  const [q, setQ] = useState('');
  const [fStatus, setFStatus] = useState('all');
  const [fType, setFType] = useState('all');
  const [view, setView] = useState(() => { try { return localStorage.getItem('ufuq-admin-groups-view') || 'cards'; } catch (e) { return 'cards'; } });
  const setViewSaved = (v) => { setView(v); try { localStorage.setItem('ufuq-admin-groups-view', v); } catch (e) { /* ignore */ } };

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (myGroups.length === 0) { setCounts({}); return; }
      const { data } = await supabase.from('group_members').select('group_code').in('group_code', myGroups.map((g) => g.code));
      const c = {}; (data || []).forEach((m) => { c[m.group_code] = (c[m.group_code] || 0) + 1; });
      if (!cancelled) setCounts(c);
    })();
    return () => { cancelled = true; };
  }, [myGroups]);

  const stats = useMemo(() => ({
    all: myGroups.length, active: myGroups.filter((g) => g.is_active).length, inactive: myGroups.filter((g) => !g.is_active).length,
    cls: myGroups.filter((g) => g.type !== 'individual').length, ind: myGroups.filter((g) => g.type === 'individual').length,
  }), [myGroups]);

  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    return myGroups.filter((g) => (fStatus === 'all' || (fStatus === 'active') === !!g.is_active)
      && (fType === 'all' || (fType === 'individual') === (g.type === 'individual'))
      && (!s || (g.name || '').toLowerCase().includes(s) || String(g.code).includes(s)));
  }, [myGroups, q, fStatus, fType]);

  async function toggleActive(g) {
    const { error } = await supabase.from('groups').update({ is_active: !g.is_active }).eq('code', g.code);
    if (error) { toast(error.message, 'err'); return; }
    toast(t('Group updated.'), 'ok');
    reloadGroups({ silent: true });
  }
  async function copyCode(g) {
    const text = String(joinCodes[g.code] || '');
    if (!text) { toast(t('This group has no join code yet.'), 'err'); return; }
    try { await navigator.clipboard.writeText(text); toast(t('Copied') + ': ' + text, 'ok'); } catch (e) { toast(text, 'ok'); }
  }
  const openNew = () => setModal({ open: true, group: null });
  const openEdit = (g) => setModal({ open: true, group: g });
  const TypeChip = ({ g }) => (g.type === 'individual' ? <span className="chip chip-type-individual">{t('Individual')}</span> : <span className="chip chip-type-class">{t('Class')}</span>);
  const zoomLink = (g) => (g.zoom_link ? <a href={safeHttpUrl(g.zoom_link) || '#'} target="_blank" rel="noopener noreferrer" className="a-link">Zoom ↗</a> : null);

  return (
    <section className="page active" id="page-groups">
      <PageHeader title={t('Groups')} sub={t('Create groups and manage their schedule and Zoom link.')}>
        <button className="btn btn-gold" id="newGroupBtn" onClick={openNew}><Ico><path d="M12 5v14M5 12h14" /></Ico>{t('New group')}</button>
      </PageHeader>

      <div className="a-stats a-stats-sm">
        <StatCard tone="var(--gold)" label={t('All your groups')} value={stats.all} icon={<Ico><path d="m12 2 10 5-10 5L2 7l10-5Z" /><path d="m2 17 10 5 10-5M2 12l10 5 10-5" /></Ico>} onClick={() => { setFStatus('all'); setFType('all'); }} />
        <StatCard tone="var(--a-green)" label={t('Active')} value={stats.active} icon={<Ico><path d="M20 6 9 17l-5-5" /></Ico>} onClick={() => setFStatus('active')} />
        <StatCard tone="var(--a-blue)" label={t('Class')} value={stats.cls} icon={<Ico><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" /></Ico>} onClick={() => setFType('class')} />
        <StatCard tone="var(--a-violet)" label={t('Individual')} value={stats.ind} icon={<Ico><circle cx="12" cy="7" r="4" /><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /></Ico>} onClick={() => setFType('individual')} />
      </div>

      <div className="a-toolbar a-toolbar-solo">
        <SearchInput value={q} onChange={setQ} placeholder={t('Search groups…')} />
        <Segmented value={fStatus} onChange={setFStatus} options={[{ value: 'all', label: t('All') }, { value: 'active', label: t('Active'), count: stats.active }, { value: 'inactive', label: t('Inactive'), count: stats.inactive }]} />
        <Segmented value={fType} onChange={setFType} options={[{ value: 'all', label: t('All') }, { value: 'class', label: t('Class') }, { value: 'individual', label: t('Individual') }]} />
        <div className="a-toolbar-end">
          <div className="a-seg" role="group" aria-label={t('View')}>
            <button type="button" className={view === 'cards' ? 'on' : ''} onClick={() => setViewSaved('cards')} aria-label={t('Cards')}><Ico><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></Ico></button>
            <button type="button" className={view === 'table' ? 'on' : ''} onClick={() => setViewSaved('table')} aria-label={t('Table')}><Ico><path d="M3 6h18M3 12h18M3 18h18" /></Ico></button>
          </div>
        </div>
      </div>

      {myGroups.length === 0 ? (
        <div className="panel"><EmptyState title={t('No groups yet')} hint={t('You don\'t have any groups yet. Click "+ New group" to add one.')}>
          <button className="btn btn-gold btn-sm" onClick={openNew}>{t('+ New group')}</button></EmptyState></div>
      ) : list.length === 0 ? (
        <div className="panel"><EmptyState title={t('No groups match your filters.')}><button className="btn btn-ghost btn-sm" onClick={() => { setQ(''); setFStatus('all'); setFType('all'); }}>{t('Clear filters')}</button></EmptyState></div>
      ) : view === 'cards' ? (
        <div className="a-cards" id="groupsBody">
          {list.map((g) => {
            const ind = g.type === 'individual';
            const days = Array.isArray(g.schedule_days) ? g.schedule_days : [];
            return (
              <article className={'a-gcard' + (g.is_active ? '' : ' is-off')} key={g.code}>
                <header>
                  <Avatar name={g.name || '?'} size={42} />
                  <div className="a-gcard-t"><h4>{g.name}</h4><TypeChip g={g} /></div>
                  <button type="button" className="icon-btn" title={t('Edit')} aria-label={t('Edit')} onClick={() => openEdit(g)}><EditIcon /></button>
                </header>
                <div className="a-gcard-meta">
                  <button type="button" className="a-code" onClick={() => copyCode(g)} title={t('Copy join code')}>
                    <small>{t('Join code')}</small><b>{joinCodes[g.code] || '—'}</b>
                    <Ico><rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></Ico>
                  </button>
                  <div className="a-gcard-num"><b>{counts ? (counts[g.code] || 0) : '…'}</b><small>{t('Students')}</small></div>
                </div>
                <div className="a-gcard-sched">
                  {ind ? <span className="muted">{g.schedule || t('One-on-one slots')}</span>
                    : days.length ? days.map((d, i) => <span className="a-day" key={i}>{dayLabel(t, d.day).slice(0, 3)} <b>{d.time}</b></span>)
                    : <span className="muted">{g.schedule || '\u2014'}</span>}
                </div>
                <footer>
                  <label className="a-switch-row" onClick={(e) => { e.preventDefault(); toggleActive(g); }}>
                    <Switch on={!!g.is_active} /><span>{g.is_active ? t('Active') : t('Inactive')}</span>
                  </label>
                  {zoomLink(g)}
                </footer>
              </article>
            );
          })}
        </div>
      ) : (
        <div className="panel a-flush"><div className="a-table-wrap a-flat">
          <table>
            <thead><tr><th>{t('Name')}</th><th>{t('Join code')}</th><th>{t('Type')}</th><th>{t('Schedule')}</th><th>{t('Students')}</th><th>Zoom</th><th>{t('Status')}</th><th></th></tr></thead>
            <tbody id="groupsBody">
              {list.map((g) => (
                <tr key={g.code}>
                  <td><div className="a-cell-user"><Avatar name={g.name || '?'} size={32} /><b>{g.name}</b></div></td>
                  <td><button type="button" className="a-code a-code-inline" onClick={() => copyCode(g)}>{joinCodes[g.code] || '—'}</button></td>
                  <td><TypeChip g={g} /></td>
                  <td className="muted">{g.type === 'individual' ? '\u2014' : (g.schedule || '\u2014')}</td>
                  <td>{counts ? (counts[g.code] || 0) : '…'}</td>
                  <td>{zoomLink(g) || <span className="muted">{'\u2014'}</span>}</td>
                  <td><label className="a-switch-row" onClick={(e) => { e.preventDefault(); toggleActive(g); }}><Switch on={!!g.is_active} /></label></td>
                  <td className="a-actions"><button className="icon-btn" title={t('Edit')} aria-label={t('Edit')} onClick={() => openEdit(g)}><EditIcon /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div></div>
      )}
      <GroupModal open={modal.open} group={modal.group} onClose={() => setModal((m) => ({ ...m, open: false }))} />
    </section>
  );
}

/** New / Edit group dialog (#groupModalOverlay). */
function GroupModal({ open, group: g, onClose }) {
  const { t, toast, user, reloadGroups } = usePanel();
  const [f, setF] = useState(blank());
  const [days, setDays] = useState([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [typeLocked, setTypeLocked] = useState(false);

  function blank() {
    return { code: '', name: '', schedule: '', zoom: '', active: true, type: 'class', slot: 10, buffer: 2, noShow: 3 };
  }

  // Re-initialise every time the dialog opens (the old openGroupModal()).
  useEffect(() => {
    if (!open) return undefined;
    setF(g ? {
      code: g.code, name: g.name, schedule: g.schedule || '', zoom: g.zoom_link || '', active: !!g.is_active,
      type: g.type === 'individual' ? 'individual' : 'class',
      slot: g.slot_minutes || 10, buffer: g.buffer_minutes || 2, noShow: g.no_show_minutes || 3,
    } : blank());
    setDays(g && Array.isArray(g.schedule_days) ? JSON.parse(JSON.stringify(g.schedule_days)) : []);
    setError('');
    setTypeLocked(false);
    // Once a group has any scheduled individual slots, changing its type would orphan that data — lock the selector.
    let cancelled = false;
    if (g) {
      (async () => {
        const { count } = await supabase.from('group_slots').select('id', { count: 'exact', head: true }).eq('group_code', g.code);
        if (!cancelled) setTypeLocked((count || 0) > 0);
      })();
    }
    return () => { cancelled = true; };
  }, [open, g]);

  const isIndividual = f.type === 'individual';
  const set = (k, v) => setF((cur) => ({ ...cur, [k]: v }));

  const addDay = () => {
    // Default the new row to the first weekday that isn't already used, so teachers can't accidentally end up
    // with two rows for the same day (which used to make Join Class silently check the wrong time).
    const used = days.map((d) => d.day);
    const free = DAYS.find((d) => used.indexOf(d) === -1) || 'Monday';
    setDays([...days, { day: free, time: '18:00' }]);
  };
  const setDay = (i, k, v) => setDays((cur) => cur.map((d, idx) => (idx === i ? { ...d, [k]: v } : d)));

  async function submit(e) {
    e.preventDefault();
    setError('');
    const code = f.code.trim();
    const name = f.name.trim();
    const schedule = f.schedule.trim();
    const zoom_link = f.zoom.trim() || null;
    const type = isIndividual ? 'individual' : 'class';
    const slot_minutes = Math.max(1, parseInt(f.slot, 10) || 10);
    const buffer_minutes = Math.max(0, parseInt(f.buffer, 10) || 0);
    const no_show_minutes = Math.max(1, parseInt(f.noShow, 10) || 3);
    if (!g && !/^[0-9]{5}$/.test(code)) { setError(t('Group code must be exactly 5 digits.')); return; }
    if (type === 'class' && !schedule) { setError(t('Please fill in the schedule text for students.')); return; }
    for (let i = 0; i < days.length; i++) {
      if (!TIME_RE.test(days[i].time)) { setError(t('Invalid time format (must be HH:MM, e.g. 18:00).')); return; }
    }
    // Block saving if two rows target the same weekday — Join Class would check a different (often stale) time.
    const seen = {};
    for (let i = 0; i < days.length; i++) {
      const d = days[i].day;
      if (seen[d]) { setError(t('You have two schedule rows for the same day ({day}). Remove one before saving.').replace('{day}', d)); return; }
      seen[d] = true;
    }
    setSaving(true);
    try {
      const daysToSave = type === 'individual' ? [] : days;
      const fields = { name, schedule, zoom_link, is_active: f.active, schedule_days: daysToSave, type, slot_minutes, buffer_minutes, no_show_minutes };
      if (g) {
        const { error: err } = await supabase.from('groups').update(fields).eq('code', g.code);
        if (err) throw err;
        toast(t('Group updated.'), 'ok');
      } else {
        const { error: err } = await supabase.from('groups').insert({ code, ...fields });
        if (err) throw err;
        const { error: tgErr } = await supabase.from('teacher_groups').insert({ teacher_id: user.id, group_code: code });
        if (tgErr) throw tgErr;
        toast(t('New group created.'), 'ok');
      }
      onClose();
      await reloadGroups();
    } catch (err) {
      setError(err.message || t('An unknown error occurred.'));
    } finally { setSaving(false); }
  }

  return (
    <Modal open={open} onClose={onClose} id="groupModalOverlay">
      <h3 id="groupModalTitle">{g ? t('Edit group') : t('New group')}</h3>
      <form id="groupForm" onSubmit={submit}>
        <div className="field-row">
          <div className="field">
            <label>{t('Group code (number)')}</label>
            <input type="text" id="groupCode" inputMode="numeric" pattern="[0-9]{5}" maxLength={5} required disabled={!!g}
                   value={f.code} onChange={(e) => set('code', e.target.value)} />
          </div>
          <div className="field">
            <label>{t('Group name')}</label>
            <input type="text" id="groupName" required value={f.name} onChange={(e) => set('name', e.target.value)} />
          </div>
        </div>
        <div className="field">
          <label>{t('Group type')}</label>
          <div className="a-typepick" role="radiogroup" id="groupType">
            {[['class', 'Class (everyone joins together)'], ['individual', 'Individual (one-on-one slots)']].map(([v, lbl]) => (
              <button type="button" role="radio" aria-checked={f.type === v} key={v} disabled={typeLocked} className={f.type === v ? 'on' : ''} onClick={() => set('type', v)}>{t(lbl)}</button>
            ))}
          </div>
          <p className="hint" id="groupTypeLockedHint" style={{ display: typeLocked ? 'block' : 'none' }}>
            {t('This group already has scheduled slots, so its type can no longer be changed.')}
          </p>
        </div>
        <div className="field" id="groupScheduleField">
          <label>{t(isIndividual ? 'Schedule text (optional note for students)' : 'Schedule text (shown to students) — e.g. Mon / Thu · 6:00 PM (GMT+5)')}</label>
          <input type="text" id="groupSchedule" required={!isIndividual} value={f.schedule} onChange={(e) => set('schedule', e.target.value)} />
        </div>
        <div className="field">
          <label>{t('Zoom link (optional)')}</label>
          <input type="url" id="groupZoom" placeholder="https://zoom.us/j/..." value={f.zoom} onChange={(e) => set('zoom', e.target.value)} />
        </div>
        <div className="field" id="groupClassDaysField" style={{ display: isIndividual ? 'none' : 'block' }}>
          <label>{t('Class days')}</label>
          <div id="scheduleDaysList">
            {days.length === 0 ? <p className="hint">{t('No days added yet.')}</p> : days.map((d, i) => (
              <div className="schedule-day-row" key={i}>
                <select value={d.day} onChange={(e) => setDay(i, 'day', e.target.value)}>
                  {DAYS.map((dd) => <option key={dd} value={dd}>{dayLabel(t, dd)}</option>)}
                </select>
                <input type="text" value={d.time} placeholder="18:00" style={{ width: 90 }} onChange={(e) => setDay(i, 'time', e.target.value)} />
                <button type="button" className="icon-btn" onClick={() => setDays(days.filter((_, idx) => idx !== i))}>&times;</button>
              </div>
            ))}
          </div>
          <button type="button" className="btn btn-ghost btn-sm" id="addScheduleDay" onClick={addDay}>{t('+ Add day')}</button>
        </div>
        <div className="field-row" id="groupIndividualFields" style={{ display: isIndividual ? 'flex' : 'none' }}>
          <div className="field">
            <label>{t('Slot minutes')}</label>
            <input type="number" id="groupSlotMinutes" min="1" max="180" value={f.slot} onChange={(e) => set('slot', e.target.value)} />
          </div>
          <div className="field">
            <label>{t('Break minutes')}</label>
            <input type="number" id="groupBufferMinutes" min="0" max="60" value={f.buffer} onChange={(e) => set('buffer', e.target.value)} />
          </div>
          <div className="field">
            <label>{t('No-show after minutes')}</label>
            <input type="number" id="groupNoShowMinutes" min="1" max="60" value={f.noShow} onChange={(e) => set('noShow', e.target.value)} />
          </div>
        </div>
        <div className="field">
          <label className="att-toggle" style={{ cursor: 'pointer' }} onClick={() => set('active', !f.active)}>
            <Switch on={f.active} id="groupActiveSwitch" />
            {t('Group is active (students can join)')}
          </label>
        </div>
        <p className="hint" id="groupFormError" style={{ display: error ? 'block' : 'none', color: 'var(--danger-bright)' }}>{error}</p>
        <div className="modal-actions">
          <button type="button" className="btn btn-ghost" onClick={onClose}>{t('Cancel')}</button>
          <button type="submit" className="btn btn-gold" id="groupSaveBtn" disabled={saving}>{t('Save')}</button>
        </div>
      </form>
    </Modal>
  );
}
