import { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { getSessionAndRole, ROLE_PAGES } from '../../lib/auth';
import RequireAuth from '../../components/RequireAuth';
import RequireRole from '../../components/RequireRole';
import NameGate from '../../components/NameGate';
import Dashboard from '../Dashboard/Dashboard';
import Profile from './Profile';

/**
 * `/profile` — students see their profile *inside* the dashboard (same sidebar, topbar and
 * notifications as every other tab); teachers and admins, who have no student cabinet,
 * get the standalone page with a sidebar that fits their role.
 */
export default function ProfileRoute() {
  const [state, setState] = useState({ status: 'checking', role: null });

  useEffect(() => {
    let cancelled = false;
    (async () => {
      let result;
      try { result = await getSessionAndRole(); } catch (e) { result = null; }
      if (cancelled) return;
      setState(result ? { status: 'ok', role: result.role } : { status: 'none', role: null });
    })();
    return () => { cancelled = true; };
  }, []);

  if (state.status === 'checking') return null;
  if (state.status === 'none') return <Navigate to={ROLE_PAGES.login} replace />;
  if (state.role === 'teacher' || state.role === 'admin') {
    return <RequireAuth><NameGate><Profile role={state.role} /></NameGate></RequireAuth>;
  }
  return <RequireRole role="student"><Dashboard initialView="profile" /></RequireRole>;
}
