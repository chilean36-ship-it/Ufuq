import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabaseClient';
import { writeCachedRole } from '../../lib/auth';
import { afterAuthDestination } from '../../lib/payIntent';
import { useI18n } from '../../context/I18nContext';
import LegalConsent from '../Legal/LegalConsent';
import PasswordResetFlow from '../../components/PasswordResetFlow';
import Captcha from '../../components/Captcha';
import { isCaptchaError } from '../../lib/captcha';
import { checkBotGuard, noteAuthFailure, noteAuthSuccess } from '../../lib/botGuard';

/**
 * Sign-in / sign-up / forgot-password modal (port of the #authOverlay logic from app-shell.js).
 *  - email+password sign up / sign in (Supabase Auth)
 *  - Google OAuth (account picker forced)
 *  - reset-by-email
 * After sign-in the user is routed by role: admin -> /admin, teacher -> /teacher, else -> /dashboard.
 */
export default function AuthModal({ open, mode, onModeChange, onClose }) {
  const { t } = useI18n();
  const navigate = useNavigate();

  const [resetOpen, setResetOpen] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [googleBusy, setGoogleBusy] = useState(false);
  const cap = useRef(null);
  const openedAt = useRef(0);
  const [honey, setHoney] = useState('');

  // Every time the modal opens: back to the form view with a clean error line.
  useEffect(() => {
    if (open) { setResetOpen(false); setError(''); }
  }, [open]);
  useEffect(() => { if (open) openedAt.current = Date.now(); }, [open, mode]);

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  const isSignin = mode === 'signin';

  const title = t(isSignin ? 'auth.signinTitle' : 'auth.signupTitle');
  const sub = t(isSignin ? 'auth.signinSub' : 'auth.signupSub');

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    const nameVal = name.trim();
    const emailVal = email.trim().toLowerCase();
    const isSignup = mode !== 'signin';

    const guard = checkBotGuard({ openedAt: openedAt.current, honey });
    if (!guard.ok) {
      setError(guard.reason === 'locked' ? t('captcha.tooMany').replace('{s}', guard.wait) : t('captcha.rejected'));
      return;
    }
    setSubmitting(true);

    try {
      // CAPTCHA: odatda ko'rinmas; token bo'lmasa (yuklanmadi / shubha) forma yuborilmaydi.
      const captchaToken = (cap.current && cap.current.enabled) ? await cap.current.getToken() : undefined;
      if (cap.current && cap.current.enabled && !captchaToken) {
        setError(t('captcha.required'));
        cap.current.reset();
        setSubmitting(false);
        return;
      }
      if (isSignup) {
        const { data, error: err } = await supabase.auth.signUp({
          email: emailVal,
          password,
          options: { captchaToken, data: { full_name: nameVal || 'Student', ...(nameVal ? { profile_name_set: true } : {}) } }, // a name typed here is already confirmed
        });
        if (err) throw err;

        // Agar "Confirm email" yoqilgan bo'lsa, session hali yo'q bo'ladi —
        // foydalanuvchi emailini tasdiqlashi kerak.
        if (!data.session) {
          setError(t('auth.signupConfirm'));
          if (cap.current) cap.current.reset();
          setSubmitting(false);
          return;
        }
        noteAuthSuccess();
        // replace: the back button from the dashboard must not land on the login form again.
        navigate(afterAuthDestination('student', '/dashboard?new=1'), { replace: true });
      } else {
        const { data, error: err } = await supabase.auth.signInWithPassword({ email: emailVal, password, options: { captchaToken } });
        if (err) throw err;
        noteAuthSuccess();

        // Rolga qarab yo'naltirish: 'admin' -> admin panel, 'teacher' -> o'qituvchi
        // paneli, qolgan hollarda (oddiy talaba) -> shaxsiy kabinet (dashboard).
        let destination = '/dashboard';
        try {
          const { data: profileRow } = await supabase
            .from('profiles').select('role').eq('id', data.user.id).maybeSingle();
          if (profileRow && profileRow.role) writeCachedRole(data.user.id, profileRow.role);
          if (profileRow && profileRow.role === 'admin') destination = '/admin';
          else if (profileRow && profileRow.role === 'teacher') destination = '/teacher';
        } catch (roleErr) {
          console.error('Rolni tekshirishda xatolik:', roleErr.message);
        }
        navigate(afterAuthDestination(destination === '/dashboard' ? 'student' : 'staff', destination), { replace: true });
      }
    } catch (err) {
      console.error('Auth error:', err);
      let msg = err.message || t('auth.errGeneric');
      if (isCaptchaError(err)) msg = t('captcha.rejected');
      else if (/already registered|already exists/i.test(msg)) msg = t('auth.errExists');
      else if (/invalid login credentials/i.test(msg)) msg = t('auth.errInvalid');
      else if (/password should be at least/i.test(msg)) msg = t('auth.errShortPass');
      setError(msg);
      if (cap.current) cap.current.reset(); // token bir martalik
      noteAuthFailure();
      setSubmitting(false);
    }
  }

  // ---- Google orqali kirish (Supabase OAuth) ----
  async function handleGoogle() {
    setError('');
    const guard = checkBotGuard({ openedAt: openedAt.current, honey });
    if (!guard.ok) {
      setError(guard.reason === 'locked' ? t('captcha.tooMany').replace('{s}', guard.wait) : t('captcha.rejected'));
      return;
    }
    setGoogleBusy(true);
    try {
      const { error: err } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/dashboard`,
          // Har safar Google'ning akkaunt tanlash oynasi chiqishi uchun.
          queryParams: { prompt: 'select_account' },
        },
      });
      if (err) throw err;
      // Muvaffaqiyatli bo'lsa, brauzer shu yerda Google'ga o'tib ketadi.
    } catch (err) {
      console.error('Google auth error:', err);
      setError(err.message || t('auth.errGoogle'));
      setGoogleBusy(false);
    }
  }

  const submitLabel = submitting
    ? (isSignin ? 'Signing in…' : 'Creating account…')
    : t(isSignin ? 'auth.signinBtn' : 'auth.signupBtn');

  return (
    <div
      className={'auth-overlay' + (open ? ' open' : '')}
      id="authOverlay"
      aria-hidden={!open}
      data-mode={mode}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="auth-modal" role="dialog" aria-modal="true" aria-labelledby="authTitle">
        <button type="button" className="auth-close" id="authClose" aria-label="Close" onClick={onClose}>&times;</button>

        <div className="auth-logo-row">
          <img src="/assets/images/img-01.webp" alt="Ufuq" style={{ height: '26px', width: 'auto' }} />
          <span className="auth-logo-word">Ufuq</span>
        </div>

        <h2 id="authTitle">{title}</h2>
        <p className="auth-sub" id="authSub">{sub}</p>

        {(
          <div id="authFormView">
            <div className="auth-social">
              <button type="button" className="social-btn" id="googleAuthBtn" disabled={googleBusy} onClick={handleGoogle}>
                <svg width="18" height="18" viewBox="0 0 18 18">
                  <path fill="#4285F4" d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.71v2.26h2.9c1.7-1.57 2.7-3.88 2.7-6.61z" />
                  <path fill="#34A853" d="M9 18c2.43 0 4.47-.8 5.96-2.19l-2.9-2.26c-.8.54-1.84.86-3.06.86-2.35 0-4.34-1.59-5.05-3.72H.96v2.33A9 9 0 0 0 9 18z" />
                  <path fill="#FBBC05" d="M3.95 10.69A5.4 5.4 0 0 1 3.67 9c0-.59.1-1.16.28-1.69V4.98H.96A9 9 0 0 0 0 9c0 1.45.35 2.83.96 4.02l2.99-2.33z" />
                  <path fill="#EA4335" d="M9 3.58c1.32 0 2.5.45 3.44 1.35l2.58-2.58C13.46.89 11.43 0 9 0A9 9 0 0 0 .96 4.98l2.99 2.33C4.66 5.17 6.65 3.58 9 3.58z" />
                </svg>
                <span id="googleAuthBtnLabel">{googleBusy ? 'Redirecting…' : t('auth.google')}</span>
              </button>
            </div>

            <div className="auth-divider">{t('auth.or')}</div>

            <form id="authForm" onSubmit={handleSubmit}>
              {!isSignin && (
                <div className="auth-field" id="nameField">
                  <label htmlFor="authName">{t('auth.nameLabel')}</label>
                  <input
                    type="text" id="authName" placeholder={t('auth.namePlaceholder')} required
                    value={name} onChange={(e) => setName(e.target.value)}
                  />
                </div>
              )}
              <div className="auth-field">
                <label htmlFor="authEmail">{t('auth.emailLabel')}</label>
                <input
                  type="email" id="authEmail" placeholder={t('auth.emailPlaceholder')} required
                  value={email} onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div className="auth-field">
                <label htmlFor="authPassword">{t('auth.passwordLabel')}</label>
                <input
                  type="password" id="authPassword" placeholder={t('auth.passwordPlaceholder')} required minLength={8}
                  value={password} onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <div className="hp-field" aria-hidden="true"><label>Website<input type="text" name="website" tabIndex={-1} autoComplete="off" value={honey} onChange={(e) => setHoney(e.target.value)} /></label></div>
              {open && <Captcha ref={cap} key={mode} action={isSignin ? 'login' : 'signup'} />}
              {error && (
                <p className="auth-error" id="authError" style={{ display: 'block', color: '#E5484D', fontSize: '13.5px', margin: '0 0 14px', lineHeight: 1.5 }}>
                  {error}
                </p>
              )}
              <button type="submit" className="auth-submit" id="authSubmit" disabled={submitting}>{submitLabel}</button>
              <LegalConsent id="authTerms" />
            </form>
            {isSignin && (
              <a
                href="#" id="forgotPasswordLink"
                style={{ display: 'block', fontSize: '12.5px', color: 'var(--gold-bright)', marginTop: '8px', textAlign: 'center' }}
                onClick={(e) => { e.preventDefault(); setResetOpen(true); }}
              >
                {t('auth.forgot')}
              </a>
            )}

            <p className="auth-switch">
              <span id="switchPrompt">{t(isSignin ? 'auth.newHere' : 'auth.haveAccount')}</span>{' '}
              <a
                href="#" id="authSwitchLink"
                onClick={(e) => { e.preventDefault(); setError(''); onModeChange(isSignin ? 'signup' : 'signin'); }}
              >
                {t(isSignin ? 'auth.createAccount' : 'auth.signIn')}
              </a>
            </p>
          </div>
        )}

        <PasswordResetFlow open={resetOpen} onClose={() => setResetOpen(false)} initialEmail={email} />
      </div>
    </div>
  );
}
