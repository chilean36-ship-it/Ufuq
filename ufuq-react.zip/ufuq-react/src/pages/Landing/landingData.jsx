/* Static content for the landing page. Text is referenced by i18n key so every language switches live. */

export const NAV_LINKS = [
  { href: '#about-author', key: 'nav.about' },
  { href: '#programs', key: 'nav.programs' },
  { href: '#pricing', key: 'nav.pricing' },
  { href: '#contacts', key: 'nav.contacts' },
];

export const FLOATING_LETTERS = [
  { ch: 'ا', style: { top: '14%', left: '12%', fontSize: '34px', animationDelay: '0.2s' } },
  { ch: 'ب', style: { top: '70%', left: '8%', fontSize: '26px', animationDelay: '1.1s' } },
  { ch: 'ق', style: { top: '20%', right: '6%', fontSize: '30px', animationDelay: '0.6s' } },
  { ch: 'م', style: { top: '76%', right: '10%', fontSize: '22px', animationDelay: '1.6s' } },
];

export const ABOUT_CREDS = [
  { num: '10+', key: 'about.cred1' },
  { num: '1000+', key: 'about.cred2' },
  { num: '2', key: 'about.cred3' },
];

export const EXPLORE_CARDS = [
  { n: '01', t: 'explore.c1t', d: 'explore.c1d' },
  { n: '02', t: 'explore.c2t', d: 'explore.c2d' },
  { n: '03', t: 'explore.c3t', d: 'explore.c3d', soon: true },
  { n: '04', t: 'explore.c4t', d: 'explore.c4d' },
  { n: '05', t: 'explore.c5t', d: 'explore.c5d', soon: true },
  { n: '06', t: 'explore.c6t', d: 'explore.c6d', soon: true },
];

const ARROW = (
  <svg viewBox="0 0 24 24" fill="none" stroke="#EDEAE3" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M5 12h14M13 6l6 6-6 6" />
  </svg>
);
export const PROG_ARROW = ARROW;

export const PROGRAMS = [
  {
    img: '/assets/images/img-05.webp',
    alt: 'Al-Ufuq — Arabic language textbook for non-native speakers',
    labelKey: 'programs.p1l', titleKey: 'programs.p1t',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="#E5C878" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M4 5.5C4 4.7 4.7 4 5.5 4H12v16H5.5A1.5 1.5 0 0 1 4 18.5v-13Z" />
        <path d="M20 5.5c0-.8-.7-1.5-1.5-1.5H12v16h6.5a1.5 1.5 0 0 0 1.5-1.5v-13Z" />
      </svg>
    ),
  },
  {
    img: '/assets/images/img-06.webp',
    alt: 'Arabic calligraphy pen and ink on script',
    labelKey: 'programs.p2l', titleKey: 'programs.p2t',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="#E5C878" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 20h9" />
        <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z" />
      </svg>
    ),
  },
  {
    img: '/assets/images/img-07.webp',
    alt: 'Open Arabic book with a stack of texts and candlelight',
    labelKey: 'programs.p3l', titleKey: 'programs.p3t',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="#E5C878" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 11.5a8.4 8.4 0 0 1-8.9 8.4 8.6 8.6 0 0 1-3.6-.8L3 20l1.05-4.05A8.4 8.4 0 1 1 21 11.5Z" />
      </svg>
    ),
  },
];

const CULTURE_IMG_STYLE = { width: '100%', height: '100%', objectFit: 'cover', display: 'block' };

export const DISCOVER_TABS = [
  {
    id: 'stories', tabKey: 'discover.tab1', textKey: 'discover.text1',
    cards: [
      { img: '/assets/images/img-09.webp', alt: 'A traveller pausing at a desert well', titleKey: 'discover.s1', video: '/assets/videos/stories-well-in-palms.mp4' },
      { img: '/assets/images/img-10.webp', alt: 'A caravan of camels crossing the dunes', titleKey: 'discover.s2', video: '/assets/videos/stories-caravans-journey.mp4' },
      { img: '/assets/images/img-11.webp', alt: 'A rider approaching a lantern-lit city at dusk', titleKey: 'discover.s3', video: '/assets/videos/stories-rider-at-the-gates.mp4' },
    ],
  },
  {
    id: 'morals', tabKey: 'discover.tab2', textKey: 'discover.text2',
    cards: [
      { img: '/assets/images/img-12.webp', alt: 'Kindness and helping an elder', titleKey: 'discover.m1', video: '/assets/videos/morals-honesty.mp4', moral: true },
      { img: '/assets/images/img-13.webp', alt: 'Kindness and helping a child', titleKey: 'discover.m2', video: '/assets/videos/morals-kindness.mp4', moral: true },
      { img: '/assets/images/img-14.webp', alt: 'Family learning together', titleKey: 'discover.m3', video: '/assets/videos/morals-patience.mp4', moral: true },
    ],
  },
  {
    id: 'culture', tabKey: 'discover.tab3', textKey: 'discover.text3',
    cards: [
      { img: '/assets/images/img-15.webp', alt: 'Culture image 1', titleKey: 'discover.c1', video: '/assets/videos/culture-geometric-pattern.mp4', imgStyle: CULTURE_IMG_STYLE },
      { img: '/assets/images/img-16.webp', alt: 'Culture image 2', titleKey: 'discover.c2', video: '/assets/videos/culture-dome-minaret.mp4', imgStyle: CULTURE_IMG_STYLE },
      { img: '/assets/images/img-17.webp', alt: 'Culture image 3', titleKey: 'discover.c3', video: '/assets/videos/culture-calligraphy-pen.mp4', imgStyle: CULTURE_IMG_STYLE },
    ],
  },
];

export const FACES = [
  { name: 'Sarvar A.', initial: 'S', cls: 'face-photo-1', file: 'sarvar-a.jpg', levelKey: 'testi.l1' },
  { name: 'Dilnoza K.', initial: 'D', cls: 'face-photo-2', file: 'dilnoza-k.jpg', levelKey: 'testi.l2' },
  { name: 'Jasur M.', initial: 'J', cls: 'face-photo-3', file: 'jasur-m.jpg', levelKey: 'testi.l3' },
  { name: 'Madina T.', initial: 'M', cls: 'face-photo-4', file: 'madina-t.jpg', levelKey: 'testi.l4' },
  { name: 'Otabek R.', initial: 'O', cls: 'face-photo-5', file: 'otabek-r.jpg', levelKey: 'testi.l5' },
  { name: 'Aziza N.', initial: 'A', cls: 'face-photo-6', file: 'aziza-n.jpg', levelKey: 'testi.l6' },
];

export const QUOTES = [
  { qKey: 'testi.q1', name: 'Sarvar A.', levelKey: 'testi.l1' },
  { qKey: 'testi.q2', name: 'Dilnoza K.', levelKey: 'testi.l2' },
  { qKey: 'testi.q3', name: 'Jasur M.', levelKey: 'testi.l3' },
  { qKey: 'testi.q4', name: 'Madina T.', levelKey: 'testi.l4' },
  { qKey: 'testi.q5', name: 'Otabek R.', levelKey: 'testi.l5' },
];

export const PRICING_FEATURES = ['pricing.f1', 'pricing.f2', 'pricing.f3', 'pricing.f4', 'pricing.f5'];

export const FAQ = [1, 2, 3, 4, 5, 6].map((n) => ({ q: `faq.q${n}`, a: `faq.a${n}` }));

export const FOOTER_COLUMNS = [
  {
    h: 'footer.h1',
    links: [
      { href: '#explore', key: 'footer.explore' },
      { href: '#pricing', key: 'footer.pricing' },
      { href: '#stories', key: 'footer.stories' },
    ],
  },
  {
    h: 'footer.h2',
    links: [
      { href: '#about', key: 'footer.about' },
      { href: '#about-author', key: 'footer.teachers' },
      { href: '#contacts', key: 'footer.contact' },
    ],
  },
  {
    h: 'footer.h3',
    links: [
      { href: '', text: 'YouTube', linkSlot: 'link_youtube' },
      { href: '', text: 'Instagram', linkSlot: 'link_instagram' },
      { href: 'https://t.me/kanal_ustaz_ali', text: 'Telegram', external: true, linkSlot: 'link_telegram' },
    ],
  },
];
