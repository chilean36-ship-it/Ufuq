import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import useScrollTop from '../../hooks/useScrollTop';
import useHashView, { readHashView } from '../../hooks/useHashView';
import PageStyle from '../../components/PageStyle';
import CabinetLangSelect from '../../components/CabinetLangSelect';
import PillSelect, { GROUP_ICON } from '../../components/PillSelect';
import pageCss from './teacher.css?inline';
import pageCssV2 from './teacher-v2.css?inline';
import designCss from './teacher-design.css?inline';
import materialsCss from './materials-design.css?inline';
import mediaCss from './media-design.css?inline';
import sidebarCss from '../../components/panel/panel-sidebar.css?inline';
import PanelSidebar from '../../components/panel/PanelSidebar';
import AiChat from '../Dashboard/AiChat/AiChat';
import CommandPalette from '../../components/panel/CommandPalette';
import usePendingWork from '../../components/panel/usePendingWork';
import teacherExtra from '../../i18n/teacher-extra';
import examModeDict from '../../i18n/exam-mode';
import { CabinetI18nProvider, useCabinetI18n } from '../../context/CabinetI18nContext';
import teacherDictBase from '../../i18n/cabinet-teacher';
import fillMissing from '../../i18n/fill-missing';
import { supabase } from '../../lib/supabaseClient';
import { getFreshUser, resolveFullName } from '../../lib/profileName';
import useLiveRefresh from '../../lib/liveRefresh';
import { clearCachedRole, ufuqGetSession } from '../../lib/auth';
import { PanelContext } from '../../components/panel/PanelContext';
import ProfilePage from '../../components/panel/ProfilePage';
import { ConfirmModal, MenuIcon, ProfileNavIcon, TeacherRoleIcon, AdminRoleIcon, Toasts, useConfirm, useIsMobile, useToasts } from '../../components/panel/ui';
import AttendancePage from '../../components/panel/AttendancePage';
import OverviewPage from './OverviewPage';
import GroupsPage from './GroupsPage';
import StudentsPage from './StudentsPage';
import TasksPage from './TasksPage';
import SlotsPage from './SlotsPage';
import HifzPage from './HifzPage';
import CalendarPage from './CalendarPage';
import ExamsPage from './ExamsPage';
import MaterialsPage from './MaterialsPage';
import MediaPage from './MediaPage';
import AnnouncementsPage from './AnnouncementsPage';
import PanelPending from './PanelPending';

// New strings of the redesigned panel, merged over the base dictionary (EN falls back to the key itself).
const teacherDict = Object.keys({ ...teacherDictBase, ...teacherExtra }).reduce((acc, k) => { acc[k] = { ...(fillMissing[k] || {}), ...(teacherDictBase[k] || {}), ...(teacherExtra[k] || {}), ...(examModeDict[k] || {}) }; return acc; }, {});
const COLLAPSE_KEY = 'ufuq-panel-collapsed';

const GROUP_KEY = 'ufuq-admin-group'; // same key the legacy admin/teacher panels shared
const svg = { viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round' };

const I = {
  overview: <svg {...svg}><rect x="3" y="3" width="7" height="9" /><rect x="14" y="3" width="7" height="5" /><rect x="14" y="12" width="7" height="9" /><rect x="3" y="16" width="7" height="5" /></svg>,
  teaching: <svg {...svg}><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>,
  coursework: <svg {...svg}><path d="M12 4L3 8l9 4 9-4-9-4z" /><path d="M7 10v5c0 1.5 2.5 3 5 3s5-1.5 5-3v-5" /></svg>,
  messages: <svg {...svg}><path d="M3 11l18-5v12L3 14v-3z" /><path d="M11.6 16.8a2 2 0 0 1-3.6 1.2" /></svg>,
};

const PAGE_LABEL = {
  overview: 'Overview', groups: 'Groups', students: 'Students', attendance: 'Attendance', slots: 'Slots', hifz: 'Hifz', calendar: 'Calendar',
  tasks: 'Tasks', exams: 'Exams', materials: 'Materials', media: 'Media', announcements: 'Messages', profile: 'Profile',
};

const SUB = {
  overview: 'Your day at a glance', groups: 'Schedule, students and group chat', students: 'Everyone in the selected group',
  tasks: 'Homework, submissions and grades', attendance: 'Mark and review who came', slots: 'Individual lesson slots', hifz: 'Qur\'an recitation tasks and AI checks',
  calendar: 'Lessons by month', exams: 'Written exams', materials: 'Audio lessons and board photos',
  media: 'Videos and audio for your groups', announcements: 'Notify the group or one student',
  profile: 'Your account',
};

const PAGES = {
  overview: OverviewPage, groups: GroupsPage, students: StudentsPage, tasks: TasksPage, attendance: AttendancePage,
  slots: SlotsPage,
  hifz: HifzPage,
  calendar: CalendarPage,
  exams: ExamsPage,
  materials: MaterialsPage,
  media: MediaPage,
  announcements: AnnouncementsPage,
  profile: ProfilePage,
};

function readSavedGroup() { try { return localStorage.getItem(GROUP_KEY); } catch (e) { return null; } }
function saveGroup(code) { try { localStorage.setItem(GROUP_KEY, code); } catch (e) { /* ignore */ } }

function TeacherInner() {
  const { t, lang } = useCabinetI18n();
  const navigate = useNavigate();
  const [toasts, toast] = useToasts();
  const [confirmState, askConfirm, closeConfirm] = useConfirm();
  const isMobile = useIsMobile();

  const [guard, setGuard] = useState({ ok: false, msgKey: 'Checking…' });
  const [user, setUser] = useState(null);
  const [myName, setMyName] = useState('Teacher');
  const [myAvatarUrl, setMyAvatarUrl] = useState(null);
  const [myRole, setMyRole] = useState('teacher');
  const [myGroups, setMyGroups] = useState([]);
  const [groupsLoaded, setGroupsLoaded] = useState(false);
  const [currentGroupCode, setCode] = useState(null);
  const [page, setPage] = useState(() => readHashView('overview', (v) => Object.prototype.hasOwnProperty.call(PAGES, v)));
  useHashView(page, 'overview'); // F5 qilinganda shu bo'limda qoladi
  const [nonce, setNonce] = useState(0);
  useScrollTop(page + ':' + nonce);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(() => { try { return localStorage.getItem(COLLAPSE_KEY) === '1'; } catch (e) { return false; } });
  const [cmdOpen, setCmdOpen] = useState(false);
  const expandSidebar = useCallback(() => { setCollapsed(false); try { localStorage.setItem(COLLAPSE_KEY, '0'); } catch (e) { /* ignore */ } }, []);
  const toggleCollapsed = useCallback(() => setCollapsed((c) => { const v = !c; try { localStorage.setItem(COLLAPSE_KEY, v ? '1' : '0'); } catch (e) { /* ignore */ } return v; }), []);

  useEffect(() => { document.title = 'Ufuq — Teacher'; }, []);

  useEffect(() => {
    let cancelled = false;
    let redirectTimer;
    (async () => {
      let session = null;
      try { session = await ufuqGetSession(); } catch (e) { session = null; }
      if (cancelled) return;
      if (!session) { clearCachedRole(); navigate('/index', { replace: true }); return; }
      setUser(session.user);
      setGuard({ ok: false, msgKey: 'Checking permissions…' });
      const { data, error } = await supabase.from('profiles').select('role, full_name, avatar_url').eq('id', session.user.id).single();
      if (cancelled) return;
      if (error || !data || (data.role !== 'teacher' && data.role !== 'admin')) {
        setGuard({ ok: false, msgKey: "You don't have access to the teacher panel. Redirecting to your dashboard…" });
        redirectTimer = setTimeout(() => navigate('/dashboard', { replace: true }), 1400);
        return;
      }
      const savedName = resolveFullName(await getFreshUser(session.user), data.full_name);
      if (savedName) setMyName(savedName);
      const savedAvatar = data.avatar_url || (session.user.user_metadata && session.user.user_metadata.avatar_url) || null;
      setMyAvatarUrl(savedAvatar);
      try {
        if (savedAvatar) localStorage.setItem('ufuq-avatar:' + session.user.id, savedAvatar);
        else localStorage.removeItem('ufuq-avatar:' + session.user.id);
      } catch (e) { /* storage blocked */ }
      setGuard({ ok: true, msgKey: '' });
    })();
    return () => { cancelled = true; clearTimeout(redirectTimer); };
  }, [navigate]);

  const reloadGroups = useCallback(async (opts) => {
    const silent = !!(opts && opts.silent);
    if (!user) return;
    const { data: tg, error: tgErr } = await supabase.from('teacher_groups').select('group_code').eq('teacher_id', user.id);
    if (tgErr) { if (!silent) toast(t('Error loading groups:') + ' ' + tgErr.message, 'err'); return; }
    const codes = (tg || []).map((r) => r.group_code);
    let groups = [];
    if (codes.length > 0) {
      const { data, error: gErr } = await supabase.from('groups').select('*').in('code', codes).order('name');
      if (gErr) { if (!silent) toast(t('Error loading group data:') + ' ' + gErr.message, 'err'); return; }
      groups = (data || []).slice().sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), undefined, { numeric: true, sensitivity: 'base' }));
    }
    setMyGroups((cur) => (JSON.stringify(cur) === JSON.stringify(groups) ? cur : groups)); // same data → same reference → no re-render
    setGroupsLoaded(true);
    if (groups.length === 0) { setCode(null); return; }
    setCode((cur) => {
      const saved = cur || readSavedGroup();
      const keep = groups.some((gg) => gg.code === saved) ? saved : groups[0].code;
      saveGroup(keep);
      return keep;
    });
  }, [user, t, toast]);

  useEffect(() => { if (guard.ok && user) reloadGroups(); }, [guard.ok, user]); // eslint-disable-line react-hooks/exhaustive-deps
  useLiveRefresh(reloadGroups);

  const pending = usePendingWork(guard.ok ? myGroups.map((g) => g.code) : []);

  useEffect(() => {
    const onKey = (e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setCmdOpen((o) => !o); } };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const setCurrentGroupCode = useCallback((code) => { setCode(code); saveGroup(code); }, []);
  const currentGroup = useMemo(() => myGroups.find((gg) => gg.code === currentGroupCode) || null, [myGroups, currentGroupCode]);
  const showPage = useCallback((name) => { setPage(name); setNonce((n) => n + 1); setSidebarOpen(false); }, []);
  const [announcePrefill, setAnnouncePrefill] = useState(null);
  const goToAnnouncements = useCallback((userId, name) => { setAnnouncePrefill({ userId, name }); showPage('announcements'); }, [showPage]);
  const clearAnnouncePrefill = useCallback(() => setAnnouncePrefill(null), []);

  const ctx = useMemo(() => ({
    t, lang, toast, askConfirm, user, myName, myAvatarUrl, setMyName, setMyAvatarUrl, myGroups, currentGroup, currentGroupCode, setCurrentGroupCode, reloadGroups,
    announcePrefill, clearAnnouncePrefill, goToAnnouncements, showPage, pending,
  }), [t, lang, toast, askConfirm, user, myName, myAvatarUrl, setMyName, setMyAvatarUrl, myGroups, currentGroup, currentGroupCode, setCurrentGroupCode, reloadGroups, announcePrefill, clearAnnouncePrefill, goToAnnouncements, showPage, pending]);

  const isIndividual = !!(currentGroup && currentGroup.type === 'individual');
  const nav = useMemo(() => [
    { page: 'overview', label: 'Overview', icon: I.overview },
    { id: 'teaching', label: 'Teaching', icon: I.teaching, items: [
      { page: 'groups', label: 'Groups' }, { page: 'students', label: 'Students' }, { page: 'attendance', label: 'Attendance' },
      ...(isIndividual ? [{ page: 'slots', label: 'Slots' }, { page: 'hifz', label: 'Hifz' }] : []), { page: 'calendar', label: 'Calendar' },
    ] },
    { id: 'coursework', label: 'Coursework', icon: I.coursework, items: [
      { page: 'tasks', label: 'Tasks', badge: pending.tasks }, { page: 'exams', label: 'Exams' },
      { page: 'materials', label: 'Materials' }, { page: 'media', label: 'Media' },
    ] },
    { page: 'announcements', label: 'Messages', icon: I.messages },
  ], [isIndividual, pending.tasks]);
  const flatNav = useMemo(() => nav.flatMap((n) => (n.items ? n.items.map((i) => ({ ...i, icon: n.icon })) : [n])), [nav]);
  const Page = (flatNav.some((n) => n.page === page) || page === 'profile') ? PAGES[page] : PAGES.overview;
  const activePage = Page === PAGES[page] ? page : 'overview';
  const navLabel = PAGE_LABEL[activePage] || activePage;

  return (
    <PanelContext.Provider value={ctx}>
      <PageStyle css={pageCss} />
      <PageStyle css={pageCssV2} />
      <PageStyle css={sidebarCss} />
      <PageStyle css={designCss} />
      <PageStyle css={materialsCss} />
      <PageStyle css={mediaCss} />

      {!guard.ok && (
        <div className="guard-overlay">
          <div className="spinner"></div>
          <div className="guard-msg">{t(guard.msgKey)}</div>
        </div>
      )}

      <div style={{ display: sidebarOpen ? 'block' : 'none', position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 40 }} onClick={() => setSidebarOpen(false)} />
      <PanelSidebar variant="teacher" showStudentLink={false} brandSuffix={t('Teacher')} nav={nav} page={activePage} onNavigate={showPage}
                    collapsed={collapsed} onToggleCollapsed={toggleCollapsed} onExpand={expandSidebar} open={sidebarOpen} isMobile={isMobile} />

      <div className="main">
        <div className="topbar">
          <button className="icon-btn menu-toggle-btn" aria-label={t('Menu')} style={{ display: isMobile ? 'inline-flex' : 'none' }} onClick={() => setSidebarOpen((o) => !o)}><MenuIcon /></button>
          <div className="crumb">
            <span className="crumb-title">{t(navLabel)}</span>
            <span className="crumb-sub">{t(SUB[activePage] || 'Teacher dashboard')}{currentGroup ? ' \u00b7 ' + currentGroup.name : ''}</span>
          </div>
          <div className="top-right">
            <button type="button" className="top-search" onClick={() => setCmdOpen(true)} aria-label={t('Search pages…')}>
              <svg {...svg}><circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" /></svg><span>{t('Search pages…')}</span><kbd>Ctrl K</kbd>
            </button>
            <CabinetLangSelect />
            <PillSelect icon={GROUP_ICON} ariaLabel={t('Group')} value={currentGroupCode || ''}
                        disabled={!groupsLoaded || myGroups.length === 0}
                        placeholder={!groupsLoaded ? t('Loading groups…') : t('No group assigned')}
                        emptyText={t('No group assigned')}
                        options={myGroups.map((g) => ({ value: g.code, label: g.name }))}
                        onChange={(code) => { setCurrentGroupCode(code); setNonce((n) => n + 1); }} />
            <div className="top-profile" role="button" tabIndex={0} style={{ cursor: 'pointer' }} title={t('Edit profile')}
                 onClick={() => showPage('profile')} onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); showPage('profile'); } }}>
              <div className="top-avatar">
                {myAvatarUrl
                  ? <img src={myAvatarUrl} alt="" style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover', display: 'block' }} />
                  : (myName || 'T').trim().charAt(0).toUpperCase()}
              </div>
              <span className="top-user-info">
                <span className="top-username">{myName}</span>
                <span className="top-role">
                  {myRole === 'admin' ? <AdminRoleIcon /> : <TeacherRoleIcon />}
                  {t(myRole === 'admin' ? 'Admin' : 'Teacher')}
                </span>
              </span>
            </div>
          </div>
        </div>
        <div className="content">
          {guard.ok && groupsLoaded && <Page key={page + ':' + nonce} />}
        </div>
      </div>

      <CommandPalette open={cmdOpen} onClose={() => setCmdOpen(false)} placeholder={t('Search pages…')} emptyText={t('No pages match.')}
                      items={[...flatNav, { page: 'profile', label: 'Profile', icon: <ProfileNavIcon /> }].map((n) => ({ page: n.page, icon: n.icon, label: t(n.label) }))}
                      onPick={showPage} />
      {guard.ok && <AiChat mode="teacher" user={user} name={myName} />}
      <ConfirmModal state={confirmState} onClose={closeConfirm} />
      <Toasts items={toasts} />
    </PanelContext.Provider>
  );
}

/** Route entry: `/teacher` (teacher or admin role — anyone else is sent to their dashboard, as in teacher.html). */
export default function Teacher() {
  return (
    <CabinetI18nProvider dict={teacherDict}>
      <TeacherInner />
    </CabinetI18nProvider>
  );
}
