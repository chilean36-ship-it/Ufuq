import { useMemo, useState } from 'react';
import { usePanel } from '../../components/panel/PanelContext';
import { DAY_NUM, DOW_ORDER, MONTH_KEYS, fmtDateStr } from '../../lib/panelUtils';

/** Every lesson scheduled on a given JS weekday (0=Sunday), across ALL of the teacher's groups — not just the
 *  currently-selected one, matching the original (the calendar is a bird's-eye view of the whole teaching week). */
function lessonsOnWeekday(myGroups, jsDow) {
  const out = [];
  myGroups.forEach((g) => {
    if (!g.is_active || !Array.isArray(g.schedule_days)) return;
    g.schedule_days.forEach((d) => { if (DAY_NUM[d.day] === jsDow) out.push({ group: g, time: d.time || '' }); });
  });
  return out.sort((a, b) => String(a.time).localeCompare(String(b.time)));
}

export default function CalendarPage() {
  const { t, myGroups } = usePanel();
  const [cursor, setCursor] = useState(() => new Date());

  const { label, cells, today } = useMemo(() => {
    const y = cursor.getFullYear(), m = cursor.getMonth();
    const first = new Date(y, m, 1);
    const lead = (first.getDay() + 6) % 7; // Monday-first
    const daysInMonth = new Date(y, m + 1, 0).getDate();
    const today = fmtDateStr(new Date());
    const arr = [];
    for (let i = 0; i < lead; i++) arr.push(null);
    for (let day = 1; day <= daysInMonth; day++) {
      const d = new Date(y, m, day);
      arr.push({ day, dateStr: fmtDateStr(d), events: lessonsOnWeekday(myGroups, d.getDay()) });
    }
    return { label: t(MONTH_KEYS[m]) + ' ' + y, cells: arr, today };
  }, [cursor, myGroups, t]);

  return (
    <section className="page active" id="page-calendar">
      <div className="page-head">
        <h2>{t('Calendar')}</h2>
        <p>{t('The full month of lessons for all of your groups.')}</p>
      </div>
      <div className="panel">
        <div className="cal-head">
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => setCursor((c) => new Date(c.getFullYear(), c.getMonth() - 1, 1))}>&lsaquo;</button>
          <div className="cal-month">{label}</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => setCursor(new Date())}>{t('Today')}</button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => setCursor((c) => new Date(c.getFullYear(), c.getMonth() + 1, 1))}>&rsaquo;</button>
          </div>
        </div>
        <div className="cal-dows">{DOW_ORDER.map((d) => <span key={d}>{t(d).slice(0, 3)}</span>)}</div>
        <div className="cal-grid">
          {cells.map((c, i) => (
            c === null ? <div className="cal-cell is-blank" key={'b' + i}></div> : (
              <div className={'cal-cell' + (c.dateStr === today ? ' is-today' : '')} key={c.dateStr}>
                <div className="cal-daynum">{c.day}</div>
                {c.events.map((e, j) => (
                  <div className="cal-ev" title={e.group.name + ' \u00b7 ' + e.time} key={j}>
                    <b>{e.time || '\u2014'}</b>{e.group.name}
                  </div>
                ))}
              </div>
            )
          ))}
        </div>
        <div className="cal-legend">
          {myGroups.length === 0 ? t('No group has been assigned to you yet.') : myGroups.map((g) => (
            <span key={g.code}>{g.name} {'\u2014'} {g.schedule || '\u2014'}</span>
          ))}
        </div>
      </div>
    </section>
  );
}
