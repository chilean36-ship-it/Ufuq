import { useCallback, useEffect, useRef, useState } from 'react';
import { supabase } from '../../lib/supabaseClient';
import useLiveRefresh from '../../lib/liveRefresh';
import { usePanel } from '../../components/panel/PanelContext';
import { Modal } from '../../components/panel/ui';
import { TYPE_LABEL, plainQ } from '../../lib/examPaper';
import PageStyle from '../../components/PageStyle';
import listCss from '../../styles/exam-builder.css?inline';
import ExamEditor from './ExamEditor';
import '../../styles/exam-paper.css';

/** "Written exams" sub-tab of Exams: per-group exam list (draft/published, question & submission counts),
 *  a paper-style builder (sections, one item per line, ready-made templates), publish gating (needs ≥1 question),
 *  a results table per student, and a grading view that shows the AI score/feedback alongside a teacher-score
 *  override, with a "Re-run AI check" button that calls the `grade-exam` edge function. */
export default function WrittenExamsPanel() {
  const { t, toast, askConfirm, currentGroup: g } = usePanel();
  const code = g ? g.code : null;
  const [exams, setExams] = useState(null);
  const [meta, setMeta] = useState({ qCount: {}, subCount: {} });
  const [builder, setBuilder] = useState({ open: false, exam: null });
  const [results, setResults] = useState({ open: false, exam: null });
  const [grade, setGrade] = useState({ open: false, submissionId: null, name: '' });

  const load = useCallback(async (opts) => {
    const silent = !!(opts && opts.silent);
    if (!code) { setExams(null); return; }
    if (!silent) setExams(null);
    try {
      const { data, error } = await supabase.from('written_exams').select('*').eq('group_code', code).order('created_at', { ascending: false });
      if (error) throw error;
      const list = data || [];
      if (list.length === 0) { setExams([]); return; }
      const ids = list.map((e) => e.id);
      const [qs, subs] = await Promise.all([
        supabase.from('written_exam_questions').select('exam_id').in('exam_id', ids),
        supabase.from('written_exam_submissions').select('exam_id, status').in('exam_id', ids),
      ]);
      const qc = {}, sc = {};
      (qs.data || []).forEach((q) => { qc[q.exam_id] = (qc[q.exam_id] || 0) + 1; });
      (subs.data || []).forEach((s) => { if (s.status === 'submitted' || s.status === 'graded') sc[s.exam_id] = (sc[s.exam_id] || 0) + 1; });
      setMeta({ qCount: qc, subCount: sc });
      setExams(list);
    } catch (e) { if (!silent) setExams({ error: e.message || String(e) }); }
  }, [code]);

  useEffect(() => { load(); }, [load]);
  useLiveRefresh(load);

  async function togglePublish(exam) {
    try {
      if (!exam.is_published) {
        const { count } = await supabase.from('written_exam_questions').select('id', { count: 'exact', head: true }).eq('exam_id', exam.id);
        if (!count) { toast(t('Add at least one question before publishing.'), 'err'); return; }
      }
      const { error } = await supabase.from('written_exams').update({ is_published: !exam.is_published }).eq('id', exam.id);
      if (error) throw error;
      toast(t(exam.is_published ? 'Exam unpublished.' : 'Exam published.'), 'ok');
      load();
    } catch (e) { toast(e.message || String(e), 'err'); }
  }

  function del(exam) {
    askConfirm(t('Delete exam'), t('This exam, its questions and all student answers will be deleted. Continue?'), async () => {
      const { error } = await supabase.from('written_exams').delete().eq('id', exam.id);
      if (error) { toast(error.message, 'err'); return; }
      toast(t('Exam deleted.'), 'ok');
      load();
    });
  }

  const openNew = () => { if (!code) { toast(t('Select a group first.'), 'err'); return; } setBuilder({ open: true, exam: null }); };
  const count = Array.isArray(exams) ? exams.length : 0;

  return (
    <div className="we-panel active" id="examsWrittenPanel">
      <PageStyle css={listCss} />
      <div className="panel">
        <div className="xl-head">
          <div>
            <h3>{t('Written exams')}{g ? <span className="we-group-pill">{g.name}</span> : null}</h3>
            {code && Array.isArray(exams) ? <div className="xl-count">{count} {t('exams')}</div> : null}
          </div>
          <button className="btn btn-gold" onClick={openNew}>{t('+ New exam')}</button>
        </div>
        {!code ? <div className="xl-empty"><p>{t('Select a group')}</p></div>
          : exams === null ? <div className="xl-empty"><p>{t('Loading…')}</p></div>
          : exams.error ? <div className="xl-empty"><p>{exams.error}</p></div>
          : exams.length === 0 ? (
            <div className="xl-empty">
              <p>{t('No written exams yet.')}</p>
              <button className="btn btn-gold" onClick={openNew}>{t('+ New exam')}</button>
            </div>
          ) : (
            <div className="xl-list">
              {exams.map((e) => (
                <article className="xl-card" key={e.id}>
                  <div>
                    <div className="xl-title" dir="auto">{e.title}</div>
                    <div className="xl-meta">
                      <span><b>{meta.qCount[e.id] || 0}</b> {t('questions')}</span>
                      <span><b>{meta.subCount[e.id] || 0}</b> {t('submitted')}</span>
                    </div>
                  </div>
                  <label className="xl-switch" title={t(e.is_published ? 'Unpublish' : 'Publish')}>
                    <input type="checkbox" role="switch" checked={!!e.is_published} onChange={() => togglePublish(e)} />
                    <i aria-hidden="true" />
                    <span className={e.is_published ? 'on' : 'off'}>{t(e.is_published ? 'Published' : 'Draft')}</span>
                  </label>
                  <div className="xl-actions">
                    <button className="btn btn-gold btn-sm" onClick={() => setResults({ open: true, exam: e })}>{t('Results')}</button>
                    <button className="btn btn-ghost btn-sm" onClick={() => setBuilder({ open: true, exam: e })}>{t('Edit')}</button>
                    <button className="btn btn-danger btn-sm" onClick={() => del(e)}>{t('Delete')}</button>
                  </div>
                </article>
              ))}
            </div>
          )}
      </div>

      <ExamEditor state={builder} onClose={() => setBuilder((s) => ({ ...s, open: false }))} onSaved={load} />
      <ResultsModal state={results} onClose={() => setResults((s) => ({ ...s, open: false }))}
        onGrade={(submissionId, name) => setGrade({ open: true, submissionId, name })} />
      <GradeModal state={grade} onClose={() => setGrade((s) => ({ ...s, open: false }))}
        examTitle={results.exam ? results.exam.title : ''}
        onSaved={() => { if (results.exam) { /* keep results modal fresh */ } load(); }} />
    </div>
  );
}

function ResultsModal({ state, onClose, onGrade }) {
  const { t, toast, currentGroup: g } = usePanel();
  const [rows, setRows] = useState(null);
  const examId = state.exam ? state.exam.id : null;

  const refresh = useCallback(async () => {
    if (!examId || !g) return;
    setRows(null);
    try {
      const [memRes, subRes] = await Promise.all([
        supabase.from('group_members').select('user_id, name').eq('group_code', g.code).order('name'),
        supabase.from('written_exam_submissions').select('*').eq('exam_id', examId),
      ]);
      if (memRes.error) throw memRes.error;
      if (subRes.error) throw subRes.error;
      const members = memRes.data || [];
      if (members.length === 0) { setRows([]); return; }
      const subMap = {}; (subRes.data || []).forEach((s) => { subMap[s.user_id] = s; });
      const aiDone = {};
      const subIds = (subRes.data || []).map((x) => x.id);
      if (subIds.length) {
        const { data: ai } = await supabase.from('written_exam_answers').select('submission_id').in('submission_id', subIds).not('ai_score', 'is', null);
        (ai || []).forEach((a) => { aiDone[a.submission_id] = true; });
      }
      const viol = {};
      try {
        const { data: vs } = await supabase.rpc('exam_violation_summary', { p_exam_type: 'written', p_exam_id: String(examId) });
        (vs || []).forEach((v) => { viol[v.user_id] = v.total; });
      } catch (e) { /* migration not applied yet */ }
      setRows(members.map((m) => { const sb = subMap[m.user_id] || null; return { member: m, sub: sb, viol: viol[m.user_id] || 0, ai: !!(sb && aiDone[sb.id]) }; }));
    } catch (e) { setRows({ error: e.message || String(e) }); }
  }, [examId, g]);

  useEffect(() => { if (state.open) refresh(); }, [state.open, refresh]);

  const labels = { draft: 'Not submitted', submitted: 'Submitted', graded: 'Graded' };
  const [busy, setBusy] = useState(false);
  const pending = Array.isArray(rows) ? rows.filter((r) => r.sub && r.sub.status === 'submitted' && r.ai) : [];

  /** Approves AI-checked papers as they are: item score = teacher score if set, else the AI score; total = average. */
  async function approveMany(list) {
    if (!list.length || !examId) return;
    setBusy(true);
    try {
      const { data: qs, error: qErr } = await supabase.from('written_exam_questions').select('id').eq('exam_id', examId);
      if (qErr) throw qErr;
      const qIds = (qs || []).map((q) => q.id);
      const { data: ans, error: aErr } = await supabase.from('written_exam_answers').select('submission_id, question_id, ai_score, teacher_score').in('submission_id', list.map((r) => r.sub.id));
      if (aErr) throw aErr;
      for (const r of list) {
        const mine = {}; (ans || []).forEach((a) => { if (a.submission_id === r.sub.id) mine[a.question_id] = a; });
        const sum = qIds.reduce((acc, id) => { const a = mine[id]; const v = a ? (a.teacher_score != null ? a.teacher_score : (a.ai_score != null ? a.ai_score : 0)) : 0; return acc + v; }, 0);
        const total = qIds.length ? Math.round(sum / qIds.length) : 0;
        const { error } = await supabase.from('written_exam_submissions').update({ status: 'graded', total_score: total }).eq('id', r.sub.id);
        if (error) throw error;
      }
      toast(t('Grades approved.'), 'ok');
      refresh();
    } catch (e) { toast(e.message || String(e), 'err'); } finally { setBusy(false); }
  }

  return (
    <Modal open={state.open} onClose={onClose} wide>
      <h3>{t('Results')} &mdash; <span>{state.exam ? state.exam.title : ''}</span></h3>
      {pending.length > 0 && (
        <div className="pb-addrow" style={{ margin: '0 0 12px', alignItems: 'center' }}>
          <span className="u-pill gold">{'\u2728'} {pending.length} {t('Needs approval')}</span>
          <button type="button" className="btn btn-gold btn-sm" disabled={busy} onClick={() => approveMany(pending)}>{t('Approve all AI-checked')}</button>
        </div>
      )}
      <table>
        <thead><tr><th>{t('Student')}</th><th>{t('Status')}</th><th>{t('Total score')}</th><th>{t('Integrity')}</th><th></th></tr></thead>
        <tbody>
          {rows === null ? <tr className="empty-row"><td colSpan={5}>{t('Loading…')}</td></tr>
            : rows.error ? <tr className="empty-row"><td colSpan={5}>{rows.error}</td></tr>
            : rows.length === 0 ? <tr className="empty-row"><td colSpan={5}>{t('There are no students in this group yet.')}</td></tr>
            : rows.map(({ member: m, sub: s, viol, ai }) => {
              const status = s ? s.status : 'none';
              const label = s ? (s.status === 'submitted' && ai ? 'AI checked' : labels[s.status]) : 'Not submitted';
              return (
                <tr key={m.user_id}>
                  <td><b>{m.name || t('Student')}</b></td>
                  <td><span className={'we-status ' + status}>{t(label)}</span></td>
                  <td>{s && s.total_score !== null && s.total_score !== undefined ? s.total_score : '\u2014'}</td>
                  <td>{viol > 0 ? <span className="u-pill amber" title={t('Times the student left the exam page')}>{'\u26A0'} {viol}</span> : <span className="muted">{'\u2713'}</span>}</td>
                  <td style={{ textAlign: 'right' }}>
                    {s && s.status !== 'draft'
                      ? <button className={'btn btn-sm ' + (s.status === 'submitted' && ai ? 'btn-gold' : 'btn-ghost')} onClick={() => onGrade(s.id, m.name || '')}>{t(s.status === 'submitted' && ai ? 'Approve' : 'Check')}</button>
                      : <span className="muted" style={{ fontSize: 12 }}>{'\u2014'}</span>}
                  </td>
                </tr>
              );
            })}
        </tbody>
      </table>
    </Modal>
  );
}

function GradeModal({ state, onClose, examTitle, onSaved }) {
  const { t, toast } = usePanel();
  const [sub, setSub] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [scores, setScores] = useState({});
  const [saving, setSaving] = useState(false);
  const [regrading, setRegrading] = useState(false);
  const autoRan = useRef(null);

  const load = useCallback(async () => {
    if (!state.submissionId) return;
    setSub(null);
    try {
      const { data: s, error: subErr } = await supabase.from('written_exam_submissions').select('*').eq('id', state.submissionId).single();
      if (subErr) throw subErr;
      const [qRes, aRes] = await Promise.all([
        supabase.from('written_exam_questions').select('*').eq('exam_id', s.exam_id).order('order_num'),
        supabase.from('written_exam_answers').select('*').eq('submission_id', state.submissionId),
      ]);
      if (qRes.error) throw qRes.error;
      if (aRes.error) throw aRes.error;
      const ansMap = {}; (aRes.data || []).forEach((a) => { ansMap[a.question_id] = a; });
      const initScores = {};
      (qRes.data || []).forEach((q) => {
        const a = ansMap[q.id];
        initScores[q.id] = a && a.teacher_score !== null && a.teacher_score !== undefined ? String(a.teacher_score)
          : a && a.ai_score !== null && a.ai_score !== undefined ? String(a.ai_score) : '';
      });
      setSub(s); setQuestions(qRes.data || []); setAnswers(ansMap); setScores(initScores);
    } catch (e) { setSub({ error: e.message || String(e) }); }
  }, [state.submissionId]);

  useEffect(() => { if (state.open) load(); }, [state.open, load]);

  const hasAi = Object.values(answers).some((a) => a && a.ai_score !== null && a.ai_score !== undefined);

  // If the student's browser closed before the AI finished, run the check now (once per opened paper).
  useEffect(() => {
    if (!sub || sub.error || sub.status !== 'submitted' || hasAi || !state.open) return;
    if (autoRan.current === sub.id) return;
    autoRan.current = sub.id;
    regrade();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sub, hasAi, state.open]);

  async function save() {
    if (!sub || sub.error) return;
    setSaving(true);
    try {
      const vals = [];
      for (const q of questions) {
        const a = answers[q.id];
        const raw = (scores[q.id] || '').trim();
        const val = raw === '' ? null : Math.max(0, Math.min(100, parseInt(raw, 10) || 0));
        vals.push(val === null ? 0 : val);
        if (!a) continue;
        const { error } = await supabase.from('written_exam_answers').update({ teacher_score: val }).eq('id', a.id);
        if (error) throw error;
      }
      const total = vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : 0;
      const { error } = await supabase.from('written_exam_submissions').update({ status: 'graded', total_score: total }).eq('id', sub.id);
      if (error) throw error;
      toast(t('Grades approved.') + ' \u2014 ' + total, 'ok');
      onClose();
      onSaved();
    } catch (e) { toast(e.message || String(e), 'err'); } finally { setSaving(false); }
  }

  async function regrade() {
    setRegrading(true);
    try {
      const { data, error } = await supabase.functions.invoke('grade-exam', { body: { submission_id: state.submissionId } });
      if (error) throw error;
      if (data && data.ok) { toast(t('AI check finished.') + ' \u2014 ' + data.total_score, 'ok'); load(); }
      else { toast((data && data.error) || t('AI check failed — grade it manually.'), 'err'); }
    } catch (e) { toast(e.message || String(e), 'err'); } finally { setRegrading(false); }
  }

  const meta = sub && !sub.error ? (examTitle ? examTitle + ' \u00b7 ' : '') + t(sub.status === 'graded' ? 'Graded' : 'Submitted') + (sub.submitted_at ? ' \u00b7 ' + new Date(sub.submitted_at).toLocaleString() : '') : '';

  return (
    <Modal open={state.open} onClose={onClose} wide>
      <h3>{state.name || t('Student')}</h3>
      <p className="hint" style={{ marginBottom: 14 }}>{meta}</p>
      {sub && !sub.error && sub.status === 'graded' && (
        <div className="we-ai" style={{ marginBottom: 14, padding: '10px 14px', border: '1px solid rgba(201,162,75,.4)', borderRadius: 10 }}>
          {t('Graded by AI. The student already sees this result; change a score only if you disagree.')}
        </div>
      )}
      {sub && !sub.error && sub.status === 'submitted' && (
        <div className="we-ai" style={{ marginBottom: 14, padding: '10px 14px', border: '1px solid rgba(201,162,75,.4)', borderRadius: 10 }}>
          {regrading ? t('Waiting for AI…') : hasAi ? t('The AI has checked this paper. Review the scores, change any you disagree with, then approve.') : t('Not checked by AI.')}
        </div>
      )}
      <div>
        {sub === null ? <div className="empty-block">{t('Loading…')}</div>
          : sub.error ? <div className="empty-block">{sub.error}</div>
          : questions.length === 0 ? <div className="empty-block">{t('No questions yet.')}</div>
          : questions.map((q, i) => {
            const a = answers[q.id];
            const text = a && a.answer_text && a.answer_text.trim();
            return (
              <div className="we-ans" key={q.id}>
                <div className="we-ans-type">{t('Question')} {i + 1} {'\u00b7'} {t(TYPE_LABEL[q.type] || q.type)}</div>
                <div className="we-ans-q" dir="auto">{plainQ(q.question_text)}</div>
                {q.criteria_text && <div className="we-ai"><b>{t('Criteria')}:</b> {q.criteria_text}</div>}
                <div className={'we-ans-text' + (text ? '' : ' we-ans-empty')} dir="auto">{text ? a.answer_text : t('No answer.')}</div>
                <div className="we-ai">
                  {a && a.ai_score !== null && a.ai_score !== undefined
                    ? <><b>{t('AI score')}: {a.ai_score}</b>{a.ai_feedback ? ' \u2014 ' + a.ai_feedback : ''}</>
                    : t('Not checked by AI.')}
                </div>
                <div className="we-score-row">
                  <label>{t('Teacher score (0-100)')}</label>
                  <input type="number" min="0" max="100" className="we-score-in" disabled={!a}
                         value={scores[q.id] || ''} onChange={(e) => setScores((cur) => ({ ...cur, [q.id]: e.target.value }))} />
                </div>
              </div>
            );
          })}
      </div>
      <div className="modal-actions">
        <button type="button" className="btn btn-ghost" disabled={regrading} onClick={regrade}>{t('Re-run AI check')}</button>
        <button type="button" className="btn btn-gold" disabled={saving || regrading} onClick={save}>{t('Save')}</button>
      </div>
    </Modal>
  );
}
