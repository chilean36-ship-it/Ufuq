import { useCallback, useEffect, useMemo, useState } from 'react';
import { supabase } from '../../lib/supabaseClient';
import useLiveRefresh from '../../lib/liveRefresh';
import { usePanel } from '../../components/panel/PanelContext';
import { EmptyRow, Modal } from '../../components/panel/ui';
import { fmtDate } from '../../lib/panelUtils';

const STATUSES = ['unpaid', 'active', 'blocked'];
const LEVELS = [1, 2, 3, 4, 5, 6, 7, 8];
const SKILLS = ['listening', 'speaking', 'reading', 'writing'];

export default function StudentsPage() {
  const { t, toast, askConfirm, myGroups, currentGroup: g, setCurrentGroupCode } = usePanel();
  const code = g ? g.code : null;
  const [rows, setRows] = useState(null);
  const [search, setSearch] = useState('');
  const [profile, setProfile] = useState({ open: false, userId: null, name: '' });

  const load = useCallback(async (opts) => {
    const silent = !!(opts && opts.silent);
    if (!code) return;
    if (!silent) setRows(null);
    const { data: members, error } = await supabase.from('group_members').select('user_id, name, joined_at').eq('group_code', code).order('joined_at');
    if (error) { { if (!silent) toast(error.message, 'err'); }; return; }
    if (!members || members.length === 0) { setRows([]); return; }
    const ids = members.map((m) => m.user_id);
    const { data: profs } = await supabase.from('profiles').select('id, status, level').in('id', ids);
    const profMap = {};
    (profs || []).forEach((p) => { profMap[p.id] = p; });
    setRows(members.map((m) => {
      const p = profMap[m.user_id] || { status: 'unpaid', level: 1 };
      return { ...m, status: p.status, level: p.level };
    }));
  }, [code, toast]);

  useEffect(() => { load(); }, [load]);
  useLiveRefresh(load);
  useEffect(() => { setSearch(''); }, [code]);

  const patchRow = (uid, patch) => setRows((cur) => cur.map((r) => (r.user_id === uid ? { ...r, ...patch } : r)));

  async function changeStatus(uid, status) {
    const { error } = await supabase.rpc('admin_update_student', { p_user_id: uid, p_status: status, p_level: null });
    if (error) { toast(error.message, 'err'); return; }
    patchRow(uid, { status });
    toast(t('Status updated.'), 'ok');
  }
  async function changeLevel(uid, level) {
    const { error } = await supabase.rpc('admin_update_student', { p_user_id: uid, p_status: null, p_level: level });
    if (error) { toast(error.message, 'err'); return; }
    patchRow(uid, { level });
    toast(t('Level updated.'), 'ok');
  }
  function remove(m) {
    askConfirm(t('Remove from Group'), t('This student will be removed from this group. They can rejoin later using the group code. Continue?'), async () => {
      const { error } = await supabase.from('group_members').delete().eq('user_id', m.user_id).eq('group_code', g.code);
      if (error) { toast(error.message, 'err'); return; }
      toast(t('Student removed from group.'), 'ok');
      load();
    });
  }

  const filtered = useMemo(() => {
    if (!rows) return rows;
    const q = search.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((r) => (r.name || '').toLowerCase().includes(q));
  }, [rows, search]);

  const statusLabels = { unpaid: t('Unpaid'), active: t('Active (paid)'), blocked: t('Blocked') };

  return (
    <section className="page active" id="page-students">
      <div className="page-head"><h2>{t('Students')}</h2><p>{t('Select a group from the switcher above.')}</p></div>
      <div className="scope-tabs">
        {myGroups.map((mg) => (
          <button type="button" key={mg.code} className={'scope-btn' + (mg.code === code ? ' on' : '')}
                  onClick={() => setCurrentGroupCode(mg.code)}>{mg.name}</button>
        ))}
      </div>
      {rows && rows.length > 0 && (
        <div className="kpi-row kpi-row-3">
          <div className="kpi"><span className="kpi-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /></svg></span><span><span className="kpi-num">{rows.length}</span><span className="kpi-lbl">{t('Students')}</span></span></div>
          <div className="kpi"><span className="kpi-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5" /></svg></span><span><span className="kpi-num">{rows.filter((r) => r.status === 'active').length}</span><span className="kpi-lbl">{t('Active (paid)')}</span></span></div>
          <div className={'kpi' + (rows.some((r) => r.status === 'unpaid') ? ' is-alert' : '')}><span className="kpi-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 3" /></svg></span><span><span className="kpi-num">{rows.filter((r) => r.status === 'unpaid').length}</span><span className="kpi-lbl">{t('Unpaid')}</span></span></div>
        </div>
      )}
      <div className="panel">
        <div className="panel-head">
          <h3>{g ? g.name + ' \u2014 students' : t('Student list')}</h3>
          <input type="text" className="u-input u-search" placeholder={t('Search a student\u2026')} value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <table>
          <thead><tr><th>{t('Name')}</th><th>{t('Status')}</th><th>{t('Level')}</th><th></th></tr></thead>
          <tbody>
            {!g ? <EmptyRow cols={4}>{t('Select a group')}</EmptyRow>
              : rows === null ? <EmptyRow cols={4}>{t('Loading…')}</EmptyRow>
              : rows.length === 0 ? <EmptyRow cols={4}>{t('There are no students in this group yet.')}</EmptyRow>
              : filtered.length === 0 ? <EmptyRow cols={4}>{t('Nothing found.')}</EmptyRow>
              : filtered.map((m) => (
                <tr key={m.user_id}>
                  <td>
                    <div className="st-person">
                      <span className="st-avatar">{(m.name || '?').trim().charAt(0).toUpperCase()}</span>
                      <button type="button" className="link-name" onClick={() => setProfile({ open: true, userId: m.user_id, name: m.name || t('Student') })}>{m.name || t('Student')}</button>
                    </div>
                  </td>
                  <td>
                    <select className={'chip-select chip-status-' + (m.status || 'unpaid')} value={m.status || ''} onChange={(e) => changeStatus(m.user_id, e.target.value)}>
                      {STATUSES.map((s) => <option key={s} value={s}>{statusLabels[s]}</option>)}
                    </select>
                  </td>
                  <td>
                    <select style={{ width: 70, padding: '6px 8px' }} value={m.level} onChange={(e) => changeLevel(m.user_id, parseInt(e.target.value, 10))}>
                      {LEVELS.map((lv) => <option key={lv} value={lv}>{lv}</option>)}
                    </select>
                  </td>
                  <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                    <button className="btn btn-danger btn-sm" onClick={() => remove(m)}>{t('Remove from Group')}</button>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
      <StudentProfileModal state={profile} group={g} onClose={() => setProfile((s) => ({ ...s, open: false }))} />
    </section>
  );
}

function StudentProfileModal({ state, group: g, onClose }) {
  const { t, goToAnnouncements } = usePanel();
  const [data, setData] = useState(null);   // null = loading
  const userId = state.userId;

  useEffect(() => {
    if (!state.open || !g || !userId) return undefined;
    let cancelled = false;
    setData(null);
    (async () => {
      const [profRes, memRes, sessRes, progRes, examRes, taskRes] = await Promise.all([
        supabase.from('profiles').select('status, level').eq('id', userId).maybeSingle(),
        supabase.from('group_members').select('joined_at').eq('user_id', userId).eq('group_code', g.code).maybeSingle(),
        supabase.from('attendance_sessions').select('id, session_date').eq('group_code', g.code).order('session_date', { ascending: false }).limit(30),
        supabase.from('student_progress').select('*').eq('user_id', userId).eq('group_code', g.code).maybeSingle(),
        supabase.from('written_exam_submissions').select('id, status, total_score, submitted_at, exam:written_exams!inner(title, group_code)').eq('user_id', userId).eq('exam.group_code', g.code).eq('status', 'graded').order('submitted_at', { ascending: false }),
        supabase.from('tasks').select('id, title, due_date').eq('group_code', g.code),
      ]);
      if (cancelled) return;
      const prof = profRes.data || {};
      const mem = memRes.data || {};
      const sess = sessRes.data || [];
      let att = [];
      if (sess.length) {
        const { data: recs } = await supabase.from('attendance_records').select('session_id, present').eq('user_id', userId).in('session_id', sess.map((s) => s.id));
        const map = {}; (recs || []).forEach((r) => { map[r.session_id] = r.present; });
        att = sess.filter((s) => map[s.id] !== undefined).map((s) => ({ date: s.session_date, present: map[s.id] }));
      }
      const p = progRes.data || { listening: 0, speaking: 0, reading: 0, writing: 0 };
      const exams = examRes.data || [];
      const tasks = taskRes.data || [];
      let subs = [];
      if (tasks.length) {
        const { data: s } = await supabase.from('task_submissions').select('*').eq('user_id', userId).in('task_id', tasks.map((tk) => tk.id));
        subs = s || [];
      }
      const taskMap = {}; tasks.forEach((tk) => { taskMap[tk.id] = tk; });
      if (!cancelled) setData({ prof, mem, att, p, exams, subs, taskMap, tasks });
    })();
    return () => { cancelled = true; };
  }, [state.open, g, userId]);

  const attTotal = data ? data.att.length : 0;
  const attPresent = data ? data.att.filter((a) => a.present).length : 0;
  const attPct = attTotal ? Math.round((attPresent * 100) / attTotal) : 0;
  const avg = data ? Math.round((data.p.listening + data.p.speaking + data.p.reading + data.p.writing) / 4) : 0;
  const statusLabel = data ? t(data.prof.status === 'active' ? 'Active (paid)' : data.prof.status === 'blocked' ? 'Blocked' : 'Unpaid') : '';

  return (
    <Modal open={state.open} onClose={onClose} wide id="studentProfileOverlay">
      <div className="sp-head">
        <div className="sp-avatar">{(state.name || '?').charAt(0).toUpperCase()}</div>
        <div>
          <div className="sp-name">{state.name || t('Student')}</div>
          <div className="sp-meta">{g ? (g.name + (data ? (' \u00b7 ' + t('Joined') + ': ' + (data.mem.joined_at ? fmtDate(data.mem.joined_at) : '\u2014')) : '')) : ''}</div>
        </div>
      </div>
      {data === null ? <div className="empty-block">{t('Loading…')}</div> : (
        <>
          <div className="sp-stats">
            <div className="sp-stat"><div className="sp-stat-num">{attPct}%</div><div className="sp-stat-lbl">{t('Attendance')}</div></div>
            <div className="sp-stat"><div className="sp-stat-num">{avg}</div><div className="sp-stat-lbl">{t('Average score')}</div></div>
            <div className="sp-stat"><div className="sp-stat-num">{data.exams.length}</div><div className="sp-stat-lbl">{t('Exams taken')}</div></div>
            <div className="sp-stat"><div className="sp-stat-num">{data.subs.length}/{data.tasks.length}</div><div className="sp-stat-lbl">{t('Submissions')}</div></div>
            <div className="sp-stat"><div className="sp-stat-num" style={{ fontSize: 16, paddingTop: 5 }}>{statusLabel}</div><div className="sp-stat-lbl">{t('Status')} {'\u00b7'} {t('Level')} {data.prof.level || 1}</div></div>
          </div>
          <div className="sp-section">
            <h4>{t('Skills')}</h4>
            <div>
              {SKILLS.map((s) => {
                const v = data.p[s] || 0;
                return (
                  <div className="sp-skill" key={s}>
                    <i>{t(s.charAt(0).toUpperCase() + s.slice(1))}</i>
                    <span className="sp-bar"><span style={{ width: v + '%' }}></span></span>
                    <b>{v}</b>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="sp-section">
            <h4>{t('Exam results')}</h4>
            {data.exams.length === 0 ? <div className="empty-block">{t('No exam results yet.')}</div> : (
              <div className="u-list">
                {data.exams.map((r) => (
                  <div className="u-item" key={r.id}>
                    <div className="u-item-main">
                      <div className="u-item-title" dir="auto">{(r.exam && r.exam.title) || '\u2014'} {'\u2014'} {r.total_score == null ? '\u2014' : r.total_score + '%'}</div>
                      <div className="u-item-sub">{r.submitted_at ? new Date(r.submitted_at).toLocaleString() : ''}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="sp-section">
            <h4>{t('Submissions')}</h4>
            {data.subs.length === 0 ? <div className="empty-block">{t('No one has submitted yet.')}</div> : (
              <div className="u-list">
                {data.subs.map((s) => {
                  const tk = data.taskMap[s.task_id] || {};
                  return (
                    <div className="u-item" key={s.id}>
                      <div className="u-item-main">
                        <div className="u-item-title">{tk.title || '\u2014'}</div>
                        <div className="u-item-sub">
                          {s.file_name || ''} {'\u00b7'} {new Date(s.submitted_at).toLocaleDateString()}
                          {s.grade && <> {'\u00b7'} <span className="u-pill gold">{s.grade}</span></>}
                          {s.feedback && <br />}{s.feedback}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          <div className="sp-section">
            <h4>{t('Recent attendance')}</h4>
            {attTotal === 0 ? <div className="empty-block">{t('No sessions yet.')}</div> : (
              <div className="u-list">
                {data.att.slice(0, 12).map((a, i) => (
                  <div className="u-item" style={{ padding: '9px 14px' }} key={i}>
                    <div className="u-item-main"><div className="u-item-sub" style={{ margin: 0 }}>{fmtDate(a.date)}</div></div>
                    <span className={'u-pill ' + (a.present ? 'gold' : 'amber')}>{t(a.present ? 'Present' : 'Absent')}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}
      <div className="modal-actions">
        <button type="button" className="btn btn-ghost" onClick={() => { onClose(); goToAnnouncements(state.userId, state.name); }}>{t('Send a message')}</button>
        <button type="button" className="btn btn-ghost" onClick={onClose}>{t('Close')}</button>
      </div>
    </Modal>
  );
}
