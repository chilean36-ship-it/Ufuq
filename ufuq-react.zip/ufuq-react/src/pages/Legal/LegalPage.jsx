import { Link, Navigate } from 'react-router-dom';
import PageStyle from '../../components/PageStyle';
import LangSelect from '../../components/LangSelect';
import tokensCss from '../../styles/tokens.css?inline';
import { useI18n } from '../../context/I18nContext';
import { LEGAL } from './legalConfig';
import { LEGAL_DOCS, getLegalDoc, legalUi } from './legalContent';

const CSS = `
  *{box-sizing:border-box}
  html,body{margin:0;background:var(--bg);color:var(--text);font-family:'Inter',system-ui,sans-serif;display:block;overflow:auto;height:auto}
  .lg-top{position:sticky;top:0;z-index:5;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px clamp(16px,4vw,40px);background:color-mix(in srgb,var(--bg) 88%,transparent);backdrop-filter:blur(10px);border-bottom:1px solid var(--line)}
  .lg-top a.back{color:var(--gold-bright);text-decoration:none;font-size:14px;font-weight:600}
  .lg-wrap{max-width:1040px;margin:0 auto;padding:40px clamp(16px,4vw,40px) 80px;display:grid;grid-template-columns:230px minmax(0,1fr);gap:48px}
  .lg-nav{position:sticky;top:84px;align-self:start;display:flex;flex-direction:column;gap:4px}
  .lg-nav h6{margin:0 0 8px;font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--text-muted)}
  .lg-nav a{padding:9px 12px;border-radius:8px;color:var(--text-muted);text-decoration:none;font-size:14px}
  .lg-nav a:hover{color:var(--text);background:rgba(255,255,255,.04)}
  .lg-nav a.on{color:var(--gold-bright);background:rgba(212,175,90,.1)}
  .lg-doc h1{margin:0 0 6px;font-family:'Playfair Display',serif;font-size:clamp(28px,4vw,40px);line-height:1.15}
  .lg-meta{color:var(--text-muted);font-size:13px;margin-bottom:28px}
  .lg-note{padding:12px 14px;border:1px solid var(--line);border-radius:10px;color:var(--text-muted);font-size:13.5px;margin-bottom:24px}
  .lg-doc h2{margin:30px 0 10px;font-size:18px;color:var(--gold-bright)}
  .lg-doc p,.lg-doc li{color:var(--text);opacity:.86;line-height:1.75;font-size:15px}
  .lg-doc p{margin:0 0 12px}
  .lg-doc ul{margin:0 0 12px;padding-left:22px}
  .lg-doc li{margin-bottom:6px}
  @media(max-width:820px){.lg-wrap{grid-template-columns:1fr;gap:20px}.lg-nav{position:static;flex-direction:row;flex-wrap:wrap}}
`;

export default function LegalPage({ doc }) {
  const { lang } = useI18n();
  if (!LEGAL_DOCS.includes(doc)) return <Navigate to="/terms" replace />;
  const ui = legalUi(lang);
  const sections = getLegalDoc(lang, doc);
  const title = ui.docs[doc];
  const fallback = lang !== 'EN' && lang !== 'UZ' ? ui.fallback : '';
  return (
    <>
      <PageStyle css={tokensCss} />
      <PageStyle css={CSS} />
      <div className="lg-top">
        <Link className="back" to="/index">← {ui.back}</Link>
        <LangSelect />
      </div>
      <div className="lg-wrap">
        <nav className="lg-nav" aria-label={ui.footerTitle}>
          <h6>{ui.footerTitle}</h6>
          {LEGAL_DOCS.map((d) => (
            <Link key={d} to={`/${d}`} className={d === doc ? 'on' : ''}>{ui.docs[d]}</Link>
          ))}
        </nav>
        <article className="lg-doc">
          <h1>{title}</h1>
          <div className="lg-meta">{ui.updated}: {LEGAL.updated}</div>
          {fallback && <div className="lg-note">{fallback}</div>}
          {sections.map((s) => (
            <section key={s.h}>
              <h2>{s.h}</h2>
              {(s.p || []).map((x, i) => <p key={i}>{x}</p>)}
              {s.ul && <ul>{s.ul.map((x, i) => <li key={i}>{x}</li>)}</ul>}
            </section>
          ))}
        </article>
      </div>
    </>
  );
}
