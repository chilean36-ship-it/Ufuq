import { supabase } from '../../../lib/supabaseClient';

/*
 * Exam integrity helper. The server piece (exam_violations + log_exam_violation) lives in
 * supabase/migrations/20261006_exam_integrity.sql; the call is best-effort so the exam never breaks if it fails.
 */

/** Reports a violation; never throws. kind: tab | blur | fullscreen | leave. */
export async function logViolation(examType, examId, kind, count) {
  try { await supabase.rpc('log_exam_violation', { p_exam_type: examType, p_exam_id: String(examId), p_kind: kind, p_count: count }); } catch (e) { /* best effort */ }
}
