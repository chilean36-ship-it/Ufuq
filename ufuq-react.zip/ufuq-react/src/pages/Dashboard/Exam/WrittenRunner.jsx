import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { useCabinetI18n } from '../../../context/CabinetI18nContext';
import {
  startExam, fetchAnswers, fetchRunnerQuestions, fetchSubmission,
  gradeExam, submitExam, saveAnswers as saveAnswersRpc, friendlyExamError, beginExam, fetchRemaining,
} from './writtenData';
import useExamGuard from '../../../hooks/useExamGuard';
import ExamGuardOverlay from '../../../components/ExamGuardOverlay';
import ExamShell from '../../../components/ExamShell';
import { logViolation } from './integrity';
import { useDashboardData } from '../../../context/DashboardDataContext';
import { layoutQuestions, splitAnswer, joinAnswer } from '../../../lib/examPaper';
import '../../../styles/exam-paper.css';

const FS_STEPS = [0.9, 1, 1.18, 1.38];   // text size levels for the question and the answer boxes
const AUTOSAVE_MS = 15000;   // safety net; typing also saves ~2.5 s after the last keystroke
const DEBOUNCE_MS = 2500;

/** A textarea that grows with its content, so long answers never hide behind a tiny scrolling box. */
function Grow({ value, className, ...rest }) {
  const ref = useRef(null);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = (el.scrollHeight + 2) + 'px';
  }, [value]);
  return <textarea ref={ref} className={className} value={value} {...rest} />;
}

/**
 * Written-exam runner — port of openExam() / renderRunner() / saveAnswers() / finishExam().
 * Autosaves (2.5 s after typing + every 15 s) while the submission is a draft; read-only once submitted or graded.
 * All writes go through RPCs, so no raw row-level-security error can reach the student.
 */
export default function WrittenRunner({ exam, existingSub, userId, onSubChange, onBack, toast }) {
  const { t } = useCabinetI18n();
  const { name: studentName } = useDashboardData();
  const [sub, setSub] = useState(existingSub || null);
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});   // question_id → saved answer row (scores/feedback live here)
  const [texts, setTexts] = useState({});       // question_id → text currently in the input
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [note, setNote] = useState(null);       // { text, on } — overrides the default status line
  const [finishing, setFinishing] = useState(false);
  const [phase, setPhase] = useState('intro');    // intro → exam → done (only for drafts); read-only papers skip it
  const [aiState, setAiState] = useState('idle'); // idle | checking | done | failed
  const [confirming, setConfirming] = useState(false);
  const [idx, setIdx] = useState(0);               // the question on screen (exam room shows one at a time)
  const [flags, setFlags] = useState({});         // question_id → true when marked for review (kept in this browser only)
  const [secLeft, setSecLeft] = useState(null);       // seconds left on the exam clock (null = no time limit)
  const [starting, setStarting] = useState(false);
  const [rf, setRf] = useState('all');           // result filter: all | good | mid | bad
  const [ov, setOv] = useState({});              // result cards opened / closed by hand
  const [fs, setFs] = useState(() => { try { const v = parseInt(localStorage.getItem('ufuq-xr-fs'), 10); return v >= 0 && v < FS_STEPS.length ? v : 1; } catch (e) { return 1; } });

  const mounted = useRef(true);
  const started = useRef(false);
  const subRef = useRef(existingSub || null);
  const questionsRef = useRef([]);
  const textsRef = useRef({});
  const dirty = useRef(false);
  const saving = useRef(false);
  const deadline = useRef(null);   // performance.now() value at which time runs out (immune to changing the system clock)
  const autoDone = useRef(false);
  const finishRef = useRef(null);
  const finishing_ = useRef(false);

  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);

  const setSubBoth = useCallback((next) => { subRef.current = next; setSub(next); onSubChange(next); }, [onSubChange]);

  // ---- open: draft → questions → previous answers ----
  useEffect(() => {
    if (started.current) return;
    started.current = true;
    (async () => {
      try {
        const current = await startExam(exam.id);   // resumes the draft / returns the result; server checks group + published
        const [qs, ans] = await Promise.all([fetchRunnerQuestions(exam.id), fetchAnswers(current.id)]);
        if (!mounted.current) return;
        const byQ = {}; const tx = {};
        ans.forEach((a) => { byQ[a.question_id] = a; tx[a.question_id] = a.answer_text || ''; });
        subRef.current = current; questionsRef.current = qs; textsRef.current = tx;
        setSubBoth(current); setQuestions(qs); setAnswers(byQ); setTexts(tx);
        setLoading(false);
      } catch (err) {
        if (mounted.current) { setError(t(friendlyExamError(err))); setLoading(false); }
      }
    })();
  }, [exam, userId, setSubBoth]);

  // ---- saving ----
  const saveAnswers = useCallback(async () => {
    const current = subRef.current;
    if (!current || current.status !== 'draft') return;
    const rows = questionsRef.current.map((q) => ({
      submission_id: current.id, question_id: q.id, answer_text: textsRef.current[q.id] || '',
    }));
    if (rows.length === 0) return;
    saving.current = true;
    if (mounted.current) setNote({ text: t('Saving…'), on: false });
    try {
      await saveAnswersRpc(current.id, rows);
      dirty.current = false;
      if (mounted.current) {
        setAnswers((prev) => {
          const next = { ...prev };
          rows.forEach((r) => { next[r.question_id] = { ...(next[r.question_id] || {}), ...r }; });
          return next;
        });
        setNote({ text: t('Saved'), on: true });
      }
    } catch (err) {
      if (mounted.current) setNote({ text: t('Could not save — check your connection.'), on: false });
      throw err;
    } finally {
      saving.current = false;
    }
  }, [t]);

  // Autosave every 15 s while in draft (typing also schedules a save, see onType).
  useEffect(() => {
    if (!sub || sub.status !== 'draft') return undefined;
    const id = setInterval(() => { if (dirty.current && !saving.current) saveAnswers().catch(() => {}); }, AUTOSAVE_MS);
    return () => clearInterval(id);
  }, [sub, saveAnswers]);

  // Leaving mid-exam (tab close, or switching dashboard tabs) shouldn't cost the student their last edits.
  useEffect(() => {
    const flush = () => {
      const s = subRef.current;
      if (dirty.current && s && s.status === 'draft') saveAnswers().catch(() => {});
    };
    window.addEventListener('beforeunload', flush);
    return () => { window.removeEventListener('beforeunload', flush); flush(); };
  }, [saveAnswers]);

  const debounce = useRef(null);
  useEffect(() => () => clearTimeout(debounce.current), []);
  const onType = (qid, value) => {
    textsRef.current = { ...textsRef.current, [qid]: value };
    dirty.current = true;
    setTexts(textsRef.current);
    clearTimeout(debounce.current);
    debounce.current = setTimeout(() => { if (dirty.current && !saving.current) saveAnswers().catch(() => {}); }, DEBOUNCE_MS);
  };

  const unanswered = () => questionsRef.current.filter((q) => !isAnswered(textsRef.current[q.id])).length;

  // The AI is the examiner: it grades the paper right after "Finish" and the result is shown at once.
  const runAi = async (submissionId) => {
    if (mounted.current) setAiState('checking');
    try {
      const res = await gradeExam(submissionId, { attempts: 2, jitter: 1500 });
      if (!res || !res.ok) throw new Error((res && res.error) || 'AI check failed');
      // The server may answer "busy" (another run is grading this paper) or the result may still be being written:
      // poll for 'graded' for up to ~100 s, slowing down gently so a full group does not hammer the database.
      let fresh = await fetchSubmission(submissionId);
      const until = Date.now() + 100000;
      for (let i = 0; fresh && fresh.status !== 'graded' && Date.now() < until; i++) {
        await new Promise((r) => setTimeout(r, Math.min(3000, 1500 + i * 150) + Math.random() * 400));
        if (!mounted.current) return;
        fresh = await fetchSubmission(submissionId);
      }
      if (!fresh || fresh.status !== 'graded') throw new Error('not graded yet');
      const ans = await fetchAnswers(submissionId);
      if (!mounted.current) return;
      const byQ = {}; ans.forEach((a) => { byQ[a.question_id] = a; });
      setAnswers(byQ);
      if (fresh) setSubBoth(fresh);
      setAiState('done');
    } catch (aiErr) {
      console.error('grade-exam:', aiErr);
      if (mounted.current) setAiState('failed');
    }
  };

  const finish = async (auto) => {
    const s = subRef.current;
    if (!s || s.status !== 'draft' || finishing_.current) return;
    finishing_.current = true;
    setConfirming(false);
    setFinishing(true);
    let submitted = null;
    try {
      clearTimeout(debounce.current);
      // answers must be safe before the status flips; when the time is up we submit even if this last save fails
      try { await saveAnswers(); } catch (e) { if (!auto) throw e; }
      submitted = await submitExam(s.id);
      setSubBoth(submitted);
      setPhase('done');
    } catch (err) {
      toast(t(friendlyExamError(err)));
      if (auto) autoDone.current = false;   // the clock keeps trying until the paper is handed in
    } finally {
      finishing_.current = false;
      if (mounted.current) setFinishing(false);
    }
    if (submitted) await runAi(submitted.id);
  };
  finishRef.current = finish;

  // The exam clock. The server owns the time: we get "seconds left" once and count down with the monotonic clock,
  // then re-check with the server every 30 s and whenever the tab comes back, so nothing drifts.
  const timed = secLeft !== null;
  useEffect(() => {
    if (!timed || phase !== 'exam' || !sub || sub.status !== 'draft') return undefined;
    const tick = () => {
      if (deadline.current == null) return;
      const sec = Math.max(0, Math.ceil((deadline.current - performance.now()) / 1000));
      setSecLeft(sec);
      if (sec <= 0 && !autoDone.current) {
        autoDone.current = true;
        toast(t('Time is up — your exam is being submitted.'));
        if (finishRef.current) finishRef.current(true);
      }
    };
    const resync = async () => {
      try {
        const r = await fetchRemaining(subRef.current.id);
        if (r !== null && r !== undefined) deadline.current = performance.now() + r * 1000;
        tick();
      } catch (e) { /* offline: keep counting locally */ }
    };
    tick();
    const id = setInterval(tick, 1000);
    const rid = setInterval(resync, 30000);
    const onVis = () => { if (document.visibilityState === 'visible') resync(); };
    document.addEventListener('visibilitychange', onVis);
    return () => { clearInterval(id); clearInterval(rid); document.removeEventListener('visibilitychange', onVis); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timed, phase, sub && sub.status]);

  // Opening a handed-in paper that was never checked (tab closed, AI was busy) checks it now.
  const healed = useRef(false);
  useEffect(() => {
    if (loading || error || !sub || healed.current) return;
    if (sub.status === 'submitted' && phase !== 'done') { healed.current = true; runAi(sub.id); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, error, sub, phase]);

  const guard = useExamGuard({
    active: !loading && !error && !!sub && sub.status === 'draft' && phase === 'exam', maxViolations: 3, wantFullscreen: true,
    onViolation: (kind, count) => logViolation('written', exam.id, kind, count),
    onLimit: () => setTimeout(() => finish(true), 1500),
  });

  // text size is remembered; marks for review survive a reload of the same paper
  useEffect(() => { try { localStorage.setItem('ufuq-xr-fs', String(fs)); } catch (e) { /* storage blocked */ } }, [fs]);
  const subId = sub && sub.id;
  useEffect(() => {
    if (!subId) return;
    try { setFlags(JSON.parse(localStorage.getItem('ufuq-xr-flags:' + subId) || '{}') || {}); } catch (e) { /* ignore */ }
  }, [subId]);
  useEffect(() => {
    if (!subId) return;
    try { localStorage.setItem('ufuq-xr-flags:' + subId, JSON.stringify(flags)); } catch (e) { /* ignore */ }
  }, [flags, subId]);

  const goIdx = useCallback((i) => setIdx((cur) => Math.max(0, Math.min(questionsRef.current.length - 1, typeof i === 'function' ? i(cur) : i))), []);
  const goTo = useCallback((id) => { const i = questionsRef.current.findIndex((q) => q.id === id); if (i >= 0) setIdx(i); }, []);

  // a new question: back to the top of the card, and (on a computer) straight into the answer box
  useEffect(() => {
    if (phase !== 'exam') return undefined;
    const body = document.getElementById('xrBody');
    if (body) body.scrollTo({ top: 0 });
    if (window.innerWidth <= 860) return undefined;
    const tm = setTimeout(() => { const f = document.querySelector('.xq textarea, .xq input, .xq select'); if (f) f.focus({ preventScroll: true }); }, 60);
    return () => clearTimeout(tm);
  }, [idx, phase]);

  // Alt + ← / → moves between questions without leaving the keyboard
  useEffect(() => {
    if (phase !== 'exam') return undefined;
    const onKey = (e) => {
      if (!e.altKey) return;
      if (e.key === 'ArrowRight') { e.preventDefault(); goIdx((c) => c + 1); } else if (e.key === 'ArrowLeft') { e.preventDefault(); goIdx((c) => c - 1); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [phase, goIdx]);

  if (loading) return <div id="weRunner"><p className="exam-loading">{t('Loading…')}</p></div>;
  if (error) return <div id="weRunner"><p className="exam-empty">{error}</p></div>;

  const readOnly = sub.status !== 'draft';
  const approved = sub.status === 'graded';
  const laid = layoutQuestions(questions);
  const doneCount = questions.filter((q) => isAnswered(texts[q.id])).length;
  const total = questions.length;
  const saveChip = note
    ? <span className={'xr-chip save' + (note.on ? ' ok' : '')}><i className={'xr-dotlive' + (note.on ? '' : ' busy')} /><span className="t">{note.text}</span></span>
    : <span className="xr-chip save ok"><i className="xr-dotlive" /><span className="t">{t('Saved')}</span></span>;

  // ---- one answer box, shared by the exam room and the read-only paper ----
  const buildField = (q, bank, val) => {
    const ph = readOnly ? undefined : t('Write your answer here');
    let field;
        if (q.type === 'matching' || q.type === 'antonym') {
          const { word, sentence } = splitAnswer(val);
          const setWord = (w) => onType(q.id, joinAnswer(w, sentence));
          const setSentence = (x) => onType(q.id, joinAnswer(word, x));
          field = (
            <div className="pp-fields">
              {q.type === 'matching' && bank && bank.length
                ? (
                  <select className="pp-select" dir="auto" value={word} disabled={readOnly} onChange={(e) => setWord(e.target.value)}>
                    <option value="">{t('Choose the partner word…')}</option>
                    {bank.map((w) => <option key={w} value={w}>{w}</option>)}
                  </select>
                ) : (
                  <input type="text" className="pp-line" dir="auto" data-we-answer={q.id} value={word} readOnly={readOnly} autoComplete="off" spellCheck={false}
                         placeholder={ph && t(q.type === 'antonym' ? 'Antonym' : 'Partner word')} onChange={(e) => setWord(e.target.value)} />
                )}
              <input type="text" className="pp-line" dir="auto" value={sentence} readOnly={readOnly} autoComplete="off" spellCheck={false}
                     placeholder={ph && t('Write a sentence')} onChange={(e) => setSentence(e.target.value)} />
            </div>
          );
        } else if (q.type === 'essay') {
          field = (<>
            <Grow className="pp-lines pp-essay" dir="auto" data-we-answer={q.id} value={val} readOnly={readOnly} placeholder={ph} spellCheck={false} onChange={(e) => onType(q.id, e.target.value)} />
            {!readOnly && <div className="xr-count">{t('Words')}: {wordCount(val)}</div>}
          </>);
        } else if (q.type === 'grammar') {
          field = <Grow className="pp-lines" dir="auto" data-we-answer={q.id} value={val} readOnly={readOnly} placeholder={ph} spellCheck={false} onChange={(e) => onType(q.id, e.target.value)} />;
        } else {
          field = <Grow className="pp-line" dir="auto" rows={1} data-we-answer={q.id} value={val} readOnly={readOnly} placeholder={ph} spellCheck={false} onChange={(e) => onType(q.id, e.target.value)} />;
        }
    return field;
  };

  // ---- one paper (shared by the exam room and the read-only view) ----
  const paper = (
    <div className="pp-sheet">
      <h3 className="pp-sheet-title" dir="auto">{exam.title}</h3>
      <div className="pp-nameline"><b>{t('Name')}:</b><span dir="auto">{studentName || ''}</span></div>
      {laid.map(({ q, body, partHead, secHead, bank, showBank, number }, idx) => {
        const a = answers[q.id];
        const val = texts[q.id] || '';
        let feedback = null;
        if (approved && a) {
          const score = (a.teacher_score !== null && a.teacher_score !== undefined) ? a.teacher_score
            : (a.ai_score !== null && a.ai_score !== undefined ? a.ai_score : null);
          if (score !== null) {
            feedback = (
              <div className="pp-score">
                <b>{t('Score')}: {score}</b>{a.ai_feedback ? <> — {a.ai_feedback}</> : null}
              </div>
            );
          }
        }
        const field = buildField(q, bank, val);
        return (
          <div key={q.id}>
            {partHead && <div className="pp-part" dir="auto">{partHead}</div>}
            {secHead && <div className="pp-sec" dir="auto">{secHead}</div>}
            {showBank && (
              <div className="pp-bank" dir="auto">
                <span className="pp-bank-label">{t('Word list')}</span>
                {bank.map((w) => <span className="pp-chip" key={w}>{w}</span>)}
              </div>
            )}
            <div className="pp-item" data-qid={q.id}>
              <div className="pp-item-q" dir="auto"><span className="pp-num">{number}</span><span>{body}</span></div>
              {field}
              {feedback}
            </div>
          </div>
        );
      })}
    </div>
  );

  // =============== handed in: result review (graded) or "checking" card (not graded yet) ===============
  const checkIcon = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5" /></svg>;
  const backBtn = <button type="button" className="xr-btn" onClick={onBack}>{t('Back to exams')}</button>;

  if (readOnly) {
    if (!approved) {
      return (
        <ExamShell title={exam.title} subtitle={t('Review your answers')} right={backBtn}>
          {aiState === 'checking' ? (
            <div className="xr-done">
              <div className="xr-spin" aria-hidden="true" />
              <h2>{t('AI is checking your answers')}</h2>
              <p>{t('Your result will appear in a moment.')}</p>
            </div>
          ) : (
            <div className="xr-done">
              <div className="xr-check">{checkIcon}</div>
              <h2>{t('Your exam is submitted')}</h2>
              <p>{aiState === 'failed' ? t('The AI could not check it just now. Your answers are safe — try again.') : t('The AI has not checked this paper yet.')}</p>
              <div className="xr-done-actions">
                {backBtn}
                <button type="button" className="xr-btn pri" onClick={() => runAi(sub.id)}>{aiState === 'failed' ? t('Check again') : t('Check with AI')}</button>
              </div>
            </div>
          )}
        </ExamShell>
      );
    }

    const tone = (v) => (v >= 80 ? 'good' : v >= 50 ? 'mid' : 'bad');
    let sn = 0; let skey = '|';
    const rows = laid.map(({ q, body, partHead, secHead }, i) => {
      const a = answers[q.id];
      const sc = a ? ((a.teacher_score !== null && a.teacher_score !== undefined) ? a.teacher_score : (a.ai_score !== undefined ? a.ai_score : null)) : null;
      const raw = (texts[q.id] || '');
      const k = (partHead || '') + '|' + (secHead || '');
      if (k !== '|' && k !== skey) { sn += 1; skey = k; }
      let ansText = raw.trim();
      if (q.type === 'matching' || q.type === 'antonym') { const sp = splitAnswer(raw); ansText = [sp.word, sp.sentence].filter((x) => x && x.trim()).join('\n'); }
      return { id: q.id, n: i + 1, body, sc, fb: a && a.ai_feedback, ans: ansText, sec: sn, bank: null };
    });
    const cnt = { good: 0, mid: 0, bad: 0 };
    rows.forEach((r) => { cnt[tone(r.sc || 0)] += 1; });
    const shown = rows.filter((r) => rf === 'all' || tone(r.sc || 0) === rf);
    const isOpen = (r) => (r.id in ov ? ov[r.id] : (r.sc || 0) < 80);
    const setAll = (v) => { const o = {}; rows.forEach((r) => { o[r.id] = v; }); setOv(o); };
    const filters = [['all', t('All'), rows.length], ['good', t('Correct'), cnt.good], ['mid', t('Partial'), cnt.mid], ['bad', t('Wrong'), cnt.bad]];
    const sTotal = sub.total_score == null ? null : sub.total_score;
    return (
      <ExamShell title={exam.title} subtitle={t('Review your answers')} right={backBtn}>
        <div className="xrv">
          <section className="xrv-top">
            <div className={'xr-score ' + tone(sTotal || 0)}>
              <svg viewBox="0 0 120 120" aria-hidden="true"><circle cx="60" cy="60" r="52" className="bg" /><circle cx="60" cy="60" r="52" className="fg" style={{ strokeDasharray: (Math.max(0, Math.min(100, sTotal || 0)) * 3.267) + ' 400' }} /></svg>
              <b>{sTotal == null ? '—' : sTotal}</b><span>/ 100</span>
            </div>
            <div className="xrv-sum">
              <h2>{t('Your result')}</h2>
              <p>{t('Checked by AI')} · {exam.title}</p>
              <div className="xrv-stats">
                <div className="good"><b>{cnt.good}</b>{t('Correct')}</div>
                <div className="mid"><b>{cnt.mid}</b>{t('Partial')}</div>
                <div className="bad"><b>{cnt.bad}</b>{t('Wrong')}</div>
              </div>
            </div>
          </section>

          <div className="xrv-bar">
            <div className="xrv-filters" role="tablist">
              {filters.map(([k, label, n]) => (
                <button key={k} type="button" role="tab" aria-selected={rf === k} className={'xrv-f ' + k + (rf === k ? ' on' : '')} onClick={() => setRf(k)}>{label}<i>{n}</i></button>
              ))}
            </div>
            <div className="xrv-all">
              <button type="button" onClick={() => setAll(true)}>{t('Expand all')}</button>
              <button type="button" onClick={() => setAll(false)}>{t('Collapse all')}</button>
            </div>
          </div>

          <div className="xrv-list">
            {shown.map((r) => {
              const open = isOpen(r); const tn = tone(r.sc || 0);
              return (
                <article className={'xrv-card ' + tn + (open ? ' open' : '')} key={r.id}>
                  <button type="button" className="xrv-head" aria-expanded={open} onClick={() => setOv((o) => ({ ...o, [r.id]: !open }))}>
                    <span className="xrv-n">{r.n}</span>
                    <span className="xrv-q" dir="auto">{String(r.body).replace(/\s+/g, ' ').slice(0, 120)}</span>
                    {r.sec > 0 && <span className="xrv-sec">{t('Section')} {r.sec}</span>}
                    <span className={'xr-rs ' + tn}>{r.sc == null ? '—' : r.sc}</span>
                    <svg className="xrv-chev" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M6 9l6 6 6-6" /></svg>
                  </button>
                  {open && (
                    <div className="xrv-body">
                      <p className="xrv-full" dir="auto">{r.body}</p>
                      <div className="xrv-lbl">{t('Your answer')}</div>
                      <div className={'xrv-ans' + (r.ans ? '' : ' none')} dir="auto">{r.ans || t('No answer')}</div>
                      {r.fb ? (<><div className="xrv-lbl">{t('AI comment')}</div><div className="xrv-fb" dir="auto">{r.fb}</div></>) : null}
                    </div>
                  )}
                </article>
              );
            })}
          </div>
          <div style={{ textAlign: 'center', margin: '26px 0 10px' }}>{backBtn}</div>
        </div>
      </ExamShell>
    );
  }

  if (phase === 'intro') {
    const mins = exam.duration_minutes;
    const resumed = Object.values(texts).some((v) => isAnswered(v));
    const rules = [
      ['\u26F6', t('The exam opens in full screen.')],
      ['\u2298', t('Copying, pasting, cutting, right-click, printing and text selection are disabled.')],
      ['\u26A0', t('Leaving the page, switching tabs or windows, or exiting full screen is recorded and shown to your teacher.')],
      ...(mins ? [['\u23F1', t('Time limit') + ': ' + mins + ' ' + t('min') + '. ' + t('The timer starts when you press Start and cannot be paused.')]] : []),
      ['\u2691', t('After 3 warnings the exam is submitted automatically.')],
      ['\u2713', t('Your answers are saved automatically. The AI checks them as soon as you finish.')],
    ];
    const begin = async () => {
      if (starting) return;
      setStarting(true);
      try {
        const rem = await beginExam(sub.id);   // the server starts (or resumes) the clock
        if (rem !== null) { deadline.current = performance.now() + rem * 1000; setSecLeft(rem); }
        const el = document.documentElement;
        if (!document.fullscreenElement && el.requestFullscreen) el.requestFullscreen().catch(() => {});
        setPhase('exam');
      } catch (err) {
        toast(t(friendlyExamError(err)));
      } finally {
        if (mounted.current) setStarting(false);
      }
    };
    return (
      <ExamShell title={exam.title} subtitle={t('Exam room')}>
        <div className="xr-intro">
          <h2>{t('Before you start')}</h2>
          <p>{t('Only the exam is shown: all other sections of the site are hidden until you finish.')}</p>
          <div className="xr-stats">
            <span className="xr-chip">{total} {t('questions')}</span>
            <span className="xr-chip">{mins ? '\u23F1 ' + mins + ' ' + t('min') : t('No time limit')}</span>
            {resumed && <span className="xr-chip ok">{doneCount}/{total} {t('answered')}</span>}
          </div>
          <ul className="xr-rules">{rules.map(([ic, txt]) => <li key={txt}><span className="xr-ri">{ic}</span><span>{txt}</span></li>)}</ul>
          {total === 0 && <p className="exam-empty">{t('No questions yet.')}</p>}
          <div className="xr-intro-actions">
            <button type="button" className="xr-btn" onClick={onBack}>{t('Cancel')}</button>
            <button type="button" className="xr-btn pri" onClick={begin} disabled={total === 0 || starting}>{resumed ? t('Continue the exam') : t('Start the exam')}</button>
          </div>
        </div>
      </ExamShell>
    );
  }

  const left = unanswered();

  // every question carries its part / section heading, so the context is never lost when one question is shown at a time
  const ctxs = [];
  { let part = ''; let sec = ''; laid.forEach((l, i) => { if (l.partHead) part = l.partHead; if (l.secHead) sec = l.secHead; ctxs[i] = { part, sec }; }); }
  // the question list shows short group names (Section 1, Section 2 …); the full instruction stays on the question card
  const secNo = [];
  { let n = 0; let key = '|'; laid.forEach((l, i) => { const k = (ctxs[i].part || '') + '|' + (ctxs[i].sec || ''); if (k !== '|' && k !== key) { n += 1; key = k; } secNo[i] = k === '|' ? 0 : n; }); }
  const cur = Math.min(idx, Math.max(0, total - 1));
  const item = laid[cur];
  const q = item ? item.q : null;
  const qval = q ? (texts[q.id] || '') : '';
  const flagged = !!(q && flags[q.id]);
  const flagCount = laid.filter((l) => flags[l.q.id]).length;
  const unansweredIdx = laid.map((l, i) => (isAnswered(texts[l.q.id]) ? -1 : i)).filter((i) => i >= 0);
  const flaggedIdx = laid.map((l, i) => (flags[l.q.id] ? i : -1)).filter((i) => i >= 0);
  const toggleFlag = () => { if (q) setFlags((f) => ({ ...f, [q.id]: !f[q.id] })); };
  const isLast = cur >= total - 1;

  const ICON_FLAG = <svg viewBox="0 0 24 24" width="18" height="18" fill={flagged ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 21V4M5 4h11l-2 4 2 4H5" /></svg>;
  const ICON_PREV = <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M15 18l-6-6 6-6" /></svg>;
  const ICON_NEXT = <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M9 18l6-6-6-6" /></svg>;

  const finishBtn = <button type="button" className="xr-btn ok" disabled={finishing} onClick={() => setConfirming(true)}>{t('Finish and submit')}</button>;

  return (
    <>
    <ExamShell
      title={exam.title} subtitle={doneCount + ' / ' + total + ' ' + t('answered')}
      progress={{ done: doneCount, total }}
      current={{ n: cur + 1, total }}
      navTitle={t('Question list')}
      navLegend={{ done: t('Answered'), todo: t('Not answered'), flag: t('Marked'), current: t('Current') }}
      right={<>
        {timed && <span className={'xr-chip timer' + (secLeft <= 60 ? ' crit' : secLeft <= 300 ? ' warn' : '')} role="timer" aria-label={t('Time left')} title={t('Time left')}>
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="13" r="8" /><path d="M12 9v4l2.5 2M9 2h6" /></svg>
          <b>{fmtClock(secLeft)}</b></span>}
        <div className="xr-tools" role="group" aria-label={t('Text size')}>
          <button type="button" className="xr-tool s" disabled={fs <= 0} onClick={() => setFs((v) => Math.max(0, v - 1))} aria-label={t('Smaller text')} title={t('Smaller text')}>A</button>
          <button type="button" className="xr-tool l" disabled={fs >= FS_STEPS.length - 1} onClick={() => setFs((v) => Math.min(FS_STEPS.length - 1, v + 1))} aria-label={t('Larger text')} title={t('Larger text')}>A</button>
        </div>
        {guard.violations > 0 && <span className="xr-chip warn">{'\u26A0'} {t('Warnings')}: {guard.violations}/{guard.maxViolations}</span>}
        {saveChip}
      </>}
      nav={laid.map((l, i) => ({ id: l.q.id, label: String(i + 1), done: isAnswered(texts[l.q.id]), current: i === cur, flag: !!flags[l.q.id], group: secNo[i] ? t('Section') + ' ' + secNo[i] : '' }))}
      onNav={goTo}
      navActions={finishBtn}
      footerCenter={<>
        <button type="button" className="xr-btn" disabled={cur <= 0} onClick={() => goIdx(cur - 1)}>{ICON_PREV}{t('Previous')}</button>
        {isLast
          ? <button type="button" className="xr-btn pri" disabled={finishing} onClick={() => setConfirming(true)}>{t('Review and finish')}</button>
          : <button type="button" className="xr-btn pri" onClick={() => goIdx(cur + 1)}>{t('Next')}{ICON_NEXT}</button>}
      </>}
      footerRight={<><span className="xr-foot-l">{doneCount}/{total} {t('answered')}</span>{finishBtn}</>}
      overlay={confirming ? (
        <div className="xr-modal" role="alertdialog" aria-modal="true" onClick={(e) => { if (e.target === e.currentTarget) setConfirming(false); }}>
          <div className="xr-modal-box">
            <h3>{t('Finish and submit')}</h3>
            <p>{left > 0 ? t('Some questions are not answered yet. Check them before you submit.') : t('All questions are answered.')} {t('Once you finish you can no longer change your answers. Continue?')}</p>
            <div className="xr-sum">
              <div className="ok"><b>{total - left}</b>{t('Answered')}</div>
              <div className={left > 0 ? 'no' : ''}><b>{left}</b>{t('Not answered')}</div>
              <div className="fl"><b>{flagCount}</b>{t('Marked')}</div>
            </div>
            {unansweredIdx.length > 0 && (
              <div className="xr-jump">
                <div className="xr-jump-t">{t('Not answered')}</div>
                <div className="xr-jump-l">{unansweredIdx.map((i) => <button key={i} type="button" className="xr-dot no" onClick={() => { setConfirming(false); setIdx(i); }}>{i + 1}</button>)}</div>
              </div>
            )}
            {flaggedIdx.length > 0 && (
              <div className="xr-jump">
                <div className="xr-jump-t">{t('Marked for review')}</div>
                <div className="xr-jump-l">{flaggedIdx.map((i) => <button key={i} type="button" className="xr-dot flag" onClick={() => { setConfirming(false); setIdx(i); }}>{i + 1}</button>)}</div>
              </div>
            )}
            <div className="xr-modal-actions">
              <button type="button" className="xr-btn" onClick={() => setConfirming(false)}>{left > 0 ? t('Go back to the exam') : t('Back')}</button>
              <button type="button" className="xr-btn ok" onClick={() => finish()}>{t('Finish and submit')}</button>
            </div>
          </div>
        </div>
      ) : null}
    >
      {!q ? <p className="xq-empty">{t('No questions yet.')}</p> : (
        <>
          <article className="xq" key={q.id} data-qid={q.id} style={{ '--xr-fs': FS_STEPS[fs] }}>
            <div className="xq-top">
              <span className="xq-no"><span>{t('Question')}</span><b>{cur + 1}</b><span>/ {total}</span></span>
              {isAnswered(qval) ? <span className="xq-done">{'\u2713'} {t('Answered')}</span> : null}
              <button type="button" className={'xq-flagbtn' + (flagged ? ' on' : '')} aria-pressed={flagged} onClick={toggleFlag} title={t('Mark for review')}>
                {ICON_FLAG}<span className="t">{flagged ? t('Marked for review') : t('Mark for review')}</span>
              </button>
            </div>
            {(ctxs[cur].part || ctxs[cur].sec) && (
              <div className="xq-ctx">
                {ctxs[cur].part ? <div className="xq-part" dir="auto">{ctxs[cur].part}</div> : null}
                {ctxs[cur].sec ? <div className="xq-sec" dir="auto">{ctxs[cur].sec}</div> : null}
              </div>
            )}
            {item.bank && item.bank.length > 0 && (
              <div className="xq-bank" dir="auto">
                <span className="xq-bank-l">{t('Word list')}</span>
                {item.bank.map((w) => <span className="xq-chip" key={w}>{w}</span>)}
              </div>
            )}
            <p className="xq-text" dir="auto">{item.body}</p>
            {buildField(q, item.bank, qval)}
          </article>
          <p className="xq-hint">{t('Your answers are saved automatically.')}</p>
        </>
      )}
    </ExamShell>
    <ExamGuardOverlay t={t} warning={guard.warning} max={guard.maxViolations} onContinue={guard.dismiss} />
    </>
  );
}

/** A two-field answer ("word\nsentence") with both parts empty is not an answer. */
function isAnswered(v) { return !!v && v.replace(/\s+/g, '') !== ''; }
function wordCount(v) { const m = (v || '').trim().match(/\S+/g); return m ? m.length : 0; }

/** 75 → "01:15", 3725 → "1:02:05" */
function fmtClock(sec) {
  const v = Math.max(0, Math.floor(sec || 0));
  const h = Math.floor(v / 3600); const m = Math.floor((v % 3600) / 60); const x = v % 60;
  const p = (n) => String(n).padStart(2, '0');
  return h > 0 ? h + ':' + p(m) + ':' + p(x) : p(m) + ':' + p(x);
}
