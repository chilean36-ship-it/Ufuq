import { useCallback, useEffect, useRef, useState } from 'react';
import { useCabinetI18n } from '../../../context/CabinetI18nContext';
import { useDashboardData } from '../../../context/DashboardDataContext';
import { fetchMySubmissions, fetchPublishedWrittenExams, fetchQuestionCounts, friendlyExamError, gradeExam } from './writtenData';
import WrittenRunner from './WrittenRunner';
import useScrollTop from '../../../hooks/useScrollTop';
import useLiveRefresh from '../../../lib/liveRefresh';
import PageStyle from '../../../components/PageStyle';
import css from '../../../styles/exam-list.css?inline';

const CHECK_ICON = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5" /></svg>
);

/** "Written exams" sub-tab — port of loadWrittenList() and the list markup. Mounted only while the tab is active. */
export default function WrittenExams() {
  const { t } = useCabinetI18n();
  const { user, role, groupCode, groupData } = useDashboardData();
  const userId = user && user.id;
  const isStaff = role === 'teacher';   // teachers only preview the list; admins may take exams (server allows it)

  const [exams, setExams] = useState(null);     // null = loading
  const [subs, setSubs] = useState({});
  const [counts, setCounts] = useState({});
  const [error, setError] = useState('');
  const [runExam, setRunExam] = useState(null);
  const [toastMsg, setToastMsg] = useState(null);
  useScrollTop(runExam ? runExam.id : 'list');
  const toastTimer = useRef(null);
  useEffect(() => () => clearTimeout(toastTimer.current), []);

  // The dashboard has one save-chip and no general toast, so reuse the same markup (original weToast()).
  const toast = useCallback((msg) => {
    setToastMsg(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastMsg(null), 2800);
  }, []);

  // `silent` = the 5-second background refresh: no loading state, no error message, and nothing re-renders unless the data changed
  const sigRef = useRef('');
  const load = useCallback(async (opts) => {
    const silent = !!(opts && opts.silent);
    if (!silent) { setExams(null); setError(''); sigRef.current = ''; }
    try {
      const list = await fetchPublishedWrittenExams(groupCode);   // only the exams of the group selected at the top
      let s = {}; let c = {};
      if (list.length > 0) {
        const ids = list.map((e) => e.id);
        [s, c] = await Promise.all([fetchMySubmissions(userId, ids), fetchQuestionCounts(ids)]);
      }
      const sig = JSON.stringify([list, s, c]);
      if (silent && sig === sigRef.current) return;
      sigRef.current = sig;
      setSubs(s); setCounts(c); setExams(list); setError('');
    } catch (err) {
      if (silent) return;
      setError(t(friendlyExamError(err)));
      setExams([]);
    }
  }, [userId, groupCode]);

  useEffect(() => { load(); }, [load]);
  useLiveRefresh((o) => (runExam ? undefined : load(o)));

  // Self-healing: a paper handed in but never checked (tab closed, AI busy) is checked now, once per paper per visit.
  const healed = useRef({});
  useEffect(() => {
    if (isStaff || !exams) return;
    Object.values(subs).filter((x) => x.status === 'submitted' && !healed.current[x.id]).forEach((x) => {
      healed.current[x.id] = true;
      gradeExam(x.id, { attempts: 2 }).then(() => load()).catch(() => { /* the card keeps saying "not checked yet"; the next visit tries again */ });
    });
  }, [subs, exams, isStaff, load]);

  const onSubChange = useCallback((sub) => {
    if (sub) setSubs((prev) => ({ ...prev, [sub.exam_id]: sub }));
  }, []);
  const onBack = useCallback(() => { setRunExam(null); load(); }, [load]);

  const openExam = (ex) => {
    if (!userId) { toast(t('Loading…')); return; }
    if (isStaff) { toast(t('Teachers and admins cannot take exams — this is a student view.')); return; }
    setRunExam(ex);
  };

  return (
    <>
      {runExam ? (
        <WrittenRunner exam={runExam} existingSub={subs[runExam.id]} userId={userId} onSubChange={onSubChange} onBack={onBack} toast={toast} />
      ) : (
        <div id="weStudentList">
          <PageStyle css={css} />
          {groupData && groupData.name && <div className="we-group-line">{t('Group')}: <b>{groupData.name}</b></div>}
          {isStaff && <p className="exam-empty" style={{ textAlign: 'left' }}>{t('Teachers and admins cannot take exams — this is a student view.')}</p>}
          {error ? (
            <p className="exam-empty">{error}</p>
          ) : exams === null ? (
            <p className="exam-loading">{t('Loading…')}</p>
          ) : exams.length === 0 ? (
            <p className="exam-empty">{t('No written exams for you yet.')}</p>
          ) : (
            <div className="wl-grid">
              {exams.map((ex) => {
                const s = subs[ex.id];
                let state = 'new'; let badge; let action; let score = null;
                if (s && s.status === 'graded') {
                  state = 'graded'; badge = t('Graded'); score = s.total_score == null ? '\u2014' : s.total_score;
                  action = <button type="button" className="wl-btn" onClick={() => openExam(ex)}>{t('View result')}</button>;
                } else if (s && s.status === 'submitted') {
                  state = 'wait'; badge = t('Checking…');
                  action = <button type="button" className="wl-btn" onClick={() => openExam(ex)}>{t('View result')}</button>;
                } else if (s && s.status === 'draft') {
                  state = 'draft'; badge = t('Draft');
                  action = <button type="button" className="wl-btn pri" onClick={() => openExam(ex)}>{t('Continue')}</button>;
                } else {
                  badge = t('Written exams');
                  action = <button type="button" className="wl-btn pri" onClick={() => openExam(ex)}>{t('Start')}</button>;
                }
                const tone = score === null || score === '\u2014' ? '' : (score >= 80 ? ' good' : score >= 50 ? ' mid' : ' bad');
                return (
                  <article className={'wl-card ' + state} key={ex.id}>
                    <div className="wl-top">
                      <span className={'wl-badge ' + state}>{badge}</span>
                      {score !== null && <span className={'wl-score' + tone}>{score}<small>/100</small></span>}
                    </div>
                    <h3 className="wl-title" dir="auto">{ex.title}</h3>
                    <div className="wl-meta">
                      <span><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 11l3 3L22 4M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11" /></svg>{counts[ex.id] || 0} {t('questions')}</span>
                      <span><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="13" r="8" /><path d="M12 9v4l2.5 2M9 2h6" /></svg>{ex.duration_minutes ? ex.duration_minutes + ' ' + t('min') : t('No time limit')}</span>
                    </div>
                    <div className="wl-act">{action}</div>
                  </article>
                );
              })}
            </div>
          )}
        </div>
      )}
      <div className={'save-toast' + (toastMsg ? ' show' : '')} id="saveToast">
        {CHECK_ICON}<span>{toastMsg || ''}</span>
      </div>
    </>
  );
}
