// Timezone-aware week/schedule helpers — port of the date logic in dashboard.html's inline script.
// Every group's schedule_days is stored in Tashkent wall-clock time (UTC+5, no DST); these turn
// each entry into a real UTC instant so "is class live right now" and the on-screen time are both
// correct no matter where the student actually is.

const DAY_NAMES_MON_FIRST = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
export const DAY_NAME_BY_JS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
export const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const TASHKENT_OFFSET_MS = 5 * 60 * 60000; // GMT+5, Tashkent has no DST

export function getCurrentWeekDates() {
  const now = new Date();
  const dow = now.getDay(); // 0=Sun..6=Sat
  const mondayOffset = dow === 0 ? -6 : 1 - dow;
  const monday = new Date(now);
  monday.setHours(0, 0, 0, 0);
  monday.setDate(now.getDate() + mondayOffset);
  const todayStr = new Date().toDateString();
  return DAY_NAMES_MON_FIRST.map((name, i) => {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    return {
      day: name, date: d,
      dateLabel: MONTH_NAMES[d.getMonth()] + ' ' + d.getDate(),
      dateNum: d.getDate(),
      isToday: d.toDateString() === todayStr,
    };
  });
}

export function nowInTashkent() {
  return new Date(Date.now() + TASHKENT_OFFSET_MS);
}

/** Real UTC instant for `daysFromToday` days after Tashkent's current calendar day, at hh:mm Tashkent wall-clock time. */
export function tashkentInstant(daysFromToday, hh, mm) {
  const t = nowInTashkent();
  return new Date(
    Date.UTC(t.getUTCFullYear(), t.getUTCMonth(), t.getUTCDate() + daysFromToday, hh, mm, 0, 0) - TASHKENT_OFFSET_MS
  );
}

export function formatLocalTime(date) {
  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

/** Full Monday-first week array ({day,time,instant}), each class's time in the *viewer's own* local clock. */
export function scheduleDaysToWeekArray(scheduleDays, currentWeek) {
  const byDay = {};
  (scheduleDays || []).forEach((entry) => { if (entry && entry.day) byDay[entry.day] = entry.time; });
  const tashkentTodayIdx = nowInTashkent().getUTCDay();
  return currentWeek.map((w) => {
    const hhmm = byDay[w.day];
    if (!hhmm) return { day: w.day, time: null };
    const [hh, mm] = hhmm.split(':').map(Number);
    const dayIdx = DAY_NAME_BY_JS.indexOf(w.day);
    const offset = dayIdx - tashkentTodayIdx; // this Tashkent-week's occurrence of w.day
    const instant = tashkentInstant(offset, hh, mm);
    return { day: w.day, time: formatLocalTime(instant), instant };
  });
}

export function getLiveClassNow(scheduleDays) {
  if (!scheduleDays || !scheduleDays.length) return null;
  const todayName = DAY_NAME_BY_JS[nowInTashkent().getUTCDay()];
  const entry = scheduleDays.find((e) => e && e.day === todayName);
  if (!entry || !entry.time) return null;
  const [hh, mm] = entry.time.split(':').map(Number);
  const start = tashkentInstant(0, hh, mm);
  const end = new Date(start.getTime() + 120 * 60000);
  const now = new Date();
  return now >= start && now <= end ? { start, end } : null;
}

function resolveScheduleForDay(scheduleDays, dayName) {
  if (!scheduleDays || !scheduleDays.length) return null;
  let match = null;
  scheduleDays.forEach((entry) => { if (entry && entry.day === dayName) match = entry; });
  return match;
}

/** First upcoming class instant (today included) across the next 7 days, in the viewer's local time. */
export function findNextClass(scheduleDays) {
  if (!scheduleDays || !scheduleDays.length) return null;
  const now = new Date();
  const tashkentTodayIdx = nowInTashkent().getUTCDay();
  for (let offset = 0; offset <= 7; offset++) {
    const dayName = DAY_NAME_BY_JS[(tashkentTodayIdx + offset) % 7];
    const entry = resolveScheduleForDay(scheduleDays, dayName);
    if (entry && entry.time) {
      const [hh, mm] = entry.time.split(':').map(Number);
      const start = tashkentInstant(offset, hh, mm);
      if (start > now) {
        return {
          day: DAY_NAME_BY_JS[start.getDay()], time: formatLocalTime(start), start,
          dateLabel: MONTH_NAMES[start.getMonth()] + ' ' + start.getDate(),
        };
      }
    }
  }
  return null;
}

export function fmtDueDate(iso) {
  const d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

export function isOverdue(iso) {
  return new Date(iso + 'T23:59:59') < new Date();
}
