import PageStyle from './PageStyle';
import { GUARD_CSS } from '../hooks/useExamGuard';

/** Warning shown after each integrity violation. `t` is the cabinet translate function. */
export default function ExamGuardOverlay({ t, warning, max, onContinue }) {
  return (
    <>
      <PageStyle css={GUARD_CSS} />
      {warning && (
        <div className="exam-guard-overlay" role="alertdialog" aria-modal="true">
          <div className="exam-guard-box">
            <h3>{t('Warning: you left the exam')}</h3>
            <p>
              {t('Leaving the exam page, switching tabs or exiting full screen is recorded and shown to your teacher.')}{' '}
              <b>{warning.count} / {max}</b>. {warning.count >= max ? t('Your exam is being submitted now.') : t('At the limit your exam is submitted automatically.')}
            </p>
            {warning.count < max && <button type="button" onClick={onContinue}>{t('Return to the exam')}</button>}
          </div>
        </div>
      )}
    </>
  );
}
