import { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { clearCachedRole, getSessionAndRole, ROLE_PAGES } from '../lib/auth';
import { AuthContext } from '../context/AuthContext';
import NameGate from './NameGate';

/**
 * Unified Supabase Auth + RBAC guard (port of auth-guard.js).
 *   - No session               -> /index
 *   - role === 'admin'         -> always allowed (bypasses requiredRole)
 *   - role !== requiredRole    -> redirected to that role's own page
 *   - role === requiredRole    -> children render
 * Nothing sensitive renders until the check has finished.
 */
export default function RequireRole({ role: requiredRole, children }) {
  const [state, setState] = useState({ status: 'checking', auth: null, redirect: null });

  useEffect(() => {
    let cancelled = false;
    (async () => {
      let result;
      try {
        // Never hang on a blank screen if the network/Supabase doesn't answer.
        result = await Promise.race([
          getSessionAndRole(),
          new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 15000)),
        ]);
      } catch (e) { result = null; }
      if (cancelled) return;
      if (!result) { clearCachedRole(); return setState({ status: 'redirect', auth: null, redirect: ROLE_PAGES.login }); }
      const auth = { user: result.user, role: result.role, fullName: result.full_name };
      if (result.role === 'admin' || result.role === requiredRole) {
        return setState({ status: 'ok', auth, redirect: null });
      }
      setState({ status: 'redirect', auth, redirect: ROLE_PAGES[result.role] || ROLE_PAGES.login });
    })();
    return () => { cancelled = true; };
  }, [requiredRole]);

  if (state.status === 'checking') {
    return (
      <div style={{ position: 'fixed', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#121212', color: '#A8A29B', fontFamily: 'Inter, system-ui, sans-serif', fontSize: 14 }}>
        Loading…
      </div>
    );
  }
  if (state.status === 'redirect') return <Navigate to={state.redirect} replace />;
  return <AuthContext.Provider value={state.auth}><NameGate>{children}</NameGate></AuthContext.Provider>;
}
