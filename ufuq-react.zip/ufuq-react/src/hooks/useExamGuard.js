import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * Exam integrity guard — a deterrent, not a lock: browsers can't be fully locked down, so every violation is
 * counted, shown to the student and reported (`onViolation`) so the teacher sees it next to the result.
 *
 * While `active`:
 *  - blocks copy / cut / paste / drag / right-click / text selection / print and the usual shortcuts
 *    (Ctrl+C/X/V/A/P/S/U/F, F12, Ctrl+Shift+I/J/C, PrintScreen)
 *  - counts leaving the page (tab switch, window blur, leaving full screen) as a violation
 *  - asks for full screen and asks again if the student exits it
 *  - warns before the page is closed or reloaded
 * After `maxViolations` the `onLimit` callback fires (the runner auto-submits).
 *
 * `allowPaste` stays false even for written exams: students type their own answers.
 */
export default function useExamGuard({ active, maxViolations = 3, onViolation, onLimit, wantFullscreen = true }) {
  const [violations, setViolations] = useState(0);
  const [warning, setWarning] = useState(null);       // { kind, count } while the warning overlay is up
  const countRef = useRef(0);
  const cbRef = useRef({ onViolation, onLimit });
  cbRef.current = { onViolation, onLimit };
  const lastRef = useRef(0);

  const register = useCallback((kind) => {
    const now = Date.now();
    if (now - lastRef.current < 1200) return;       // blur + visibilitychange fire together — count once
    lastRef.current = now;
    countRef.current += 1;
    const count = countRef.current;
    setViolations(count);
    setWarning({ kind, count });
    if (cbRef.current.onViolation) cbRef.current.onViolation(kind, count);
    if (count >= maxViolations && cbRef.current.onLimit) cbRef.current.onLimit(count);
  }, [maxViolations]);

  const dismiss = useCallback(() => {
    setWarning(null);
    if (wantFullscreen && !document.fullscreenElement && document.documentElement.requestFullscreen) {
      document.documentElement.requestFullscreen().catch(() => {});
    }
  }, [wantFullscreen]);

  useEffect(() => {
    if (!active) return undefined;
    const isField = (el) => !!el && (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && el.type === 'text'));
    const stop = (e) => { if (e.type === 'selectstart' && isField(e.target)) return; e.preventDefault(); };
    const stopInput = (e) => {
      const it = e.inputType || '';
      if (it === 'insertFromPaste' || it === 'insertFromDrop' || it === 'insertFromYank' || it === 'deleteByCut' || it === 'insertFromPasteAsQuotation') e.preventDefault();
    };
    // Browser back/forward (and swipe-back) would leave the exam: keep the student here and count it.
    const onPop = () => { try { window.history.pushState({ examGuard: 1 }, '', window.location.href); } catch (e) { /* ignore */ } register('leave'); };
    const onKey = (e) => {
      const k = (e.key || '').toLowerCase();
      const mod = e.ctrlKey || e.metaKey;
      const devtools = k === 'f12' || (mod && e.shiftKey && ['i', 'j', 'c'].includes(k));
      if (devtools || (mod && ['c', 'x', 'v', 'a', 'p', 's', 'u', 'f'].includes(k)) || k === 'printscreen') {
        e.preventDefault();
        if (k === 'printscreen' && navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText('').catch(() => {});
      }
    };
    const onVisibility = () => { if (document.hidden) register('tab'); };
    const onBlur = () => register('blur');
    const onFs = () => { if (wantFullscreen && !document.fullscreenElement) register('fullscreen'); };
    const onBeforeUnload = (e) => { e.preventDefault(); e.returnValue = ''; };

    ['copy', 'cut', 'paste', 'dragstart', 'drop', 'contextmenu', 'selectstart'].forEach((ev) => document.addEventListener(ev, stop, true));
    document.addEventListener('keydown', onKey, true);
    document.addEventListener('beforeinput', stopInput, true);
    try { window.history.pushState({ examGuard: 1 }, '', window.location.href); } catch (e) { /* ignore */ }
    window.addEventListener('popstate', onPop);
    document.addEventListener('visibilitychange', onVisibility);
    document.addEventListener('fullscreenchange', onFs);
    window.addEventListener('blur', onBlur);
    window.addEventListener('beforeunload', onBeforeUnload);
    document.body.classList.add('exam-guard-on');
    if (wantFullscreen && !document.fullscreenElement && document.documentElement.requestFullscreen) {
      document.documentElement.requestFullscreen().catch(() => {});
    }
    return () => {
      ['copy', 'cut', 'paste', 'dragstart', 'drop', 'contextmenu', 'selectstart'].forEach((ev) => document.removeEventListener(ev, stop, true));
      document.removeEventListener('keydown', onKey, true);
      document.removeEventListener('beforeinput', stopInput, true);
      window.removeEventListener('popstate', onPop);
      document.removeEventListener('visibilitychange', onVisibility);
      document.removeEventListener('fullscreenchange', onFs);
      window.removeEventListener('blur', onBlur);
      window.removeEventListener('beforeunload', onBeforeUnload);
      document.body.classList.remove('exam-guard-on');
      if (document.fullscreenElement && document.exitFullscreen) document.exitFullscreen().catch(() => {});
    };
  }, [active, register, wantFullscreen]);

  return { violations, warning, dismiss, maxViolations };
}

/** Warning overlay shown after each violation (rendered by the runners). */
export const GUARD_CSS = `
body.exam-guard-on, body.exam-guard-on *{ -webkit-user-select:none; user-select:none; -webkit-touch-callout:none; }
body.exam-guard-on textarea, body.exam-guard-on input[type="text"]{ -webkit-user-select:text; user-select:text; }
.exam-guard-overlay{ position:fixed; inset:0; z-index:100000; background:rgba(8,10,10,.88); backdrop-filter:blur(6px); display:flex; align-items:center; justify-content:center; padding:20px; }
.exam-guard-box{ max-width:440px; width:100%; background:#1B2427; color:#EDEAE3; border:1px solid rgba(229,120,100,.5); border-radius:18px; padding:26px; text-align:center; box-shadow:0 30px 80px rgba(0,0,0,.6); }
.exam-guard-box h3{ margin:0 0 8px; font-size:20px; color:#F0A592; }
.exam-guard-box p{ margin:0 0 16px; color:#B9B3AA; font-size:14.5px; line-height:1.55; }
.exam-guard-box b{ color:#fff; }
.exam-guard-box button{ border:0; border-radius:11px; padding:11px 22px; background:#C9A24B; color:#1A1405; font-weight:700; font-size:14px; cursor:pointer; }
.exam-guard-badge{ display:inline-flex; align-items:center; gap:6px; padding:5px 10px; border-radius:99px; font-size:12px; font-weight:700; background:rgba(229,120,100,.16); color:#F0A592; }
`;
